import React, { useCallback, useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import Home from './components/Home';
import Editor from './components/Editor';
import NewProjectModal from './components/NewProjectModal';
import SettingsPanel from './components/SettingsPanel';
import { mediaPool } from './utils/mediaPool';
import { useSettings } from './utils/settings';
import {
  clearAll, deleteProject, getProject, listProjects, loadProjectMedia, putProject, serializeProject,
} from './utils/db';
import { applyTheme, createProject, uid } from './utils/project';

export default function App() {
  const [settings, updateSettings, resetSettings] = useSettings();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(null); // 'new' | 'settings'
  const [opened, setOpened] = useState(null);
  const [busy, setBusy] = useState('');

  useEffect(() => {
    applyTheme(settings.theme, settings.glass, settings.blurOn);
  }, [settings.theme, settings.glass, settings.blurOn]);

  const refresh = useCallback(async () => {
    try {
      setProjects(await listProjects());
    } catch {
      setProjects([]);
    }
    setLoading(false);
  }, []);
  useEffect(() => {
    refresh();
  }, [refresh]);

  const openProject = async (id) => {
    setBusy('Opening project...');
    try {
      const rec = await getProject(id);
      if (!rec) throw new Error('That project could not be found.');
      const { project, urls } = await loadProjectMedia(rec);
      setOpened({ id, name: rec.name, created: rec.created, project, urls });
    } catch (e) {
      window.alert(e.message || 'Could not open the project.');
    } finally {
      setBusy('');
    }
  };

  const createProj = async ({ name, aspect, look }) => {
    const id = uid();
    const created = Date.now();
    const project = createProject(aspect, look);
    try {
      await putProject({ id, name, created, updated: created, aspect, duration: 0, thumb: null, data: serializeProject(project) });
    } catch {
      window.alert('This browser cannot save projects (private mode?). You can still edit, but nothing will be kept.');
    }
    setModal(null);
    setOpened({ id, name, created, project, urls: [] });
  };

  const exitEditor = () => {
    if (opened) opened.urls.forEach((u) => URL.revokeObjectURL(u));
    mediaPool.clear();
    setOpened(null);
    refresh();
  };

  const renameProject = async (p) => {
    const name = window.prompt('Project name', p.name);
    if (!name || !name.trim()) return;
    const rec = await getProject(p.id);
    if (rec) await putProject({ ...rec, name: name.trim().slice(0, 40) });
    refresh();
  };

  const removeProject = async (p) => {
    if (!window.confirm(`Delete "${p.name}"? This also removes its media from this device.`)) return;
    await deleteProject(p.id);
    refresh();
  };

  const clearEverything = async () => {
    if (!window.confirm('Delete ALL projects and their media from this device?')) return;
    await clearAll();
    refresh();
  };

  const goFullscreen = async () => {
    try {
      if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
      if (window.screen.orientation && window.screen.orientation.lock) await window.screen.orientation.lock('landscape');
    } catch {
      window.alert('This browser blocked fullscreen. Rotate your tablet to landscape instead.');
    }
  };

  return (
    <>
      {opened ? (
        <Editor
          key={opened.id}
          id={opened.id}
          initialName={opened.name}
          created={opened.created}
          initialProject={opened.project}
          settings={settings}
          updateSettings={updateSettings}
          onExit={exitEditor}
          onOpenSettings={() => setModal('settings')}
        />
      ) : (
        <Home
          projects={projects}
          loading={loading}
          onNew={() => setModal('new')}
          onOpen={openProject}
          onRename={renameProject}
          onDelete={removeProject}
          onSettings={() => setModal('settings')}
        />
      )}

      {modal === 'new' && (
        <NewProjectModal defaultName={`Project ${projects.length + 1}`} onCreate={createProj} onClose={() => setModal(null)} />
      )}
      {modal === 'settings' && (
        <SettingsPanel
          settings={settings}
          update={updateSettings}
          reset={resetSettings}
          onClose={() => setModal(null)}
          onFullscreen={goFullscreen}
          onClearAll={clearEverything}
        />
      )}
      {busy && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50">
          <div className="glass-sm px-5 py-3 flex items-center gap-2 text-sm"><Loader2 size={16} className="animate-spin" /> {busy}</div>
        </div>
      )}
    </>
  );
}
