import React, { useCallback, useEffect, useReducer, useRef, useState } from 'react';
import {
  Download, Film, Layers, Maximize, Music, Pause, Play, Plus, Redo2, Settings, SkipBack, Sparkles, Type, Undo2,
} from 'lucide-react';
import CanvasPlayer from './components/CanvasPlayer';
import Timeline from './components/Timeline';
import Inspector from './components/Inspector';
import AutoCaptions from './components/AutoCaptions';
import AiModal from './components/AiModal';
import SettingsDrawer from './components/SettingsDrawer';
import ExportModal from './components/ExportModal';
import Modal from './components/Modal';
import { historyReducer, initialHistory } from './state/projectReducer';
import { mediaPool } from './utils/mediaPool';
import { loadMediaFile } from './utils/media';
import { useSettings } from './utils/settings';
import { clamp, clipEnd, formatTime, projectDuration, uid } from './utils/project';

export default function App() {
  const [hist, dispatch] = useReducer(historyReducer, initialHistory);
  const project = hist.present;
  const [selected, setSelected] = useState(null);
  const [time, setTime] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [modal, setModal] = useState(null);
  const [exporting, setExporting] = useState(false);
  const [toast, setToast] = useState('');
  const [importing, setImporting] = useState(false);
  const [settings, updateSettings] = useSettings();

  const clockRef = useRef({ time: 0 });
  const fileRef = useRef(null);
  const addTrackRef = useRef('video');
  const toastTimer = useRef(null);

  const duration = projectDuration(project);
  const aiReady = settings.aiEnabled && settings.apiKey.trim().length > 0;

  const projectRef = useRef(project);
  const durRef = useRef(duration);
  const playingRef = useRef(playing);
  const selectedRef = useRef(selected);
  projectRef.current = project;
  durRef.current = duration;
  playingRef.current = playing;
  selectedRef.current = selected;

  const showToast = useCallback((msg) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 3200);
  }, []);

  const seek = useCallback((t) => {
    const tt = clamp(t, 0, Math.max(durRef.current, 0));
    clockRef.current.time = tt;
    setTime(tt);
  }, []);

  const onTime = useCallback((t) => setTime(t), []);
  const onEnded = useCallback(() => setPlaying(false), []);

  const togglePlay = useCallback(async () => {
    if (playingRef.current) {
      setPlaying(false);
      mediaPool.pauseAll();
      return;
    }
    if (durRef.current <= 0) return;
    await mediaPool.resume();
    if (clockRef.current.time >= durRef.current - 0.05) seek(0);
    setPlaying(true);
  }, [seek]);

  const doSplit = useCallback(() => {
    const p = projectRef.current;
    const t = clockRef.current.time;
    const sel = selectedRef.current;
    const inside = (c) => c && t > c.start + 0.05 && t < clipEnd(c) - 0.05;
    let target = sel && sel.type === 'clip' ? p.clips.find((c) => c.id === sel.id) : null;
    if (!inside(target)) target = p.clips.find((c) => c.track === 'video' && inside(c));
    if (!target) {
      showToast('Move the playhead over a clip, then tap Split.');
      return;
    }
    dispatch({ type: 'SPLIT', id: target.id, time: t, newId: uid() });
  }, [showToast]);

  const doDelete = useCallback(() => {
    const sel = selectedRef.current;
    if (!sel) return;
    dispatch(sel.type === 'clip' ? { type: 'DELETE_CLIP', id: sel.id } : { type: 'DELETE_SUB', id: sel.id });
    setSelected(null);
  }, []);

  useEffect(() => {
    if (clockRef.current.time > duration) {
      clockRef.current.time = duration;
      setTime(duration);
    }
  }, [duration]);

  useEffect(() => {
    if (!selected) return;
    const ok = selected.type === 'clip'
      ? project.clips.some((c) => c.id === selected.id)
      : project.subtitles.some((s) => s.id === selected.id);
    if (!ok) setSelected(null);
  }, [project, selected]);

  useEffect(() => {
    const onKey = (e) => {
      const tag = (e.target && e.target.tagName) || '';
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tag)) return;
      const k = e.key.toLowerCase();
      if (e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        doDelete();
      } else if ((e.ctrlKey || e.metaKey) && k === 'z') {
        e.preventDefault();
        dispatch({ type: e.shiftKey ? 'REDO' : 'UNDO' });
      } else if ((e.ctrlKey || e.metaKey) && k === 'y') {
        e.preventDefault();
        dispatch({ type: 'REDO' });
      } else if (k === 's' && !e.ctrlKey && !e.metaKey) {
        doSplit();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [togglePlay, doDelete, doSplit]);

  // ----- adding media -----
  const pickFiles = (track) => {
    addTrackRef.current = track;
    const input = fileRef.current;
    input.accept = track === 'audio' ? 'audio/*,video/*' : 'video/*,image/*';
    input.value = '';
    setModal(null);
    input.click();
  };

  const onFiles = async (e) => {
    const files = Array.from(e.target.files || []);
    const track = addTrackRef.current;
    if (!files.length) return;
    setImporting(true);
    for (const file of files) {
      try {
        const m = await loadMediaFile(file);
        if (track === 'audio' && m.kind === 'image') throw new Error(`"${file.name}" is a photo. Use Add, then Video or photo.`);
        if (track !== 'audio' && m.kind === 'audio') throw new Error(`"${file.name}" is audio. Use Add, then Audio or music.`);
        const clip = {
          id: uid(), name: m.name, kind: m.kind, url: m.url, thumb: m.thumb, track,
          inPoint: 0, outPoint: m.srcDuration, srcDuration: m.srcDuration, volume: 1, fit: 'contain',
        };
        const first = projectRef.current.clips.length === 0 && track === 'video';
        const portrait = m.kind === 'video' && m.height > m.width;
        dispatch(first && portrait
          ? { type: 'BATCH', actions: [{ type: 'SET_ASPECT', aspect: '9:16' }, { type: 'ADD_CLIP', clip }] }
          : { type: 'ADD_CLIP', clip });
        setSelected({ type: 'clip', id: clip.id });
      } catch (err) {
        showToast(err.message || 'Could not add that file.');
      }
    }
    setImporting(false);
  };

  const goFullscreen = async () => {
    try {
      if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
      if (window.screen.orientation && window.screen.orientation.lock) await window.screen.orientation.lock('landscape');
    } catch {
      showToast('This browser blocked fullscreen. Rotate your tablet to landscape instead.');
    }
  };

  const onExportBusy = useCallback((busy) => {
    setExporting(busy);
    if (busy) {
      setPlaying(false);
      mediaPool.pauseAll();
    } else {
      seek(0);
    }
  }, [seek]);

  const closeModal = () => setModal(null);

  return (
    <div className="h-[100dvh] w-screen flex flex-col gap-2 p-2 overflow-hidden">
      <header className="glass-sm h-12 shrink-0 flex items-center gap-1.5 px-2">
        <div className="flex items-center gap-2 pr-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-cyan-400 flex items-center justify-center">
            <Play size={14} className="text-slate-950" fill="currentColor" />
          </div>
          <span className="font-semibold hidden md:block">Pocket Cut</span>
        </div>
        <button className="btn" onClick={() => setModal('add')}><Plus size={16} /> Add</button>
        <button className="btn-icon" onClick={() => dispatch({ type: 'UNDO' })} disabled={!hist.past.length && !hist.base} aria-label="Undo"><Undo2 size={18} /></button>
        <button className="btn-icon" onClick={() => dispatch({ type: 'REDO' })} disabled={!hist.future.length} aria-label="Redo"><Redo2 size={18} /></button>
        <button className="btn" onClick={() => setModal('captions')}><Type size={16} /> Captions</button>
        {aiReady && <button className="btn" onClick={() => setModal('ai')}><Sparkles size={16} /> AI</button>}
        <div className="flex-1" />
        <button className="btn-primary" onClick={() => setModal('export')} disabled={duration <= 0}><Download size={16} /> Export</button>
        <button className="btn-icon" onClick={() => setModal('settings')} aria-label="Settings"><Settings size={18} /></button>
      </header>

      <div className="hidden portrait:flex items-center gap-2 glass-sm px-3 py-2 text-xs text-amber-200 shrink-0">
        <span className="flex-1">Rotate your tablet to landscape for the full editor.</span>
        <button className="chip" onClick={goFullscreen}>Fullscreen</button>
      </div>

      <main className="flex-1 min-h-0 flex flex-col landscape:flex-row gap-2">
        <section className="glass flex-1 min-w-0 min-h-0 flex flex-col overflow-hidden p-2">
          <div className="flex-1 min-h-0 rounded-2xl bg-black/60 overflow-hidden">
            <CanvasPlayer
              project={project}
              clockRef={clockRef}
              playing={playing}
              suspended={exporting}
              pool={mediaPool}
              onTime={onTime}
              onEnded={onEnded}
            />
          </div>
          <div className="shrink-0 flex items-center gap-2 pt-2">
            <button className="btn-icon" onClick={() => seek(0)} aria-label="Back to start"><SkipBack size={18} /></button>
            <button className="btn-primary w-12 px-0" onClick={togglePlay} disabled={duration <= 0} aria-label={playing ? 'Pause' : 'Play'}>
              {playing ? <Pause size={18} /> : <Play size={18} />}
            </button>
            <span className="text-sm tabular-nums text-slate-200">
              {formatTime(time)} <span className="text-slate-500">/ {formatTime(duration)}</span>
            </span>
            <div className="flex-1" />
            <button className="btn-icon" onClick={goFullscreen} aria-label="Fullscreen"><Maximize size={18} /></button>
          </div>
        </section>

        <aside className="glass shrink-0 overflow-hidden w-full h-44 landscape:w-80 landscape:h-auto">
          <Inspector
            project={project}
            selected={selected}
            time={time}
            dispatch={dispatch}
            onSelect={setSelected}
            onSeek={seek}
            onSplit={doSplit}
            onDelete={doDelete}
          />
        </aside>
      </main>

      <section className="glass shrink-0 overflow-hidden h-[38%] min-h-[170px]">
        <Timeline
          project={project}
          time={time}
          duration={duration}
          playing={playing}
          selected={selected}
          onSelect={setSelected}
          onSeek={seek}
          onSplit={doSplit}
          onDelete={doDelete}
          dispatch={dispatch}
        />
      </section>

      <input ref={fileRef} type="file" multiple className="hidden" onChange={onFiles} />

      {modal === 'add' && (
        <Modal title="Add to your project" icon={<Plus size={18} className="text-cyan-300" />} onClose={closeModal}>
          <div className="grid gap-2">
            <button className="btn h-14 justify-start" onClick={() => pickFiles('video')}>
              <Film size={18} /> Video or photo <span className="text-xs text-slate-400">main track</span>
            </button>
            <button className="btn h-14 justify-start" onClick={() => pickFiles('overlay')}>
              <Layers size={18} /> Overlay <span className="text-xs text-slate-400">picture-in-picture</span>
            </button>
            <button className="btn h-14 justify-start" onClick={() => pickFiles('audio')}>
              <Music size={18} /> Audio or music <span className="text-xs text-slate-400">audio track</span>
            </button>
          </div>
        </Modal>
      )}
      {modal === 'captions' && <AutoCaptions project={project} dispatch={dispatch} onClose={closeModal} />}
      {modal === 'ai' && aiReady && (
        <AiModal
          settings={settings}
          project={project}
          time={time}
          duration={duration}
          dispatch={dispatch}
          onSeek={seek}
          onClose={closeModal}
        />
      )}
      {modal === 'settings' && (
        <SettingsDrawer settings={settings} update={updateSettings} onClose={closeModal} onFullscreen={goFullscreen} />
      )}
      {modal === 'export' && <ExportModal project={project} onClose={closeModal} onBusy={onExportBusy} />}

      {importing && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[60] glass-sm px-4 py-2 text-sm">Importing...</div>
      )}
      {toast && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[60] glass-sm px-4 py-2 text-sm max-w-[90vw]">{toast}</div>
      )}
    </div>
  );
}
