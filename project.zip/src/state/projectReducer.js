import { uid, clipDur, clipEnd } from '../utils/project';

export const emptyHistory = (project) => ({ past: [], present: project, future: [], base: null });

const sortSubs = (s) => [...s].sort((a, b) => a.start - b.start);
const trackEnd = (clips, track) =>
  clips.filter((c) => c.track === track).reduce((m, c) => Math.max(m, clipEnd(c)), 0);

// Moves everything that starts at/after `from` earlier by `delta` (ripple edit).
function shiftAfter(p, from, delta, exceptId) {
  return {
    ...p,
    clips: p.clips.map((c) => (c.id !== exceptId && c.start >= from - 0.001 ? { ...c, start: Math.max(0, c.start - delta) } : c)),
    subtitles: p.subtitles.map((s) =>
      s.start >= from - 0.001
        ? {
            ...s,
            start: Math.max(0, s.start - delta),
            end: Math.max(0.1, s.end - delta),
            words: s.words ? s.words.map((w) => ({ ...w, s: w.s - delta, e: w.e - delta })) : s.words,
          }
        : s,
    ),
  };
}

function updateSub(s, patch) {
  const ns = patch.start !== undefined ? patch.start : s.start;
  const ne = patch.end !== undefined ? patch.end : s.end;
  const next = { ...s, ...patch };
  if (s.words && patch.words === undefined && (ns !== s.start || ne !== s.end)) {
    const k = (ne - ns) / Math.max(0.01, s.end - s.start);
    next.words = s.words.map((w) => ({ ...w, s: ns + (w.s - s.start) * k, e: ns + (w.e - s.start) * k }));
  }
  return next;
}

export function applyAction(p, a) {
  switch (a.type) {
    case 'ADD_CLIP': {
      const c = a.clip;
      const start = typeof c.start === 'number' ? c.start : trackEnd(p.clips, c.track);
      return { ...p, clips: [...p.clips, { ...c, start }] };
    }
    case 'UPDATE_CLIP':
      return { ...p, clips: p.clips.map((c) => (c.id === a.id ? { ...c, ...a.patch } : c)) };
    case 'DELETE_CLIP': {
      const c = p.clips.find((x) => x.id === a.id);
      if (!c) return p;
      const q = { ...p, clips: p.clips.filter((x) => x.id !== a.id) };
      return a.ripple ? shiftAfter(q, clipEnd(c), clipDur(c)) : q;
    }
    case 'SPLIT': {
      const c = p.clips.find((x) => x.id === a.id);
      if (!c) return p;
      if (a.time <= c.start + 0.05 || a.time >= clipEnd(c) - 0.05) return p;
      const cut = c.inPoint + (a.time - c.start);
      const left = { ...c, outPoint: cut };
      const right = { ...c, id: a.newId || uid(), start: a.time, inPoint: cut };
      return { ...p, clips: p.clips.flatMap((x) => (x.id === c.id ? [left, right] : [x])) };
    }
    case 'TRIM_LEFT': {
      // remove everything left of the playhead
      const c = p.clips.find((x) => x.id === a.id);
      if (!c) return p;
      if (a.time <= c.start + 0.05 || a.time >= clipEnd(c) - 0.05) return p;
      const removed = a.time - c.start;
      const patch = a.ripple ? { inPoint: c.inPoint + removed } : { start: a.time, inPoint: c.inPoint + removed };
      const q = { ...p, clips: p.clips.map((x) => (x.id === c.id ? { ...x, ...patch } : x)) };
      return a.ripple ? shiftAfter(q, a.time, removed, c.id) : q;
    }
    case 'TRIM_RIGHT': {
      // remove everything right of the playhead
      const c = p.clips.find((x) => x.id === a.id);
      if (!c) return p;
      const end = clipEnd(c);
      if (a.time <= c.start + 0.05 || a.time >= end - 0.05) return p;
      const removed = end - a.time;
      const q = { ...p, clips: p.clips.map((x) => (x.id === c.id ? { ...x, outPoint: x.outPoint - removed } : x)) };
      return a.ripple ? shiftAfter(q, end, removed, c.id) : q;
    }
    case 'SET_FILTER':
      return { ...p, filter: { ...p.filter, ...a.patch } };
    case 'SET_ASPECT':
      return { ...p, aspect: a.aspect };
    case 'SET_SUBSTYLE':
      return { ...p, subStyle: { ...p.subStyle, ...a.patch } };
    case 'SET_SUBS':
      return { ...p, subtitles: sortSubs(a.subs) };
    case 'ADD_SUBS':
      return { ...p, subtitles: sortSubs([...p.subtitles, ...a.subs]) };
    case 'ADD_SUB':
      return { ...p, subtitles: sortSubs([...p.subtitles, a.sub]) };
    case 'UPDATE_SUB':
      return { ...p, subtitles: p.subtitles.map((s) => (s.id === a.id ? updateSub(s, a.patch) : s)) };
    case 'DELETE_SUB':
      return { ...p, subtitles: p.subtitles.filter((s) => s.id !== a.id) };
    case 'BATCH':
      return a.actions.reduce((acc, x) => applyAction(acc, x), p);
    default:
      return p;
  }
}

// History: live=true actions (drags, sliders) update the project without
// creating undo steps; END_GESTURE (or the next normal action) commits them as ONE step.
export function historyReducer(state, action) {
  switch (action.type) {
    case 'UNDO': {
      if (state.base) return { ...state, present: state.base, base: null };
      if (!state.past.length) return state;
      const prev = state.past[state.past.length - 1];
      return { past: state.past.slice(0, -1), present: prev, future: [state.present, ...state.future], base: null };
    }
    case 'REDO': {
      if (!state.future.length) return state;
      const next = state.future[0];
      return { past: [...state.past, state.present], present: next, future: state.future.slice(1), base: null };
    }
    case 'END_GESTURE': {
      if (!state.base) return state;
      return { past: [...state.past.slice(-99), state.base], present: state.present, future: [], base: null };
    }
    default: {
      const next = applyAction(state.present, action);
      if (next === state.present) return state;
      if (action.live) return { ...state, present: next, base: state.base || state.present };
      const flushed = state.base ? [...state.past, state.base] : state.past;
      return { past: [...flushed.slice(-99), state.present], present: next, future: [], base: null };
    }
  }
}
