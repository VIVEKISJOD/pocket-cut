import { uid, clipEnd, DEFAULT_FILTER, DEFAULT_SUB_STYLE } from '../utils/project';

export const initialProject = {
  clips: [],
  subtitles: [],
  aspect: '16:9',
  filter: { ...DEFAULT_FILTER },
  subStyle: { ...DEFAULT_SUB_STYLE },
};

export const initialHistory = { past: [], present: initialProject, future: [], base: null };

const sortSubs = (s) => [...s].sort((a, b) => a.start - b.start);
const trackEnd = (clips, track) =>
  clips.filter((c) => c.track === track).reduce((m, c) => Math.max(m, clipEnd(c)), 0);

export function applyAction(p, a) {
  switch (a.type) {
    case 'ADD_CLIP': {
      const c = a.clip;
      const start = typeof c.start === 'number' ? c.start : trackEnd(p.clips, c.track);
      return { ...p, clips: [...p.clips, { ...c, start }] };
    }
    case 'UPDATE_CLIP':
      return { ...p, clips: p.clips.map((c) => (c.id === a.id ? { ...c, ...a.patch } : c)) };
    case 'DELETE_CLIP':
      return { ...p, clips: p.clips.filter((c) => c.id !== a.id) };
    case 'SPLIT': {
      const c = p.clips.find((x) => x.id === a.id);
      if (!c) return p;
      const end = clipEnd(c);
      if (a.time <= c.start + 0.05 || a.time >= end - 0.05) return p;
      const cut = c.inPoint + (a.time - c.start);
      const left = { ...c, outPoint: cut };
      const right = { ...c, id: a.newId || uid(), start: a.time, inPoint: cut };
      return { ...p, clips: p.clips.flatMap((x) => (x.id === c.id ? [left, right] : [x])) };
    }
    case 'SET_FILTER':
      return { ...p, filter: { ...p.filter, ...a.patch } };
    case 'SET_ASPECT':
      return { ...p, aspect: a.aspect };
    case 'SET_SUBSTYLE':
      return { ...p, subStyle: { ...p.subStyle, ...a.patch } };
    case 'SET_SUBS':
      return { ...p, subtitles: sortSubs(a.subs) };
    case 'ADD_SUBS':
      return { ...p, subtitles: sortSubs([...p.subtitles, ...a.subs]) };
    case 'ADD_SUB':
      return { ...p, subtitles: sortSubs([...p.subtitles, a.sub]) };
    case 'UPDATE_SUB':
      return { ...p, subtitles: p.subtitles.map((s) => (s.id === a.id ? { ...s, ...a.patch } : s)) };
    case 'DELETE_SUB':
      return { ...p, subtitles: p.subtitles.filter((s) => s.id !== a.id) };
    case 'BATCH':
      return a.actions.reduce((acc, x) => applyAction(acc, x), p);
    default:
      return p;
  }
}

// History: live=true actions (drags, sliders) update the project without
// creating undo steps; END_GESTURE (or the next normal action) commits them as ONE step.
export function historyReducer(state, action) {
  switch (action.type) {
    case 'UNDO': {
      if (state.base) return { ...state, present: state.base, base: null };
      if (!state.past.length) return state;
      const prev = state.past[state.past.length - 1];
      return { past: state.past.slice(0, -1), present: prev, future: [state.present, ...state.future], base: null };
    }
    case 'REDO': {
      if (!state.future.length) return state;
      const next = state.future[0];
      return { past: [...state.past, state.present], present: next, future: state.future.slice(1), base: null };
    }
    case 'END_GESTURE': {
      if (!state.base) return state;
      return { past: [...state.past.slice(-99), state.base], present: state.present, future: [], base: null };
    }
    default: {
      const next = applyAction(state.present, action);
      if (next === state.present) return state;
      if (action.live) return { ...state, present: next, base: state.base || state.present };
      const flushed = state.base ? [...state.past, state.base] : state.past;
      return { past: [...flushed.slice(-99), state.present], present: next, future: [], base: null };
    }
  }
}
