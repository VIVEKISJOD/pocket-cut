import { flattenWords } from './captionUtils';
import { clipEnd, uid } from './project';

const FILLERS = new Set([
  'um', 'umm', 'ummm', 'uh', 'uhh', 'uhm', 'erm', 'er', 'ah', 'ahh', 'hmm', 'hm', 'hmmm', 'mm', 'mmm',
  'aa', 'aaa', 'aaaa', 'ahm', 'उम्म', 'अम्म', 'हम्म', 'उम', 'अं', 'आं', 'एम्म',
]);
const norm = (w) => String(w).toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');

function mergeRanges(ranges) {
  const rs = ranges.filter((r) => r[1] - r[0] > 0.05).sort((a, b) => a[0] - b[0]);
  const out = [];
  for (const r of rs) {
    const last = out[out.length - 1];
    if (last && r[0] <= last[1] + 0.25) last[1] = Math.max(last[1], r[1]);
    else out.push([r[0], r[1]]);
  }
  return out;
}

// Finds the parts of the main video that can be cut: long silences, "umm" sounds, repeated words.
export function findCutRanges(subs, clips, { silence = true, fillers = true, repeats = true, minGap = 0.7 } = {}) {
  const words = flattenWords(subs).sort((a, b) => a.s - b.s);
  const ranges = [];
  clips
    .filter((c) => c.track === 'video' && c.kind === 'video')
    .forEach((c) => {
      const cs = c.start;
      const ce = clipEnd(c);
      const ws = words.filter((w) => w.e > cs && w.s < ce);
      if (!ws.length) return; // no speech found: never cut a whole clip away
      if (silence) {
        let prev = cs;
        ws.forEach((w, i) => {
          if (w.s - prev > minGap) ranges.push([i === 0 ? prev : prev + 0.15, w.s - 0.15]);
          prev = Math.max(prev, w.e);
        });
        if (ce - prev > minGap) ranges.push([prev + 0.3, ce]);
      }
      if (fillers) {
        ws.forEach((w) => {
          if (FILLERS.has(norm(w.w)) && w.e - w.s < 2) ranges.push([w.s - 0.03, w.e + 0.05]);
        });
      }
      if (repeats) {
        for (let i = 0; i < ws.length - 1; i++) {
          const a = norm(ws[i].w);
          if (a.length >= 3 && a === norm(ws[i + 1].w) && ws[i + 1].s - ws[i].e < 0.5) {
            ranges.push([ws[i].s - 0.02, ws[i].e + 0.03]);
          }
        }
      }
    });
  return mergeRanges(ranges.map(([a, b]) => [Math.max(0, a), b]));
}

// Cuts the ranges out of the main video track and closes the gaps.
// Captions and overlay clips move with it. Music and sound effects are left alone.
export function applyCuts(p, ranges) {
  const rs = mergeRanges(ranges);
  if (!rs.length) return { project: p, removed: 0, cutTimes: [] };
  const removedBefore = (x) => {
    let s = 0;
    for (const [a, b] of rs) {
      if (x >= b) s += b - a;
      else if (x > a) s += x - a;
    }
    return s;
  };
  const m = (x) => x - removedBefore(x);
  const inside = (w) => rs.some(([a, b]) => w.s >= a - 0.001 && w.e <= b + 0.001);

  const clips = [];
  p.clips.forEach((c) => {
    if (c.track === 'video' && c.kind === 'video') {
      let cur = c.start;
      const end = clipEnd(c);
      const pieces = [];
      rs.forEach(([a, b]) => {
        if (b <= cur || a >= end) return;
        const ra = Math.max(a, cur);
        const rb = Math.min(b, end);
        if (ra > cur) pieces.push([cur, ra]);
        cur = rb;
      });
      if (cur < end) pieces.push([cur, end]);
      let first = true;
      pieces.forEach(([a, b]) => {
        if (b - a < 0.05) return;
        clips.push({
          ...c,
          id: first ? c.id : uid(),
          start: m(a),
          inPoint: c.inPoint + (a - c.start),
          outPoint: c.inPoint + (b - c.start),
        });
        first = false;
      });
    } else if (c.track === 'overlay') {
      clips.push({ ...c, start: m(c.start) });
    } else {
      clips.push(c);
    }
  });

  const subtitles = [];
  p.subtitles.forEach((s) => {
    if (s.words && s.words.length) {
      const kept = s.words.filter((w) => !inside(w)).map((w) => ({ ...w, s: m(w.s), e: m(w.e) }));
      if (!kept.length) return;
      const start = kept[0].s;
      const end = Math.max(kept[kept.length - 1].e + 0.05, m(s.end));
      subtitles.push({ ...s, start, end, text: kept.map((w) => w.w).join(' '), words: kept });
    } else {
      const start = m(s.start);
      const end = m(s.end);
      if (end - start >= 0.1) subtitles.push({ ...s, start, end });
    }
  });

  const removed = rs.reduce((n, r) => n + (r[1] - r[0]), 0);
  return { project: { ...p, clips, subtitles }, removed, cutTimes: rs.map(([a]) => m(a)) };
}
