const IMG_RE = /\.(jpe?g|png|gif|webp|bmp|avif)$/i;
const VID_RE = /\.(mp4|mov|m4v|webm|mkv|3gp)$/i;
const AUD_RE = /\.(mp3|wav|m4a|aac|ogg|oga|opus|flac)$/i;

function detectKind(file) {
  if (file.type.startsWith('image/')) return 'image';
  if (file.type.startsWith('video/')) return 'video';
  if (file.type.startsWith('audio/')) return 'audio';
  if (IMG_RE.test(file.name)) return 'image';
  if (VID_RE.test(file.name)) return 'video';
  if (AUD_RE.test(file.name)) return 'audio';
  return null;
}

// Reads a picked file and returns { kind, url, name, srcDuration, width, height, thumb }.
export function loadMediaFile(file) {
  const kind = detectKind(file);
  if (!kind) return Promise.reject(new Error(`"${file.name}" is not a video, photo or audio file.`));
  const url = URL.createObjectURL(file);
  const base = { kind, url, name: file.name };

  if (kind === 'image') {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        let thumb = null;
        try {
          const c = document.createElement('canvas');
          c.width = 192;
          c.height = 108;
          const g = c.getContext('2d');
          const s = Math.max(192 / img.naturalWidth, 108 / img.naturalHeight);
          g.drawImage(img, (192 - img.naturalWidth * s) / 2, (108 - img.naturalHeight * s) / 2, img.naturalWidth * s, img.naturalHeight * s);
          thumb = c.toDataURL('image/jpeg', 0.6);
        } catch { /* thumbnail is optional */ }
        resolve({ ...base, srcDuration: 5, width: img.naturalWidth, height: img.naturalHeight, thumb });
      };
      img.onerror = () => reject(new Error(`Can't read "${file.name}".`));
      img.src = url;
    });
  }

  return new Promise((resolve, reject) => {
    const el = document.createElement(kind === 'video' ? 'video' : 'audio');
    el.preload = 'auto';
    el.muted = true;
    el.playsInline = true;
    el.src = url;
    let done = false;
    let timer = null;
    const finish = (extra) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      resolve({ ...base, srcDuration: el.duration, width: el.videoWidth || 0, height: el.videoHeight || 0, thumb: null, ...extra });
    };
    const fail = (msg) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      reject(new Error(msg));
    };
    timer = setTimeout(() => {
      if (isFinite(el.duration) && el.duration > 0) finish({});
      else fail(`"${file.name}" took too long to load.`);
    }, 8000);
    el.onerror = () => fail(`Can't read "${file.name}" (unsupported format?).`);
    el.onloadedmetadata = () => {
      if (!isFinite(el.duration) || el.duration <= 0) return;
      if (kind === 'audio') return finish({});
      try { el.currentTime = Math.min(0.1, el.duration / 2); } catch { finish({}); }
    };
    el.onseeked = () => {
      let thumb = null;
      try {
        const c = document.createElement('canvas');
        c.width = 192;
        c.height = 108;
        const g = c.getContext('2d');
        const s = Math.max(192 / el.videoWidth, 108 / el.videoHeight);
        const dw = el.videoWidth * s;
        const dh = el.videoHeight * s;
        g.drawImage(el, (192 - dw) / 2, (108 - dh) / 2, dw, dh);
        thumb = c.toDataURL('image/jpeg', 0.6);
      } catch { /* thumbnail is optional */ }
      finish({ thumb });
    };
  });
}
