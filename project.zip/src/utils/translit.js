// Approximate Hindi (Devanagari) -> Roman letters ("Hinglish"), fully offline.
const VOW = {
  'अ': 'a', 'आ': 'aa', 'इ': 'i', 'ई': 'ee', 'उ': 'u', 'ऊ': 'oo', 'ऋ': 'ri', 'ए': 'e', 'ऐ': 'ai',
  'ओ': 'o', 'औ': 'au', 'ऑ': 'o', 'ऍ': 'e',
};
const MAT = {
  'ा': 'aa', 'ि': 'i', 'ी': 'ee', 'ु': 'u', 'ू': 'oo', 'ृ': 'ri', 'े': 'e', 'ै': 'ai',
  'ो': 'o', 'ौ': 'au', 'ॉ': 'o', 'ॅ': 'e',
};
const CON = {
  'क': 'k', 'ख': 'kh', 'ग': 'g', 'घ': 'gh', 'ङ': 'n', 'च': 'ch', 'छ': 'chh', 'ज': 'j', 'झ': 'jh', 'ञ': 'n',
  'ट': 't', 'ठ': 'th', 'ड': 'd', 'ढ': 'dh', 'ण': 'n', 'त': 't', 'थ': 'th', 'द': 'd', 'ध': 'dh', 'न': 'n',
  'प': 'p', 'फ': 'ph', 'ब': 'b', 'भ': 'bh', 'म': 'm', 'य': 'y', 'र': 'r', 'ल': 'l', 'व': 'v', 'श': 'sh',
  'ष': 'sh', 'स': 's', 'ह': 'h', 'ळ': 'l',
};
const NUKTA = '\u093C';
const NUK = { '\u0915': 'q', '\u0916': 'kh', '\u0917': 'g', '\u091C': 'z', '\u0921': 'd', '\u0922': 'rh', '\u092B': 'f' };
const HALANT = '\u094D';
const DIGITS = '\u0966\u0967\u0968\u0969\u096A\u096B\u096C\u096D\u096E\u096F';

function word(w) {
  const s = w.normalize('NFD');
  const tokens = []; // { t, inh }
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (CON[ch] !== undefined) {
      let c = CON[ch];
      if (s[i + 1] === NUKTA) {
        if (NUK[ch]) c = NUK[ch];
        i++;
      }
      const nx = s[i + 1];
      if (MAT[nx] !== undefined) {
        tokens.push({ t: c + MAT[nx], inh: false });
        i++;
      } else if (nx === HALANT) {
        tokens.push({ t: c, inh: false, bare: true });
        i++;
      } else {
        tokens.push({ t: c + 'a', inh: true });
      }
    } else if (VOW[ch] !== undefined) {
      tokens.push({ t: VOW[ch], inh: false });
    } else if (ch === '\u0902' || ch === '\u0901') {
      tokens.push({ t: 'n', inh: false, bare: true });
    } else if (ch === '\u0903') {
      tokens.push({ t: 'h', inh: false, bare: true });
    } else if (ch === '\u0964' || ch === '\u0965') {
      tokens.push({ t: '.', inh: false, bare: true });
    } else if (DIGITS.includes(ch)) {
      tokens.push({ t: String(DIGITS.indexOf(ch)), inh: false, bare: true });
    } else if (ch !== NUKTA) {
      tokens.push({ t: ch, inh: false, bare: true });
    }
  }
  // schwa deletion: word-final, and medial "VC(a)CV" patterns
  const last = tokens.length - 1;
  const deleted = new Set();
  tokens.forEach((tk, k) => {
    if (!tk.inh) return;
    if (k === last && last > 0) {
      deleted.add(k);
    } else if (k > 0 && k < last && !deleted.has(k - 1) && !tokens[k - 1].bare) {
      const nx = tokens[k + 1];
      if (nx && !nx.inh && !nx.bare) deleted.add(k);
    }
  });
  let out = tokens.map((tk, k) => (deleted.has(k) ? tk.t.slice(0, -1) : tk.t)).join('');
  out = out.replace(/aa$/, 'a').replace(/ee$/, 'i');
  return out;
}

export const hasDevanagari = (s) => /[\u0900-\u097F]/.test(s);
export const devToRoman = (text) => String(text).replace(/[\u0900-\u097F]+/g, word);
