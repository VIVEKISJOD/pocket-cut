// Saves projects and their media files on the device (IndexedDB).
const DB_NAME = 'pocketcut';
let dbp = null;

function open() {
  if (dbp) return dbp;
  dbp = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('projects')) db.createObjectStore('projects', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('media')) {
        const s = db.createObjectStore('media', { keyPath: 'id' });
        s.createIndex('projectId', 'projectId');
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => {
      dbp = null;
      reject(req.error);
    };
  });
  return dbp;
}

function run(store, mode, fn) {
  return open().then(
    (db) =>
      new Promise((resolve, reject) => {
        const tx = db.transaction(store, mode);
        const req = fn(tx.objectStore(store));
        tx.oncomplete = () => resolve(req ? req.result : undefined);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error);
      }),
  );
}

export const putProject = (rec) => run('projects', 'readwrite', (s) => s.put(rec));
export const getProject = (id) => run('projects', 'readonly', (s) => s.get(id));
export const listProjects = () =>
  run('projects', 'readonly', (s) => s.getAll()).then((a) => (a || []).sort((x, y) => y.updated - x.updated));
export const putMedia = (rec) => run('media', 'readwrite', (s) => s.put(rec));
export const getMedia = (id) => run('media', 'readonly', (s) => s.get(id));

export async function deleteProject(id) {
  const db = await open();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(['projects', 'media'], 'readwrite');
    tx.objectStore('projects').delete(id);
    const media = tx.objectStore('media');
    const req = media.index('projectId').openKeyCursor(IDBKeyRange.only(id));
    req.onsuccess = () => {
      const cur = req.result;
      if (cur) {
        media.delete(cur.primaryKey);
        cur.continue();
      }
    };
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

export async function clearAll() {
  const db = await open();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(['projects', 'media'], 'readwrite');
    tx.objectStore('projects').clear();
    tx.objectStore('media').clear();
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

export async function storageEstimate() {
  try {
    return await navigator.storage.estimate();
  } catch {
    return null;
  }
}

// Turns a stored project record into { project, urls } with playable media URLs.
export async function loadProjectMedia(record) {
  const urls = [];
  const clips = [];
  for (const c of record.data.clips) {
    let url = null;
    if (c.mediaId) {
      const m = await getMedia(c.mediaId);
      if (m && m.blob) {
        url = URL.createObjectURL(m.blob);
        urls.push(url);
      }
    }
    clips.push({ ...c, url, missing: !url });
  }
  return { project: { ...record.data, clips }, urls };
}

export function serializeProject(project) {
  return {
    ...project,
    clips: project.clips.map((c) => {
      const { url, missing, ...rest } = c; // eslint-disable-line no-unused-vars
      return rest;
    }),
  };
}
