import { audioBufferToWav } from './audio';

const SR = 44100;

function noise(ac, seconds) {
  const b = ac.createBuffer(1, Math.floor(SR * seconds), SR);
  const d = b.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  const s = ac.createBufferSource();
  s.buffer = b;
  return s;
}
function tone(ac, type, f0, f1, t0, dur, peak, out) {
  const o = ac.createOscillator();
  const g = ac.createGain();
  o.type = type;
  o.frequency.setValueAtTime(f0, t0);
  if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.linearRampToValueAtTime(peak, t0 + 0.005);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g);
  g.connect(out);
  o.start(t0);
  o.stop(t0 + dur + 0.05);
}

// Every sound is made on the device from scratch, so there is nothing to download or license.
export const SFX_LIST = [
  { id: 'whoosh', name: 'Whoosh', dur: 0.8 },
  { id: 'pop', name: 'Pop', dur: 0.3 },
  { id: 'ding', name: 'Ding', dur: 1.4 },
  { id: 'boom', name: 'Boom', dur: 1.3 },
  { id: 'click', name: 'Click', dur: 0.2 },
  { id: 'riser', name: 'Riser', dur: 1.7 },
  { id: 'tada', name: 'Ta-da', dur: 1.3 },
  { id: 'coin', name: 'Coin', dur: 0.6 },
];

function build(id, ac) {
  const out = ac.createGain();
  out.gain.value = 0.9;
  out.connect(ac.destination);
  if (id === 'whoosh' || id === 'riser') {
    const len = id === 'whoosh' ? 0.8 : 1.7;
    const n = noise(ac, len + 0.1);
    const f = ac.createBiquadFilter();
    const g = ac.createGain();
    f.type = 'bandpass';
    f.Q.value = 1.1;
    if (id === 'whoosh') {
      f.frequency.setValueAtTime(350, 0);
      f.frequency.exponentialRampToValueAtTime(5000, 0.35);
      f.frequency.exponentialRampToValueAtTime(500, 0.78);
      g.gain.setValueAtTime(0.0001, 0);
      g.gain.linearRampToValueAtTime(0.9, 0.3);
      g.gain.linearRampToValueAtTime(0.0001, 0.78);
    } else {
      f.frequency.setValueAtTime(200, 0);
      f.frequency.exponentialRampToValueAtTime(7000, 1.6);
      g.gain.setValueAtTime(0.0001, 0);
      g.gain.linearRampToValueAtTime(1, 1.6);
      g.gain.linearRampToValueAtTime(0.0001, 1.69);
    }
    n.connect(f);
    f.connect(g);
    g.connect(out);
    n.start(0);
  } else if (id === 'pop') {
    tone(ac, 'sine', 800, 160, 0, 0.14, 0.95, out);
  } else if (id === 'ding') {
    tone(ac, 'sine', 1318, 0, 0, 1.3, 0.6, out);
    tone(ac, 'sine', 1760, 0, 0, 1.0, 0.35, out);
  } else if (id === 'boom') {
    tone(ac, 'sine', 130, 34, 0, 0.9, 1, out);
    const n = noise(ac, 1.0);
    const f = ac.createBiquadFilter();
    const g = ac.createGain();
    f.type = 'lowpass';
    f.frequency.value = 260;
    g.gain.setValueAtTime(0.7, 0);
    g.gain.exponentialRampToValueAtTime(0.0001, 0.9);
    n.connect(f);
    f.connect(g);
    g.connect(out);
    n.start(0);
  } else if (id === 'click') {
    const n = noise(ac, 0.05);
    const f = ac.createBiquadFilter();
    const g = ac.createGain();
    f.type = 'highpass';
    f.frequency.value = 1800;
    g.gain.setValueAtTime(0.9, 0);
    g.gain.exponentialRampToValueAtTime(0.0001, 0.04);
    n.connect(f);
    f.connect(g);
    g.connect(out);
    n.start(0);
  } else if (id === 'tada') {
    [523.25, 659.25, 783.99].forEach((f, i) => tone(ac, 'triangle', f, 0, i * 0.12, 0.8, 0.55, out));
    tone(ac, 'triangle', 1046.5, 0, 0.36, 0.8, 0.5, out);
  } else if (id === 'coin') {
    tone(ac, 'square', 988, 0, 0, 0.09, 0.3, out);
    tone(ac, 'square', 1319, 0, 0.09, 0.45, 0.3, out);
  }
}

const cache = new Map();
export async function makeSfx(id) {
  if (cache.has(id)) return cache.get(id);
  const def = SFX_LIST.find((s) => s.id === id) || SFX_LIST[0];
  const OAC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  const ac = new OAC(1, Math.floor(SR * def.dur), SR);
  build(def.id, ac);
  const buf = await ac.startRendering();
  const file = new File([audioBufferToWav(buf)], `${def.name}.wav`, { type: 'audio/wav' });
  cache.set(id, file);
  return file;
}
