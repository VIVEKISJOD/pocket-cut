// Runs Whisper (whisper-tiny) fully inside the browser, in a Web Worker.
// The model files download once from Hugging Face, then are cached for offline use.
import { pipeline, env } from '@xenova/transformers';

env.allowLocalModels = false;
env.useBrowserCache = true;
env.backends.onnx.wasm.numThreads = 1; // no SharedArrayBuffer needed on free hosting
env.backends.onnx.wasm.proxy = false;

let transcriberPromise = null;

function getTranscriber(id) {
  if (!transcriberPromise) {
    transcriberPromise = pipeline('automatic-speech-recognition', 'Xenova/whisper-tiny', {
      quantized: true,
      progress_callback: (data) => self.postMessage({ type: 'progress', id, data }),
    }).catch((err) => {
      transcriberPromise = null;
      throw err;
    });
  }
  return transcriberPromise;
}

const MAX_WORDS = 7;
const MAX_CHARS = 38;

function splitText(text) {
  const words = text.split(/\s+/).filter(Boolean);
  const groups = [];
  if (words.length <= 1 && text.length > 24) {
    // languages written without spaces: cut by characters
    for (let i = 0; i < text.length; i += 18) groups.push(text.slice(i, i + 18));
    return groups;
  }
  let cur = [];
  let chars = 0;
  for (const w of words) {
    if (cur.length && (cur.length >= MAX_WORDS || chars + w.length + 1 > MAX_CHARS)) {
      groups.push(cur.join(' '));
      cur = [];
      chars = 0;
    }
    cur.push(w);
    chars += w.length + 1;
  }
  if (cur.length) groups.push(cur.join(' '));
  return groups;
}

function chunksToBlocks(chunks, totalDur) {
  const blocks = [];
  let prevEnd = 0;
  for (const ch of chunks) {
    const text = String(ch.text || '').trim();
    if (!text || !/[\p{L}\p{N}]/u.test(text) || /^[\[(].*[\])]$/.test(text)) continue;
    const ts = ch.timestamp || [];
    const start = typeof ts[0] === 'number' ? ts[0] : prevEnd;
    const wordCount = text.split(/\s+/).length;
    let end = typeof ts[1] === 'number' ? ts[1] : Math.min(totalDur, start + wordCount * 0.45);
    if (end < start + 0.3) end = start + 0.3;
    prevEnd = end;
    const parts = splitText(text);
    const totalChars = parts.reduce((n, p) => n + p.length, 0) || 1;
    let t = start;
    parts.forEach((p, i) => {
      const d = ((end - start) * p.length) / totalChars;
      blocks.push({ start: t, end: i === parts.length - 1 ? end : t + d, text: p });
      t += d;
    });
  }
  return blocks;
}

self.addEventListener('message', async (e) => {
  const { type, id, audio, language } = e.data;
  if (type !== 'transcribe') return;
  try {
    const transcriber = await getTranscriber(id);
    self.postMessage({ type: 'progress', id, data: { status: 'transcribing' } });
    const opts = { chunk_length_s: 30, stride_length_s: 5, return_timestamps: true, task: 'transcribe' };
    if (language && language !== 'auto') opts.language = language;
    const out = await transcriber(audio, opts);
    const totalDur = audio.length / 16000;
    const chunks = out.chunks && out.chunks.length ? out.chunks : [{ text: out.text, timestamp: [0, totalDur] }];
    self.postMessage({ type: 'result', id, blocks: chunksToBlocks(chunks, totalDur) });
  } catch (err) {
    self.postMessage({ type: 'error', id, message: String((err && err.message) || err) });
  }
});
