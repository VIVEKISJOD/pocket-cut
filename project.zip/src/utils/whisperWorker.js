// Runs Whisper fully inside the browser, in a Web Worker.
// Model files download once from Hugging Face, then are cached for offline use.
import { pipeline, env } from '@xenova/transformers';

env.allowLocalModels = false;
env.useBrowserCache = true;
env.backends.onnx.wasm.numThreads = 1; // no SharedArrayBuffer needed on free hosting
env.backends.onnx.wasm.proxy = false;

const pipes = new Map();

function getPipe(model, id) {
  if (!pipes.has(model)) {
    pipes.set(
      model,
      pipeline('automatic-speech-recognition', model, {
        quantized: true,
        progress_callback: (data) => self.postMessage({ type: 'progress', id, data }),
      }).catch((err) => {
        pipes.delete(model);
        throw err;
      }),
    );
  }
  return pipes.get(model);
}

const hasText = (t) => /[\p{L}\p{N}]/u.test(t) && !/^[\[(].*[\])]$/.test(t);

// Whisper sometimes loops on one word; keep at most 3 repeats in a row.
function dedupe(words) {
  const out = [];
  let run = 0;
  for (const w of words) {
    const prev = out[out.length - 1];
    if (prev && prev.w.toLowerCase() === w.w.toLowerCase()) run++;
    else run = 0;
    if (run < 3) out.push(w);
  }
  return out;
}

function wordChunks(chunks) {
  const words = [];
  let prevEnd = 0;
  for (const ch of chunks) {
    const w = String(ch.text || '').trim();
    if (!w || !hasText(w)) continue;
    const ts = ch.timestamp || [];
    const s = typeof ts[0] === 'number' ? ts[0] : prevEnd;
    let e = typeof ts[1] === 'number' ? ts[1] : s + 0.3;
    if (e < s + 0.08) e = s + 0.08;
    prevEnd = e;
    words.push({ w, s, e });
  }
  return dedupe(words);
}

function segmentWords(chunks, totalDur) {
  const words = [];
  let prevEnd = 0;
  for (const ch of chunks) {
    const text = String(ch.text || '').trim();
    if (!text || !hasText(text)) continue;
    const ts = ch.timestamp || [];
    const s = typeof ts[0] === 'number' ? ts[0] : prevEnd;
    const parts = text.split(/\s+/).filter(Boolean);
    let e = typeof ts[1] === 'number' ? ts[1] : Math.min(totalDur, s + parts.length * 0.45);
    if (e < s + 0.3) e = s + 0.3;
    prevEnd = e;
    const total = parts.reduce((n, p) => n + p.length + 1, 0) || 1;
    let t = s;
    parts.forEach((p) => {
      const d = ((e - s) * (p.length + 1)) / total;
      words.push({ w: p, s: t, e: t + d });
      t += d;
    });
  }
  return dedupe(words);
}

self.addEventListener('message', async (ev) => {
  const { type, id, audio, language, model } = ev.data;
  if (type !== 'transcribe') return;
  try {
    const transcriber = await getPipe(model, id);
    self.postMessage({ type: 'progress', id, data: { status: 'transcribing' } });
    const base = { chunk_length_s: 30, stride_length_s: 5, task: 'transcribe' };
    if (language && language !== 'auto') base.language = language;
    const totalDur = audio.length / 16000;
    let words;
    let fallback = false;
    try {
      // word-level timestamps: much better caption timing
      const out = await transcriber(audio, { ...base, return_timestamps: 'word' });
      words = wordChunks(out.chunks || []);
      if (!words.length) throw new Error('no words');
    } catch {
      fallback = true;
      const out = await transcriber(audio, { ...base, return_timestamps: true });
      const chunks = out.chunks && out.chunks.length ? out.chunks : [{ text: out.text, timestamp: [0, totalDur] }];
      words = segmentWords(chunks, totalDur);
    }
    self.postMessage({ type: 'result', id, words, fallback });
  } catch (err) {
    self.postMessage({ type: 'error', id, message: String((err && err.message) || err) });
  }
});
