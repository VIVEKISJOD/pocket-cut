import { useCallback, useEffect, useState } from 'react';
import { FREE_MODELS } from '../services/openrouter';

const KEY = 'pocketcut.settings.v1';
const DEFAULTS = { aiEnabled: false, apiKey: '', model: FREE_MODELS[0].id, remember: true };

export function useSettings() {
  const [settings, setSettings] = useState(() => {
    try {
      const raw = localStorage.getItem(KEY);
      return { ...DEFAULTS, ...(raw ? JSON.parse(raw) : {}) };
    } catch {
      return { ...DEFAULTS };
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify({ ...settings, apiKey: settings.remember ? settings.apiKey : '' }));
    } catch { /* storage may be blocked */ }
  }, [settings]);
  const update = useCallback((patch) => setSettings((s) => ({ ...s, ...patch })), []);
  return [settings, update];
}
