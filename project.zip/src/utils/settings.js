import { useCallback, useEffect, useState } from 'react';
import { FREE_MODELS } from '../services/openrouter';

const KEY = 'pocketcut.settings.v2';

export const DEFAULTS = {
  // AI
  aiEnabled: false, apiKey: '', model: FREE_MODELS[0].id, remember: true, giphyKey: '',
  // look
  theme: 'midnight', glass: 0.6, blurOn: true,
  // editing
  holdToDrag: true, holdMs: 2000, haptics: true, snap: true, ripple: false, confirmDelete: true,
  showThumbs: true, autoSave: true, loopPlayback: false,
  // preview
  previewScale: 0.75, previewFps: 60, showGrid: false,
  // captions
  captionLang: 'auto', captionModel: 'Xenova/whisper-base', captionWords: 5,
  // export
  exportRes: 1080, exportFps: 30, exportQuality: 'high', exportEngine: 'studio',
};

export function useSettings() {
  const [settings, setSettings] = useState(() => {
    try {
      const raw = localStorage.getItem(KEY);
      return { ...DEFAULTS, ...(raw ? JSON.parse(raw) : {}) };
    } catch {
      return { ...DEFAULTS };
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify({ ...settings, apiKey: settings.remember ? settings.apiKey : '' }));
    } catch { /* storage may be blocked */ }
  }, [settings]);
  const update = useCallback((patch) => setSettings((s) => ({ ...s, ...patch })), []);
  const reset = useCallback(() => setSettings((s) => ({ ...DEFAULTS, apiKey: s.apiKey, giphyKey: s.giphyKey, aiEnabled: s.aiEnabled, remember: s.remember })), []);
  return [settings, update, reset];
}
