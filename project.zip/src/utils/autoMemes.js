import { downloadAsFile, imgflipTemplates } from '../services/memes';

// Words (English, Hinglish and Hindi) that hint at a feeling, and meme templates that fit it.
const RULES = [
  { re: /\b(wow|omg|shock\w*|surpris\w*|unbelievable|no way|kya baat|arre|are bhai|oh my)\b|चौंक|हैरान/i, names: ['surprised pikachu', 'shocked', 'oprah'] },
  { re: /\b(win|won|jeet\w*|best|zabardast|badhiya|congrat\w*|success\w*|finally|mast)\b|जीत|बधाई/i, names: ['success kid', 'leonardo dicaprio cheers', 'bernie'] },
  { re: /\b(fail\w*|galat|problem|mistake|oops|dikkat|barbaad|gadbad|bug|error|disaster)\b|गलत|दिक्कत/i, names: ['this is fine', 'disaster girl', 'hide the pain'] },
  { re: /\b(think|socho|soch|idea|plan|smart|brain|dimaag|trick|hack|secret)\b|सोच|दिमाग/i, names: ['roll safe', 'expanding brain', 'galaxy brain'] },
  { re: /\b(angry|gussa|hate|nafrat|stop|bakwas|pagal|crazy)\b|गुस्सा|पागल/i, names: ['woman yelling', 'batman slapping', 'angry'] },
  { re: /\b(funny|lol|haha\w*|hasi|mazak|joke|comedy|laugh\w*)\b|हँस|मज़ाक|मजाक/i, names: ['laughing', 'mocking spongebob', 'evil kermit'] },
  { re: /\b(vs|versus|choose|choice|better than|option|ya phir)\b|चुन/i, names: ['drake', 'two buttons', 'change my mind'] },
  { re: /\b(wait\w*|intezaar|late|slow|forever)\b|इंतज़ार|इंतजार/i, names: ['waiting skeleton', 'waiting'] },
  { re: /\b(love|pyar|ishq|crush|girlfriend|boyfriend|date)\b|प्यार|इश्क/i, names: ['distracted boyfriend', 'is this a pigeon'] },
  { re: /\b(money|paisa|paise|rich|cash|crore|lakh|salary|kamai)\b|पैसा|पैसे|करोड़|कमाई/i, names: ['money', 'rich', 'success kid'] },
];

// Looks through the captions and picks moments where a meme would fit.
export function findMemeMoments(subs, max = 4, spacing = 6) {
  const out = [];
  let last = -999;
  for (const s of subs) {
    if (out.length >= max) break;
    if (s.start < 1.5 || s.start - last < spacing) continue;
    const rule = RULES.find((r) => r.re.test(s.text));
    if (rule) {
      out.push({ time: s.start, rule, text: s.text });
      last = s.start;
    }
  }
  return out;
}

// Downloads a template for each moment. Anything that cannot be downloaded is skipped.
export async function fetchMemesFor(moments, onPhase = () => {}) {
  const templates = await imgflipTemplates();
  const used = new Set();
  const found = [];
  for (let i = 0; i < moments.length; i++) {
    const mo = moments[i];
    const hit = mo.rule.names
      .map((n) => templates.find((t) => !used.has(t.id) && t.title.toLowerCase().includes(n)))
      .find(Boolean);
    if (!hit) continue;
    onPhase(`Downloading meme ${i + 1} of ${moments.length}...`);
    try {
      const file = await downloadAsFile(hit);
      used.add(hit.id);
      found.push({ file, time: mo.time, title: hit.title });
    } catch { /* skip memes that cannot be downloaded */ }
  }
  return found;
}
