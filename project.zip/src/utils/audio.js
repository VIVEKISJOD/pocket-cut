function resampleLinear(data, from, to) {
  if (from === to) return data;
  const ratio = from / to;
  const n = Math.floor(data.length / ratio);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const pos = i * ratio;
    const i0 = Math.floor(pos);
    const i1 = Math.min(i0 + 1, data.length - 1);
    const f = pos - i0;
    out[i] = data[i0] * (1 - f) + data[i1] * f;
  }
  return out;
}

// Decodes a media file's audio and returns the [inPoint, outPoint] slice as
// 16 kHz mono Float32Array (what Whisper needs).
export async function extractAudio16k(url, inPoint, outPoint) {
  const res = await fetch(url);
  const buf = await res.arrayBuffer();
  const OAC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  const ctx = new OAC(1, 16000, 16000);
  let decoded;
  try {
    decoded = await ctx.decodeAudioData(buf);
  } catch {
    throw new Error('This clip has no readable audio track.');
  }
  const sr = decoded.sampleRate;
  const start = Math.max(0, Math.floor(inPoint * sr));
  const end = Math.min(decoded.length, Math.floor(outPoint * sr));
  const len = Math.max(0, end - start);
  const mono = new Float32Array(len);
  const ch = decoded.numberOfChannels;
  for (let c = 0; c < ch; c++) {
    const d = decoded.getChannelData(c);
    for (let i = 0; i < len; i++) mono[i] += d[start + i] / ch;
  }
  return resampleLinear(mono, sr, 16000);
}

// Loudness per 20 ms. Used to snap captions to where the voice really starts/stops.
export function computeEnvelope(a) {
  const hop = 320;
  const n = Math.floor(a.length / hop);
  const rms = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0;
    const o = i * hop;
    for (let j = 0; j < hop; j++) {
      const v = a[o + j];
      s += v * v;
    }
    rms[i] = Math.sqrt(s / hop);
  }
  const sorted = Array.from(rms).sort((x, y) => x - y);
  const q = (p) => sorted[Math.min(n - 1, Math.floor(p * n))] || 0;
  const noise = q(0.2);
  const peak = q(0.95);
  return { hop: 0.02, rms, thr: noise + (peak - noise) * 0.12 };
}

export function findOnset(env, lo, hi) {
  const a = Math.max(0, Math.floor(lo / env.hop));
  const b = Math.min(env.rms.length - 3, Math.floor(hi / env.hop));
  for (let i = a; i <= b; i++) {
    if (env.rms[i] > env.thr && env.rms[i + 1] > env.thr && env.rms[i + 2] > env.thr) return i * env.hop;
  }
  return null;
}

export function findOffset(env, lo, hi) {
  const a = Math.max(2, Math.floor(lo / env.hop));
  const b = Math.min(env.rms.length - 1, Math.floor(hi / env.hop));
  for (let i = b; i >= a; i--) {
    if (env.rms[i] > env.thr && env.rms[i - 1] > env.thr && env.rms[i - 2] > env.thr) return (i + 1) * env.hop;
  }
  return null;
}

// Mono 16-bit WAV (seekable, has a real duration) from a decoded recording.
export function audioBufferToWav(buf) {
  const ch = buf.numberOfChannels;
  const len = buf.length;
  const sr = buf.sampleRate;
  const mono = new Float32Array(len);
  for (let c = 0; c < ch; c++) {
    const d = buf.getChannelData(c);
    for (let i = 0; i < len; i++) mono[i] += d[i] / ch;
  }
  const ab = new ArrayBuffer(44 + len * 2);
  const v = new DataView(ab);
  const ws = (o, s) => {
    for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i));
  };
  ws(0, 'RIFF');
  v.setUint32(4, 36 + len * 2, true);
  ws(8, 'WAVE');
  ws(12, 'fmt ');
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true);
  v.setUint16(22, 1, true);
  v.setUint32(24, sr, true);
  v.setUint32(28, sr * 2, true);
  v.setUint16(32, 2, true);
  v.setUint16(34, 16, true);
  ws(36, 'data');
  v.setUint32(40, len * 2, true);
  let o = 44;
  for (let i = 0; i < len; i++, o += 2) {
    const s = Math.max(-1, Math.min(1, mono[i]));
    v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Blob([ab], { type: 'audio/wav' });
}
