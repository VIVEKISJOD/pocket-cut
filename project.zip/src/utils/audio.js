function resampleLinear(data, from, to) {
  if (from === to) return data;
  const ratio = from / to;
  const n = Math.floor(data.length / ratio);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const pos = i * ratio;
    const i0 = Math.floor(pos);
    const i1 = Math.min(i0 + 1, data.length - 1);
    const f = pos - i0;
    out[i] = data[i0] * (1 - f) + data[i1] * f;
  }
  return out;
}

// Decodes a media file's audio with the Web Audio API and returns the
// [inPoint, outPoint] slice as 16 kHz mono Float32Array (what Whisper needs).
export async function extractAudio16k(url, inPoint, outPoint) {
  const res = await fetch(url);
  const buf = await res.arrayBuffer();
  const OAC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  const ctx = new OAC(1, 16000, 16000);
  let decoded;
  try {
    decoded = await ctx.decodeAudioData(buf);
  } catch {
    throw new Error('This clip has no readable audio track.');
  }
  const sr = decoded.sampleRate;
  const start = Math.max(0, Math.floor(inPoint * sr));
  const end = Math.min(decoded.length, Math.floor(outPoint * sr));
  const len = Math.max(0, end - start);
  const mono = new Float32Array(len);
  const ch = decoded.numberOfChannels;
  for (let c = 0; c < ch; c++) {
    const d = decoded.getChannelData(c);
    for (let i = 0; i < len; i++) mono[i] += d[start + i] / ch;
  }
  return resampleLinear(mono, sr, 16000);
}
