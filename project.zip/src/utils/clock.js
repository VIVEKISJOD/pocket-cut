import { useEffect, useState } from 'react';

// Shared playback clock. Playback time lives here (not in React state) so the
// playhead and time labels can update without re-rendering the whole editor.
const listeners = new Set();

export const clock = {
  time: 0,
  version: 0, // bumps whenever something visible may have changed
  playing: false,
  set(t) {
    this.time = t;
    this.version++;
    this.emit();
  },
  advance(t) {
    this.time = t;
    this.emit();
  },
  bump() {
    this.version++;
  },
  emit() {
    listeners.forEach((fn) => fn(this.time));
  },
  subscribe(fn) {
    listeners.add(fn);
    return () => listeners.delete(fn);
  },
};

export function useClockTime(ms = 80) {
  const [t, setT] = useState(clock.time);
  useEffect(() => {
    let last = 0;
    let timer = 0;
    const unsub = clock.subscribe((time) => {
      const now = performance.now();
      clearTimeout(timer);
      if (now - last >= ms) {
        last = now;
        setT(time);
      } else {
        timer = setTimeout(() => {
          last = performance.now();
          setT(clock.time);
        }, ms);
      }
    });
    setT(clock.time);
    return () => {
      unsub();
      clearTimeout(timer);
    };
  }, [ms]);
  return t;
}
