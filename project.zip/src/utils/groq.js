// Optional online speech recognition: Groq's free Whisper large-v3.
// Much more accurate for Hindi / Hinglish than the small models that run on the tablet.
const URL_TX = 'https://api.groq.com/openai/v1/audio/transcriptions';
const URL_TR = 'https://api.groq.com/openai/v1/audio/translations';
const CODES = {
  hindi: 'hi', hinglish: 'hi', english: 'en', urdu: 'ur', bengali: 'bn', spanish: 'es', french: 'fr', german: 'de',
  portuguese: 'pt', arabic: 'ar', russian: 'ru', japanese: 'ja', korean: 'ko', chinese: 'zh', indonesian: 'id', turkish: 'tr',
};
const HINGLISH_PROMPT = 'Yeh ek Hinglish video hai. Hindi bolchaal ko English letters mein likho, jaise: kya haal hai, main theek hoon, aaj hum kuch mast karenge.';
const CHUNK = 16000 * 480; // 8 minutes per request keeps the file under the free size limit

function wavFromFloat(a) {
  const ab = new ArrayBuffer(44 + a.length * 2);
  const v = new DataView(ab);
  const ws = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  ws(0, 'RIFF'); v.setUint32(4, 36 + a.length * 2, true); ws(8, 'WAVE'); ws(12, 'fmt ');
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, 16000, true); v.setUint32(28, 32000, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  ws(36, 'data'); v.setUint32(40, a.length * 2, true);
  let o = 44;
  for (let i = 0; i < a.length; i++, o += 2) {
    const s = Math.max(-1, Math.min(1, a[i]));
    v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Blob([ab], { type: 'audio/wav' });
}

async function oneRequest({ key, audio, language, hinglish, translate }) {
  const fd = new FormData();
  fd.append('file', new File([wavFromFloat(audio)], 'audio.wav', { type: 'audio/wav' }));
  fd.append('model', 'whisper-large-v3');
  fd.append('response_format', 'verbose_json');
  fd.append('timestamp_granularities[]', 'word');
  fd.append('temperature', '0');
  if (!translate && CODES[language]) fd.append('language', CODES[language]);
  if (hinglish && !translate) fd.append('prompt', HINGLISH_PROMPT);
  let res;
  try {
    res = await fetch(translate ? URL_TR : URL_TX, { method: 'POST', headers: { Authorization: `Bearer ${key}` }, body: fd });
  } catch {
    throw new Error('Could not reach Groq. Check your internet connection.');
  }
  let j = null;
  try { j = await res.json(); } catch { /* ignore */ }
  if (!res.ok) {
    if (res.status === 401) throw new Error('Groq did not accept the key. Check it in Settings.');
    if (res.status === 429) throw new Error('Groq free limit reached for now. Wait a minute and try again, or use the on-device engine.');
    throw new Error((j && j.error && j.error.message) || `Groq error ${res.status}.`);
  }
  return j || {};
}

// Returns words [{ w, s, e }] in seconds from the start of `audio` (16 kHz mono).
export async function transcribeGroq({ key, audio, language, hinglish, translate }) {
  const words = [];
  for (let off = 0; off < audio.length; off += CHUNK) {
    const part = audio.subarray(off, Math.min(audio.length, off + CHUNK));
    if (part.length < 4800) continue;
    const base = off / 16000;
    const j = await oneRequest({ key, audio: part, language, hinglish, translate });
    if (Array.isArray(j.words) && j.words.length) {
      j.words.forEach((w) => {
        const t = String(w.word || '').trim();
        if (t) words.push({ w: t, s: base + w.start, e: base + Math.max(w.end, w.start + 0.08) });
      });
    } else {
      (j.segments || []).forEach((sg) => {
        const parts = String(sg.text || '').trim().split(/\s+/).filter(Boolean);
        const total = parts.reduce((n, p) => n + p.length + 1, 0) || 1;
        let t = sg.start;
        parts.forEach((p) => {
          const d = ((sg.end - sg.start) * (p.length + 1)) / total;
          words.push({ w: p, s: base + t, e: base + t + d });
          t += d;
        });
      });
    }
  }
  return words;
}
