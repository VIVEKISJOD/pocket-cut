import { clamp, clipEnd, hexToRgba, projectDuration } from './project';

const SUPPORTS_FILTER =
  typeof CanvasRenderingContext2D !== 'undefined' && 'filter' in CanvasRenderingContext2D.prototype;

export const isDefaultFilter = (f) =>
  f.brightness === 100 && f.contrast === 100 && f.saturation === 100 && f.hue === 0 && f.sepia === 0 && f.grayscale === 0;

export const buildFilter = (f) =>
  isDefaultFilter(f)
    ? 'none'
    : `brightness(${f.brightness}%) contrast(${f.contrast}%) saturate(${f.saturation}%) hue-rotate(${f.hue}deg) sepia(${f.sepia}%) grayscale(${f.grayscale}%)`;

// Keeps every clip's media element at the right position for timeline time t.
export function syncMedia(project, t, playing, pool) {
  for (const clip of project.clips) {
    const entry = pool.get(clip);
    if (clip.kind === 'image') continue;
    const el = entry.el;
    if (entry.gain) entry.gain.gain.value = clip.volume == null ? 1 : clip.volume;
    const active = t >= clip.start && t < clipEnd(clip);
    if (active) {
      const want = clip.inPoint + (t - clip.start);
      if (playing) {
        if (Math.abs(el.currentTime - want) > 0.25) el.currentTime = want;
        if (el.paused) el.play().catch(() => {});
      } else {
        if (!el.paused) el.pause();
        if (Math.abs(el.currentTime - want) > 0.04) el.currentTime = want;
      }
    } else {
      if (!el.paused) el.pause();
      // pre-position clips that start very soon so cuts do not flash black
      if (t < clip.start && clip.start - t < 0.6 && Math.abs(el.currentTime - clip.inPoint) > 0.1) {
        el.currentTime = clip.inPoint;
      }
    }
  }
}

function drawClip(ctx, clip, entry, box) {
  const el = entry.el;
  let sw;
  let sh;
  if (entry.kind === 'image') {
    sw = el.naturalWidth;
    sh = el.naturalHeight;
  } else {
    if (el.readyState < 2) return;
    sw = el.videoWidth;
    sh = el.videoHeight;
  }
  if (!sw || !sh) return;
  const s = clip.fit === 'cover' ? Math.max(box.w / sw, box.h / sh) : Math.min(box.w / sw, box.h / sh);
  const dw = sw * s;
  const dh = sh * s;
  ctx.save();
  ctx.beginPath();
  ctx.rect(box.x, box.y, box.w, box.h);
  ctx.clip();
  ctx.drawImage(el, box.x + (box.w - dw) / 2, box.y + (box.h - dh) / 2, dw, dh);
  ctx.restore();
}

function roundRect(ctx, x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function drawSubtitle(ctx, w, h, sub, t, st) {
  const fontPx = Math.max(10, Math.round((h * st.size) / 100));
  ctx.font = `700 ${fontPx}px ${st.font}`;
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'left';
  const words = [];
  String(sub.text || '').split('\n').forEach((para, pi) => {
    para.split(/\s+/).filter(Boolean).forEach((word, wi) => {
      words.push({ word, br: pi > 0 && wi === 0, ww: ctx.measureText(word).width });
    });
  });
  if (!words.length) return;
  const space = ctx.measureText(' ').width;
  const maxW = w * 0.88;
  const lines = [];
  let cur = null;
  words.forEach((wd, i) => {
    wd.i = i;
    if (!cur || wd.br || cur.width + space + wd.ww > maxW) {
      cur = { items: [wd], width: wd.ww };
      lines.push(cur);
    } else {
      cur.items.push(wd);
      cur.width += space + wd.ww;
    }
  });
  const total = words.reduce((n, x) => n + x.word.length + 1, 0);
  const prog = clamp((t - sub.start) / Math.max(0.01, sub.end - sub.start), 0, 1) * total;
  let acc = 0;
  let active = words.length - 1;
  for (let i = 0; i < words.length; i++) {
    acc += words[i].word.length + 1;
    if (acc >= prog) { active = i; break; }
  }
  const lineH = fontPx * 1.3;
  const padX = st.pill ? fontPx * 0.7 : 0;
  const padY = st.pill ? fontPx * 0.4 : 0;
  const bw = Math.max(...lines.map((l) => l.width)) + padX * 2;
  const bh = lines.length * lineH + padY * 2;
  const bx = (w - bw) / 2;
  const by = st.position === 'top' ? h * 0.07 : st.position === 'middle' ? (h - bh) / 2 : h - bh - h * 0.07;
  if (st.pill) {
    ctx.fillStyle = hexToRgba(st.bg, st.bgOpacity);
    roundRect(ctx, bx, by, bw, bh, fontPx * 0.6);
    ctx.fill();
  }
  lines.forEach((ln, li) => {
    let x = (w - ln.width) / 2;
    const y = by + padY + li * lineH + lineH / 2;
    ln.items.forEach((wd) => {
      if (!st.pill) {
        ctx.lineJoin = 'round';
        ctx.lineWidth = fontPx * 0.16;
        ctx.strokeStyle = 'rgba(0,0,0,0.85)';
        ctx.strokeText(wd.word, x, y);
      }
      ctx.fillStyle = st.highlightOn && wd.i === active ? st.highlight : st.color;
      ctx.fillText(wd.word, x, y);
      x += wd.ww + space;
    });
  });
}

export function renderFrame(ctx, w, h, project, t, pool, opts = {}) {
  const dur = projectDuration(project);
  const tt = dur > 0 ? Math.min(t, dur - 0.001) : t;
  ctx.save();
  ctx.filter = 'none';
  ctx.globalAlpha = 1;
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, w, h);

  const order = { video: 0, overlay: 1 };
  const visual = project.clips
    .filter((c) => (c.track === 'video' || c.track === 'overlay') && tt >= c.start && tt < clipEnd(c))
    .sort((a, b) => order[a.track] - order[b.track] || a.start - b.start);

  const full = { x: 0, y: 0, w, h };
  const pw = w * 0.34;
  const ph = h * 0.34;
  const pip = { x: w - pw - w * 0.03, y: h * 0.05, w: pw, h: ph };

  if (SUPPORTS_FILTER) ctx.filter = buildFilter(project.filter);
  let hasPip = false;
  for (const c of visual) {
    const isPip = c.track === 'overlay';
    if (isPip) hasPip = true;
    drawClip(ctx, c, pool.get(c), isPip ? pip : full);
  }
  ctx.filter = 'none';

  if (hasPip) {
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.lineWidth = Math.max(2, w * 0.003);
    ctx.strokeRect(pip.x, pip.y, pip.w, pip.h);
  }

  const v = project.filter.vignette;
  if (v > 0) {
    const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.25, w / 2, h / 2, Math.hypot(w, h) / 2);
    g.addColorStop(0, 'rgba(0,0,0,0)');
    g.addColorStop(1, `rgba(0,0,0,${(v / 100) * 0.9})`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }

  const sub = project.subtitles.find((s) => tt >= s.start && tt < s.end);
  if (sub) drawSubtitle(ctx, w, h, sub, tt, project.subStyle);

  if (opts.placeholder && project.clips.length === 0) {
    ctx.fillStyle = 'rgba(226,232,240,0.55)';
    ctx.font = `600 ${Math.round(h * 0.045)}px Inter, system-ui, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Tap "Add" to bring in a video, photo or music', w / 2, h / 2);
  }
  ctx.restore();
}
