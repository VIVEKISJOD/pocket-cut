import { DEFAULT_OV, clamp, clipEnd, hexToRgb, hexToRgba, projectDuration } from './project';

const SUPPORTS_FILTER =
  typeof CanvasRenderingContext2D !== 'undefined' && 'filter' in CanvasRenderingContext2D.prototype;

export const isDefaultFilter = (f) =>
  f.brightness === 100 && f.contrast === 100 && f.saturation === 100 && f.hue === 0 && f.sepia === 0 && f.grayscale === 0 && !f.blur;

export const buildFilter = (f, scale = 1) =>
  isDefaultFilter(f)
    ? 'none'
    : `brightness(${f.brightness}%) contrast(${f.contrast}%) saturate(${f.saturation}%) hue-rotate(${f.hue}deg) sepia(${f.sepia}%) grayscale(${f.grayscale}%)${
        f.blur ? ` blur(${(f.blur * scale).toFixed(1)}px)` : ''
      }`;

// Keeps every clip's media element at the right position for timeline time t.
export function syncMedia(project, t, playing, pool) {
  for (const clip of project.clips) {
    if (!clip.url) continue;
    const entry = pool.get(clip);
    if (clip.kind === 'image') continue;
    const el = entry.el;
    if (entry.gain) entry.gain.gain.value = clip.volume == null ? 1 : clip.volume;
    const active = t >= clip.start && t < clipEnd(clip);
    if (active) {
      const want = clip.inPoint + (t - clip.start);
      if (playing) {
        const drift = el.currentTime - want; // positive = media is ahead of the timeline
        if (Math.abs(drift) > 0.2) {
          el.currentTime = want;
          el.playbackRate = 1;
        } else if (Math.abs(drift) > 0.04) {
          el.playbackRate = drift > 0 ? 0.96 : 1.04; // ease back into sync without a jump
        } else if (el.playbackRate !== 1) {
          el.playbackRate = 1;
        }
        if (el.paused) el.play().catch(() => {});
      } else {
        if (!el.paused) el.pause();
        if (el.playbackRate !== 1) el.playbackRate = 1;
        if (Math.abs(el.currentTime - want) > 0.04) el.currentTime = want;
      }
    } else {
      if (el.playbackRate !== 1) el.playbackRate = 1;
      if (!el.paused) el.pause();
      if (t < clip.start && clip.start - t < 0.6 && Math.abs(el.currentTime - clip.inPoint) > 0.1) {
        el.currentTime = clip.inPoint;
      }
    }
  }
}

function srcSize(entry) {
  const el = entry.el;
  if (entry.kind === 'image') return [el.naturalWidth, el.naturalHeight];
  if (el.readyState < 2) return [0, 0];
  return [el.videoWidth, el.videoHeight];
}

export function boxFor(clip, w, h) {
  if (clip.track === 'overlay') {
    const o = clip.ov || DEFAULT_OV;
    const bw = w * o.s;
    const bh = h * o.s;
    return { x: o.x * w - bw / 2, y: o.y * h - bh / 2, w: bw, h: bh };
  }
  return { x: 0, y: 0, w, h };
}

function place(clip, sw, sh, box) {
  const s = clip.fit === 'cover' ? Math.max(box.w / sw, box.h / sh) : Math.min(box.w / sw, box.h / sh);
  const dw = sw * s;
  const dh = sh * s;
  return { dx: box.x + (box.w - dw) / 2, dy: box.y + (box.h - dh) / 2, dw, dh };
}

// ---- chroma key (green screen / any colour) ----
const scratch = new Map();
function drawKeyed(ctx, el, sw, sh, r, ch, id) {
  const sc = Math.min(1, 640 / sw);
  const cw = Math.max(2, Math.round(sw * sc));
  const chh = Math.max(2, Math.round(sh * sc));
  let s = scratch.get(id);
  if (!s) {
    const c = document.createElement('canvas');
    s = { c, g: c.getContext('2d', { willReadFrequently: true }) };
    scratch.set(id, s);
  }
  if (s.c.width !== cw || s.c.height !== chh) {
    s.c.width = cw;
    s.c.height = chh;
  }
  s.g.clearRect(0, 0, cw, chh);
  s.g.drawImage(el, 0, 0, cw, chh);
  const img = s.g.getImageData(0, 0, cw, chh);
  const d = img.data;
  const [kr, kg, kb] = hexToRgb(ch.color);
  const kcb = 128 - 0.168736 * kr - 0.331264 * kg + 0.5 * kb;
  const kcr = 128 + 0.5 * kr - 0.418688 * kg - 0.081312 * kb;
  const sim = ch.sim;
  const sm = Math.max(0.001, ch.smooth);
  const spill = ch.spill || 0;
  const dom = kg >= kr && kg >= kb ? 1 : kb >= kr && kb >= kg ? 2 : 0;
  for (let i = 0; i < d.length; i += 4) {
    const R = d[i];
    const G = d[i + 1];
    const B = d[i + 2];
    const cb = 128 - 0.168736 * R - 0.331264 * G + 0.5 * B;
    const cr = 128 + 0.5 * R - 0.418688 * G - 0.081312 * B;
    const dist = Math.sqrt((cb - kcb) * (cb - kcb) + (cr - kcr) * (cr - kcr)) / 181;
    let a;
    if (dist <= sim) a = 0;
    else if (dist >= sim + sm) a = 1;
    else a = (dist - sim) / sm;
    d[i + 3] = a * 255;
    if (spill > 0 && a > 0) {
      if (dom === 1) {
        const lim = (R + B) / 2;
        if (G > lim) d[i + 1] = G - (G - lim) * spill;
      } else if (dom === 2) {
        const lim = (R + G) / 2;
        if (B > lim) d[i + 2] = B - (B - lim) * spill;
      }
    }
  }
  s.g.putImageData(img, 0, 0);
  ctx.drawImage(s.c, r.dx, r.dy, r.dw, r.dh);
}

function drawClip(ctx, clip, entry, box) {
  const [sw, sh] = srcSize(entry);
  if (!sw || !sh) return;
  const r = place(clip, sw, sh, box);
  const keyed = clip.chroma && clip.chroma.on;
  ctx.save();
  ctx.beginPath();
  ctx.rect(box.x, box.y, box.w, box.h);
  ctx.clip();
  ctx.globalAlpha = clip.opacity == null ? 1 : clip.opacity;
  if (keyed) drawKeyed(ctx, entry.el, sw, sh, r, clip.chroma, clip.id);
  else ctx.drawImage(entry.el, r.dx, r.dy, r.dw, r.dh);
  ctx.restore();
  if (clip.track === 'overlay' && clip.border && !keyed) {
    ctx.save();
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.lineWidth = Math.max(2, ctx.canvas.width * 0.003);
    ctx.strokeRect(r.dx, r.dy, r.dw, r.dh);
    ctx.restore();
  }
}

// Picks the colour of the clip's own picture at canvas position (px, py).
export function sampleClipColor(clip, pool, w, h, px, py) {
  if (!clip.url) return null;
  const entry = pool.get(clip);
  const [sw, sh] = srcSize(entry);
  if (!sw || !sh) return null;
  const r = place(clip, sw, sh, boxFor(clip, w, h));
  const u = (px - r.dx) / r.dw;
  const v = (py - r.dy) / r.dh;
  if (u < 0 || u > 1 || v < 0 || v > 1) return null;
  const c = document.createElement('canvas');
  c.width = 1;
  c.height = 1;
  const g = c.getContext('2d', { willReadFrequently: true });
  g.drawImage(entry.el, Math.min(sw - 1, Math.floor(u * sw)), Math.min(sh - 1, Math.floor(v * sh)), 1, 1, 0, 0, 1, 1);
  const p = g.getImageData(0, 0, 1, 1).data;
  return `#${[p[0], p[1], p[2]].map((n) => n.toString(16).padStart(2, '0')).join('')}`;
}

function roundRect(ctx, x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function drawSubtitle(ctx, w, h, sub, t, st) {
  const fontPx = Math.max(10, Math.round((h * st.size) / 100));
  ctx.font = `700 ${fontPx}px ${st.font}`;
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'left';
  const up = (s) => (st.uppercase ? s.toUpperCase() : s);
  // word list: real word timings when we have them, otherwise estimated from the text
  const words = [];
  if (sub.words && sub.words.length) {
    sub.words.forEach((x) => words.push({ word: up(x.w), s: x.s, e: x.e, br: false }));
  } else {
    const parts = [];
    String(sub.text || '').split('\n').forEach((para, pi) =>
      para.split(/\s+/).filter(Boolean).forEach((p, wi) => parts.push({ p, br: pi > 0 && wi === 0 })),
    );
    const total = parts.reduce((n, x) => n + x.p.length + 1, 0) || 1;
    let tt = sub.start;
    parts.forEach((x) => {
      const d = ((sub.end - sub.start) * (x.p.length + 1)) / total;
      words.push({ word: up(x.p), s: tt, e: tt + d, br: x.br });
      tt += d;
    });
  }
  if (!words.length) return;
  words.forEach((x) => {
    x.ww = ctx.measureText(x.word).width;
  });
  const space = ctx.measureText(' ').width;
  const maxW = w * 0.88;
  const lines = [];
  let cur = null;
  words.forEach((wd, i) => {
    wd.i = i;
    if (!cur || wd.br || cur.width + space + wd.ww > maxW) {
      cur = { items: [wd], width: wd.ww };
      lines.push(cur);
    } else {
      cur.items.push(wd);
      cur.width += space + wd.ww;
    }
  });
  let active = 0;
  for (let i = 0; i < words.length; i++) {
    if (t >= words[i].s) active = i;
  }
  const lineH = fontPx * 1.3;
  const padX = st.pill ? fontPx * 0.7 : 0;
  const padY = st.pill ? fontPx * 0.4 : 0;
  const bw = Math.max(...lines.map((l) => l.width)) + padX * 2;
  const bh = lines.length * lineH + padY * 2;
  const bx = (w - bw) / 2;
  let by = st.position === 'top' ? h * 0.07 : st.position === 'middle' ? (h - bh) / 2 : h - bh - h * 0.07;
  by += (h * (st.offsetY || 0)) / 100;

  ctx.save();
  const age = t - sub.start;
  if (st.anim === 'pop' && age < 0.2) {
    const k = 0.6 + 0.4 * clamp(age / 0.2, 0, 1);
    ctx.translate(w / 2, by + bh / 2);
    ctx.scale(k, k);
    ctx.translate(-w / 2, -(by + bh / 2));
  } else if (st.anim === 'fade') {
    ctx.globalAlpha = clamp(age / 0.2, 0, 1);
  }
  if (st.shadow) {
    ctx.shadowColor = 'rgba(0,0,0,0.75)';
    ctx.shadowBlur = fontPx * 0.2;
    ctx.shadowOffsetY = fontPx * 0.06;
  }
  if (st.pill) {
    ctx.fillStyle = hexToRgba(st.bg, st.bgOpacity);
    roundRect(ctx, bx, by, bw, bh, fontPx * (st.radius == null ? 0.6 : st.radius));
    ctx.fill();
  }
  lines.forEach((ln, li) => {
    let x = (w - ln.width) / 2;
    const y = by + padY + li * lineH + lineH / 2;
    ln.items.forEach((wd) => {
      if (st.stroke > 0) {
        ctx.lineJoin = 'round';
        ctx.lineWidth = (fontPx * st.stroke) / 100;
        ctx.strokeStyle = st.strokeColor || '#000';
        ctx.strokeText(wd.word, x, y);
      }
      ctx.fillStyle = st.highlightOn && wd.i === active ? st.highlight : st.color;
      ctx.fillText(wd.word, x, y);
      x += wd.ww + space;
    });
  });
  ctx.restore();
}

export function renderFrame(ctx, w, h, project, t, pool, opts = {}) {
  const dur = projectDuration(project);
  const tt = dur > 0 ? Math.min(t, dur - 0.001) : t;
  ctx.save();
  ctx.filter = 'none';
  ctx.globalAlpha = 1;
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, w, h);

  const order = { video: 0, overlay: 1 };
  const visual = project.clips
    .filter((c) => c.url && (c.track === 'video' || c.track === 'overlay') && tt >= c.start && tt < clipEnd(c))
    .sort((a, b) => order[a.track] - order[b.track] || a.start - b.start);

  if (SUPPORTS_FILTER) ctx.filter = buildFilter(project.filter, Math.min(w, h) / 720);
  for (const c of visual) drawClip(ctx, c, pool.get(c), boxFor(c, w, h));
  ctx.filter = 'none';

  const v = project.filter.vignette;
  if (v > 0) {
    const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.25, w / 2, h / 2, Math.hypot(w, h) / 2);
    g.addColorStop(0, 'rgba(0,0,0,0)');
    g.addColorStop(1, `rgba(0,0,0,${(v / 100) * 0.9})`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }

  const sub = project.subtitles.find((s) => tt >= s.start && tt < s.end);
  if (sub) drawSubtitle(ctx, w, h, sub, tt, project.subStyle);

  if (opts.grid) {
    ctx.strokeStyle = 'rgba(255,255,255,0.28)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 1; i < 3; i++) {
      ctx.moveTo((w * i) / 3, 0);
      ctx.lineTo((w * i) / 3, h);
      ctx.moveTo(0, (h * i) / 3);
      ctx.lineTo(w, (h * i) / 3);
    }
    ctx.stroke();
  }

  if (opts.placeholder && project.clips.length === 0) {
    ctx.fillStyle = 'rgba(226,232,240,0.55)';
    ctx.font = `600 ${Math.round(h * 0.045)}px Inter, system-ui, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Tap Media to add a video or photo', w / 2, h / 2);
  }
  ctx.restore();
}
