export const uid = () => Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-3);
export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

export const ASPECT_LIST = [
  { id: '16:9', name: 'Landscape', hint: 'YouTube, TV', r: 16 / 9 },
  { id: '9:16', name: 'Vertical', hint: 'Reels, Shorts, TikTok', r: 9 / 16 },
  { id: '1:1', name: 'Square', hint: 'Instagram post', r: 1 },
  { id: '4:5', name: 'Portrait', hint: 'Instagram feed', r: 4 / 5 },
  { id: '4:3', name: 'Classic', hint: 'Old TV, tablets', r: 4 / 3 },
];
export const ASPECT_IDS = ASPECT_LIST.map((a) => a.id);
export const aspectRatio = (id) => (ASPECT_LIST.find((a) => a.id === id) || ASPECT_LIST[0]).r;
const even = (n) => Math.max(2, Math.round(n / 2) * 2);
// Pixel size for an aspect ratio where the shorter side is `short` pixels.
export const dims = (id, short) => {
  const r = aspectRatio(id);
  return r >= 1 ? { w: even(short * r), h: even(short) } : { w: even(short), h: even(short / r) };
};
export const PREVIEW_SHORT = 720;

export const clipDur = (c) => Math.max(0.05, c.outPoint - c.inPoint);
export const clipEnd = (c) => c.start + clipDur(c);
export const projectDuration = (p) => {
  let m = 0;
  for (const c of p.clips) m = Math.max(m, clipEnd(c));
  for (const s of p.subtitles) m = Math.max(m, s.end);
  return m;
};

export const DEFAULT_OV = { x: 0.82, y: 0.22, s: 0.34 };
export const DEFAULT_CHROMA = { on: false, color: '#00ff00', sim: 0.28, smooth: 0.12, spill: 0.6 };

export function newClip(fields) {
  const visual = fields.track === 'video' || fields.track === 'overlay';
  return {
    inPoint: 0,
    volume: 1,
    fit: 'contain',
    opacity: 1,
    ...(visual ? { chroma: { ...DEFAULT_CHROMA } } : {}),
    ...(fields.track === 'overlay' ? { ov: { ...DEFAULT_OV }, border: true } : {}),
    ...fields,
  };
}

export const FILTER_KEYS = ['brightness', 'contrast', 'saturation', 'hue', 'vignette', 'sepia', 'grayscale', 'blur'];
export const DEFAULT_FILTER = {
  preset: 'none', brightness: 100, contrast: 100, saturation: 100, hue: 0, vignette: 0, sepia: 0, grayscale: 0, blur: 0,
};
const V = (o) => ({ brightness: 100, contrast: 100, saturation: 100, hue: 0, vignette: 0, sepia: 0, grayscale: 0, blur: 0, ...o });
export const FILTER_PRESETS = [
  { id: 'none', name: 'Original', values: V({}) },
  { id: 'cinematic', name: 'Cinematic', values: V({ brightness: 96, contrast: 118, saturation: 88, hue: -6, vignette: 45, sepia: 12 }) },
  { id: 'tealorange', name: 'Teal & Orange', values: V({ contrast: 112, saturation: 125, hue: -12, vignette: 25, sepia: 8 }) },
  { id: 'warm', name: 'Warm', values: V({ brightness: 104, contrast: 104, saturation: 112, hue: -8, sepia: 18, vignette: 15 }) },
  { id: 'cool', name: 'Cool', values: V({ contrast: 106, saturation: 95, hue: 12 }) },
  { id: 'vintage', name: 'Vintage', values: V({ brightness: 104, contrast: 92, saturation: 80, sepia: 45, vignette: 55 }) },
  { id: 'noir', name: 'Noir', values: V({ brightness: 94, contrast: 130, grayscale: 100, vignette: 60 }) },
  { id: 'vivid', name: 'Vivid', values: V({ brightness: 104, contrast: 112, saturation: 150 }) },
  { id: 'fade', name: 'Fade', values: V({ brightness: 112, contrast: 86, saturation: 78 }) },
  { id: 'dreamy', name: 'Dreamy', values: V({ brightness: 108, contrast: 92, saturation: 112, blur: 2 }) },
  { id: 'sunset', name: 'Sunset', values: V({ brightness: 102, contrast: 108, saturation: 135, sepia: 25, hue: -14, vignette: 20 }) },
  { id: 'moody', name: 'Moody', values: V({ brightness: 88, contrast: 125, saturation: 80, hue: 8, vignette: 55 }) },
];

export const FONT_CHOICES = [
  { id: 'sans', name: 'Modern', css: 'Inter, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' },
  { id: 'serif', name: 'Serif', css: 'Georgia, "Times New Roman", serif' },
  { id: 'mono', name: 'Mono', css: '"Courier New", ui-monospace, monospace' },
  { id: 'impact', name: 'Impact', css: 'Impact, "Arial Black", Roboto, sans-serif' },
  { id: 'rounded', name: 'Rounded', css: '"Trebuchet MS", "Segoe UI", sans-serif' },
  { id: 'comic', name: 'Playful', css: '"Comic Sans MS", "Chalkboard SE", cursive' },
];

export const DEFAULT_SUB_STYLE = {
  font: FONT_CHOICES[0].css,
  size: 5.5,
  color: '#ffffff',
  highlight: '#facc15',
  highlightOn: true,
  bg: '#000000',
  bgOpacity: 0.6,
  pill: true,
  radius: 0.6,
  stroke: 0,
  strokeColor: '#000000',
  shadow: false,
  uppercase: false,
  anim: 'none',
  position: 'bottom',
  offsetY: 0,
};

export const CAPTION_PRESETS = [
  { id: 'clean', name: 'Clean pill', style: { ...DEFAULT_SUB_STYLE } },
  {
    id: 'pop', name: 'Bold pop',
    style: { ...DEFAULT_SUB_STYLE, font: FONT_CHOICES[3].css, size: 7.5, pill: false, stroke: 16, uppercase: true, anim: 'pop', position: 'middle', highlight: '#facc15' },
  },
  {
    id: 'karaoke', name: 'Karaoke',
    style: { ...DEFAULT_SUB_STYLE, size: 6, bgOpacity: 0.75, highlight: '#22d3ee', anim: 'fade', radius: 1 },
  },
  {
    id: 'movie', name: 'Movie',
    style: { ...DEFAULT_SUB_STYLE, font: FONT_CHOICES[1].css, size: 5, pill: false, shadow: true, stroke: 6, highlightOn: false },
  },
  {
    id: 'neon', name: 'Neon',
    style: { ...DEFAULT_SUB_STYLE, font: FONT_CHOICES[4].css, size: 6.5, pill: false, color: '#f0abfc', highlight: '#67e8f9', stroke: 12, strokeColor: '#4c1d95', shadow: true, anim: 'pop' },
  },
  {
    id: 'minimal', name: 'Minimal',
    style: { ...DEFAULT_SUB_STYLE, size: 4.5, bgOpacity: 0.35, highlightOn: false, radius: 0.3 },
  },
];

export const THEMES = [
  { id: 'midnight', name: 'Midnight', acc: '34 211 238', acc2: '139 92 246', bg: '#020617', a: '#312e81', b: '#0e7490', panel: '15 23 42' },
  { id: 'ocean', name: 'Ocean', acc: '56 189 248', acc2: '37 99 235', bg: '#020617', a: '#1e3a8a', b: '#0369a1', panel: '8 20 40' },
  { id: 'sunset', name: 'Sunset', acc: '251 146 60', acc2: '236 72 153', bg: '#12060a', a: '#9f1239', b: '#c2410c', panel: '30 12 20' },
  { id: 'forest', name: 'Forest', acc: '52 211 153', acc2: '22 163 74', bg: '#03120b', a: '#14532d', b: '#115e59', panel: '8 28 20' },
  { id: 'rose', name: 'Rose', acc: '244 114 182', acc2: '168 85 247', bg: '#10041a', a: '#701a75', b: '#9d174d', panel: '30 10 40' },
  { id: 'gold', name: 'Gold', acc: '250 204 21', acc2: '234 88 12', bg: '#120d03', a: '#78350f', b: '#854d0e', panel: '30 22 8' },
  { id: 'mono', name: 'Mono', acc: '226 232 240', acc2: '100 116 139', bg: '#09090b', a: '#27272a', b: '#3f3f46', panel: '24 24 27' },
];

export function applyTheme(themeId, glass, blurOn) {
  const t = THEMES.find((x) => x.id === themeId) || THEMES[0];
  const s = document.documentElement.style;
  s.setProperty('--acc', t.acc);
  s.setProperty('--acc2', t.acc2);
  s.setProperty('--bg', t.bg);
  s.setProperty('--bg-a', t.a);
  s.setProperty('--bg-b', t.b);
  s.setProperty('--panel', t.panel);
  s.setProperty('--panel-a', String(glass));
  s.setProperty('--blur', blurOn ? '24px' : '0px');
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', t.bg);
}

export function createProject(aspect, lookId) {
  const look = FILTER_PRESETS.find((p) => p.id === lookId) || FILTER_PRESETS[0];
  return {
    aspect,
    clips: [],
    subtitles: [],
    filter: { ...DEFAULT_FILTER, ...look.values, preset: look.id },
    subStyle: { ...DEFAULT_SUB_STYLE },
  };
}

export const formatTime = (t) => {
  t = Math.max(0, t || 0);
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  const cs = Math.floor((t * 100) % 100);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
};

export const hexToRgba = (hex, a) => {
  let h = String(hex || '').replace('#', '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  if (!/^[0-9a-fA-F]{6}/.test(h)) return `rgba(0,0,0,${a})`;
  const n = parseInt(h.slice(0, 6), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};

export const hexToRgb = (hex) => {
  let h = String(hex || '').replace('#', '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  const n = parseInt(h.slice(0, 6), 16);
  return Number.isFinite(n) ? [(n >> 16) & 255, (n >> 8) & 255, n & 255] : [0, 255, 0];
};

export const timeAgo = (ts) => {
  const s = Math.max(0, (Date.now() - ts) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return `${Math.floor(s / 86400)} d ago`;
};
