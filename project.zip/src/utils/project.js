export const uid = () => Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-3);
export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

export const ASPECTS = {
  '16:9': { w: 1280, h: 720 },
  '9:16': { w: 720, h: 1280 },
  '1:1': { w: 960, h: 960 },
};

export const clipDur = (c) => Math.max(0.05, c.outPoint - c.inPoint);
export const clipEnd = (c) => c.start + clipDur(c);
export const projectDuration = (p) => {
  let m = 0;
  for (const c of p.clips) m = Math.max(m, clipEnd(c));
  for (const s of p.subtitles) m = Math.max(m, s.end);
  return m;
};

export const FILTER_KEYS = ['brightness', 'contrast', 'saturation', 'hue', 'vignette', 'sepia', 'grayscale'];
export const DEFAULT_FILTER = {
  preset: 'none', brightness: 100, contrast: 100, saturation: 100, hue: 0, vignette: 0, sepia: 0, grayscale: 0,
};
const V = (o) => ({ brightness: 100, contrast: 100, saturation: 100, hue: 0, vignette: 0, sepia: 0, grayscale: 0, ...o });
export const FILTER_PRESETS = [
  { id: 'none', name: 'Original', values: V({}) },
  { id: 'cinematic', name: 'Cinematic', values: V({ brightness: 96, contrast: 118, saturation: 88, hue: -6, vignette: 45, sepia: 12 }) },
  { id: 'tealorange', name: 'Teal & Orange', values: V({ contrast: 112, saturation: 125, hue: -12, vignette: 25, sepia: 8 }) },
  { id: 'warm', name: 'Warm', values: V({ brightness: 104, contrast: 104, saturation: 112, hue: -8, sepia: 18, vignette: 15 }) },
  { id: 'cool', name: 'Cool', values: V({ contrast: 106, saturation: 95, hue: 12 }) },
  { id: 'vintage', name: 'Vintage', values: V({ brightness: 104, contrast: 92, saturation: 80, sepia: 45, vignette: 55 }) },
  { id: 'noir', name: 'Noir', values: V({ brightness: 94, contrast: 130, grayscale: 100, vignette: 60 }) },
  { id: 'vivid', name: 'Vivid', values: V({ brightness: 104, contrast: 112, saturation: 150 }) },
  { id: 'fade', name: 'Fade', values: V({ brightness: 112, contrast: 86, saturation: 78 }) },
];

export const FONT_CHOICES = [
  { id: 'sans', name: 'Modern', css: 'Inter, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' },
  { id: 'serif', name: 'Serif', css: 'Georgia, "Times New Roman", serif' },
  { id: 'mono', name: 'Mono', css: '"Courier New", ui-monospace, monospace' },
  { id: 'impact', name: 'Impact', css: 'Impact, "Arial Black", sans-serif' },
  { id: 'rounded', name: 'Rounded', css: '"Trebuchet MS", "Segoe UI", sans-serif' },
  { id: 'comic', name: 'Playful', css: '"Comic Sans MS", "Chalkboard SE", cursive' },
];

export const DEFAULT_SUB_STYLE = {
  font: FONT_CHOICES[0].css,
  size: 5.5,
  color: '#ffffff',
  highlight: '#facc15',
  bg: '#000000',
  bgOpacity: 0.6,
  pill: true,
  highlightOn: true,
  position: 'bottom',
};

export const formatTime = (t) => {
  t = Math.max(0, t || 0);
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  const cs = Math.floor((t * 100) % 100);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
};

export const hexToRgba = (hex, a) => {
  let h = String(hex || '').replace('#', '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  if (!/^[0-9a-fA-F]{6}/.test(h)) return `rgba(0,0,0,${a})`;
  const n = parseInt(h.slice(0, 6), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};
