import { ASPECTS, projectDuration } from './project';
import { renderFrame, syncMedia } from './renderer';

const CANDIDATES = [
  ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'mp4'],
  ['video/mp4;codecs=avc1,mp4a.40.2', 'mp4'],
  ['video/mp4', 'mp4'],
  ['video/webm;codecs=vp9,opus', 'webm'],
  ['video/webm;codecs=vp8,opus', 'webm'],
  ['video/webm', 'webm'],
];

export function pickMime() {
  if (typeof MediaRecorder === 'undefined') return null;
  for (const [mime, ext] of CANDIDATES) {
    if (MediaRecorder.isTypeSupported(mime)) return { mime, ext };
  }
  return null;
}

// Real-time export: the composite canvas + the mixed Web Audio output are
// recorded with MediaRecorder (MP4 on recent Chrome, otherwise WebM).
export async function exportProject({ project, pool, fps = 30, onProgress = () => {}, signal }) {
  const total = projectDuration(project);
  if (total <= 0) throw new Error('Add some media to the timeline first.');
  const pick = pickMime();
  if (!pick) throw new Error('This browser cannot record video. Please use Chrome on Android.');

  const { w, h } = ASPECTS[project.aspect];
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d', { alpha: false });

  pool.ensureAudio();
  await pool.resume();
  pool.pauseAll();
  pool.setSpeakerMuted(true);
  syncMedia(project, 0, false, pool);
  await new Promise((r) => setTimeout(r, 500));
  renderFrame(ctx, w, h, project, 0, pool);

  const vStream = canvas.captureStream(fps);
  const stream = new MediaStream([...vStream.getVideoTracks(), ...pool.recordDest.stream.getAudioTracks()]);
  const rec = new MediaRecorder(stream, {
    mimeType: pick.mime,
    videoBitsPerSecond: w * h >= 900000 ? 8000000 : 5000000,
    audioBitsPerSecond: 192000,
  });
  const chunks = [];
  rec.ondataavailable = (e) => {
    if (e.data && e.data.size) chunks.push(e.data);
  };
  const stopped = new Promise((res) => {
    rec.onstop = res;
  });

  let aborted = false;
  try {
    rec.start(500);
    const t0 = performance.now();
    await new Promise((resolve) => {
      const step = () => {
        if (signal && signal.aborted) {
          aborted = true;
          return resolve();
        }
        const t = (performance.now() - t0) / 1000;
        if (t >= total) return resolve();
        syncMedia(project, t, true, pool);
        renderFrame(ctx, w, h, project, t, pool);
        onProgress(Math.min(1, t / total));
        requestAnimationFrame(step);
      };
      step();
    });
    await new Promise((r) => setTimeout(r, 300));
  } finally {
    pool.pauseAll();
    pool.setSpeakerMuted(false);
    if (rec.state !== 'inactive') {
      rec.stop();
      await stopped;
    }
    vStream.getTracks().forEach((t) => t.stop());
  }
  if (aborted) return null;
  onProgress(1);
  return { blob: new Blob(chunks, { type: pick.mime.split(';')[0] }), ext: pick.ext };
}
