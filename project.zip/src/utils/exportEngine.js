import { Muxer, ArrayBufferTarget } from 'mp4-muxer';
import { clipDur, dims, projectDuration } from './project';
import { renderFrame, syncMedia } from './renderer';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const BPP = { standard: 0.06, high: 0.1, ultra: 0.16 };

export const calcBitrate = (w, h, fps, quality) => Math.round(Math.min(60e6, w * h * fps * (BPP[quality] || BPP.high)));

const CANDIDATES = [
  ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'mp4'],
  ['video/mp4;codecs=avc1,mp4a.40.2', 'mp4'],
  ['video/mp4', 'mp4'],
  ['video/webm;codecs=vp9,opus', 'webm'],
  ['video/webm;codecs=vp8,opus', 'webm'],
  ['video/webm', 'webm'],
];

export function pickMime() {
  if (typeof MediaRecorder === 'undefined') return null;
  for (const [mime, ext] of CANDIDATES) {
    if (MediaRecorder.isTypeSupported(mime)) return { mime, ext };
  }
  return null;
}

export const studioSupported = () => typeof VideoEncoder !== 'undefined' && typeof VideoFrame !== 'undefined';

// ---------------------------------------------------------------------------
// FAST export: records the canvas + mixed audio in real time with MediaRecorder.
// ---------------------------------------------------------------------------
export async function exportFast({ project, pool, opts, onProgress = () => {}, onPhase = () => {}, signal }) {
  const total = projectDuration(project);
  if (total <= 0) throw new Error('Add some media to the timeline first.');
  const pick = pickMime();
  if (!pick) throw new Error('This browser cannot record video. Please use Chrome on Android.');
  const { w, h } = dims(project.aspect, opts.res);
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d', { alpha: false });

  onPhase('Getting ready...');
  pool.ensureAudio();
  await pool.resume();
  pool.pauseAll();
  pool.setSpeakerMuted(true);
  syncMedia(project, 0, false, pool);
  await sleep(500);
  renderFrame(ctx, w, h, project, 0, pool);

  const vStream = canvas.captureStream(opts.fps);
  const stream = new MediaStream([...vStream.getVideoTracks(), ...pool.recordDest.stream.getAudioTracks()]);
  const rec = new MediaRecorder(stream, {
    mimeType: pick.mime,
    videoBitsPerSecond: calcBitrate(w, h, opts.fps, opts.quality),
    audioBitsPerSecond: 192000,
  });
  const chunks = [];
  rec.ondataavailable = (e) => {
    if (e.data && e.data.size) chunks.push(e.data);
  };
  const stopped = new Promise((res) => {
    rec.onstop = res;
  });

  let aborted = false;
  try {
    onPhase('Recording in real time...');
    rec.start(500);
    const t0 = performance.now();
    await new Promise((resolve) => {
      const step = () => {
        if (signal && signal.aborted) {
          aborted = true;
          return resolve();
        }
        const t = (performance.now() - t0) / 1000;
        if (t >= total) return resolve();
        syncMedia(project, t, true, pool);
        renderFrame(ctx, w, h, project, t, pool);
        onProgress(Math.min(1, t / total));
        requestAnimationFrame(step);
      };
      step();
    });
    await sleep(300);
  } finally {
    pool.pauseAll();
    pool.setSpeakerMuted(false);
    if (rec.state !== 'inactive') {
      rec.stop();
      await stopped;
    }
    vStream.getTracks().forEach((t) => t.stop());
  }
  if (aborted) return null;
  onProgress(1);
  return { blob: new Blob(chunks, { type: pick.mime.split(';')[0] }), ext: pick.ext, engine: 'fast' };
}

// ---------------------------------------------------------------------------
// STUDIO export: renders every frame exactly (WebCodecs H.264 + mp4-muxer).
// Never drops frames, so 60 fps and high bitrates are reliable. Slower than real time.
// ---------------------------------------------------------------------------
async function mixAudio(project, total) {
  const sr = 48000;
  const off = new OfflineAudioContext(2, Math.max(sr, Math.ceil(total * sr)), sr);
  const cache = new Map();
  let any = false;
  for (const c of project.clips) {
    if (c.kind === 'image' || !c.url) continue;
    const vol = c.volume == null ? 1 : c.volume;
    if (vol <= 0) continue;
    try {
      if (!cache.has(c.url)) {
        const ab = await (await fetch(c.url)).arrayBuffer();
        cache.set(c.url, await off.decodeAudioData(ab));
      }
      const buf = cache.get(c.url);
      const offset = Math.min(c.inPoint, Math.max(0, buf.duration - 0.01));
      const dur = Math.min(clipDur(c), buf.duration - offset);
      if (dur <= 0.01) continue;
      const src = off.createBufferSource();
      src.buffer = buf;
      const g = off.createGain();
      g.gain.value = vol;
      src.connect(g);
      g.connect(off.destination);
      src.start(Math.max(0, c.start), offset, dur);
      any = true;
    } catch { /* this clip has no audio track */ }
  }
  return any ? off.startRendering() : null;
}

async function seekClips(project, t, fps, pool) {
  const waits = [];
  for (const c of project.clips) {
    if (!c.url || c.kind === 'image' || (c.track !== 'video' && c.track !== 'overlay')) continue;
    if (!(t >= c.start && t < c.start + clipDur(c))) continue;
    const el = pool.get(c).el;
    const want = c.inPoint + (t - c.start);
    if (Math.abs(el.currentTime - want) < 0.5 / fps && el.readyState >= 2) continue;
    waits.push(
      new Promise((resolve) => {
        const done = () => {
          el.removeEventListener('seeked', done);
          clearTimeout(timer);
          resolve();
        };
        const timer = setTimeout(done, 1500);
        el.addEventListener('seeked', done);
        el.currentTime = want;
      }),
    );
  }
  if (waits.length) await Promise.all(waits);
}

export async function exportStudio({ project, pool, opts, onProgress = () => {}, onPhase = () => {}, signal }) {
  if (!studioSupported()) throw new Error('Studio export needs a newer Chrome (WebCodecs). Use Fast export instead.');
  const total = projectDuration(project);
  if (total <= 0) throw new Error('Add some media to the timeline first.');
  const { w, h } = dims(project.aspect, opts.res);
  const fps = opts.fps;
  const frames = Math.ceil(total * fps);
  const bitrate = calcBitrate(w, h, fps, opts.quality);

  onPhase('Checking encoder...');
  let vcfg = null;
  for (const codec of ['avc1.640033', 'avc1.4d0033', 'avc1.42E033']) {
    const cfg = { codec, width: w, height: h, bitrate, framerate: fps };
    try {
      const s = await VideoEncoder.isConfigSupported(cfg);
      if (s.supported) { vcfg = cfg; break; }
    } catch { /* try next */ }
  }
  if (!vcfg) throw new Error(`This device cannot encode ${w}x${h} at ${fps} fps. Pick a lower resolution or use Fast export.`);

  onPhase('Mixing audio...');
  pool.pauseAll();
  const mix = await mixAudio(project, total);
  if (signal && signal.aborted) return null;

  let acfg = null;
  let amux = 'aac';
  if (mix && typeof AudioEncoder !== 'undefined') {
    for (const [codec, m] of [['mp4a.40.2', 'aac'], ['opus', 'opus']]) {
      const cfg = { codec, sampleRate: 48000, numberOfChannels: 2, bitrate: 192000 };
      try {
        const s = await AudioEncoder.isConfigSupported(cfg);
        if (s.supported) { acfg = cfg; amux = m; break; }
      } catch { /* try next */ }
    }
  }

  const target = new ArrayBufferTarget();
  const muxer = new Muxer({
    target,
    video: { codec: 'avc', width: w, height: h, frameRate: fps },
    audio: acfg ? { codec: amux, numberOfChannels: 2, sampleRate: 48000 } : undefined,
    fastStart: 'in-memory',
  });

  let encErr = null;
  if (acfg) {
    onPhase('Encoding audio...');
    const aenc = new AudioEncoder({
      output: (chunk, meta) => muxer.addAudioChunk(chunk, meta),
      error: (e) => { encErr = e; },
    });
    aenc.configure(acfg);
    const ch0 = mix.getChannelData(0);
    const ch1 = mix.numberOfChannels > 1 ? mix.getChannelData(1) : ch0;
    const BLOCK = 4800;
    for (let i = 0; i < mix.length; i += BLOCK) {
      if (encErr) throw encErr;
      const n = Math.min(BLOCK, mix.length - i);
      const data = new Float32Array(n * 2);
      data.set(ch0.subarray(i, i + n), 0);
      data.set(ch1.subarray(i, i + n), n);
      const ad = new AudioData({
        format: 'f32-planar', sampleRate: 48000, numberOfFrames: n, numberOfChannels: 2,
        timestamp: Math.round((i / 48000) * 1e6), data,
      });
      aenc.encode(ad);
      ad.close();
      if (aenc.encodeQueueSize > 40) await sleep(4);
    }
    await aenc.flush();
    aenc.close();
  }

  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d', { alpha: false });
  const venc = new VideoEncoder({
    output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
    error: (e) => { encErr = e; },
  });
  venc.configure(vcfg);

  onPhase(`Rendering frames (${w}x${h}, ${fps} fps)...`);
  try {
    for (let i = 0; i < frames; i++) {
      if (signal && signal.aborted) return null;
      if (encErr) throw encErr;
      const t = i / fps;
      await seekClips(project, t, fps, pool);
      renderFrame(ctx, w, h, project, t, pool);
      const vf = new VideoFrame(canvas, { timestamp: Math.round((i * 1e6) / fps), duration: Math.round(1e6 / fps) });
      venc.encode(vf, { keyFrame: i % (fps * 2) === 0 });
      vf.close();
      while (venc.encodeQueueSize > 6) await sleep(3);
      if (i % 4 === 0) {
        onProgress(i / frames);
        await sleep(0);
      }
    }
    onPhase('Finishing the file...');
    await venc.flush();
  } finally {
    try { venc.close(); } catch { /* already closed */ }
  }
  if (encErr) throw encErr;
  muxer.finalize();
  onProgress(1);
  return { blob: new Blob([target.buffer], { type: 'video/mp4' }), ext: 'mp4', engine: 'studio' };
}
