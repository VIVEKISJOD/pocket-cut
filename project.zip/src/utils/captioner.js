import { computeEnvelope, extractAudio16k, findOffset, findOnset } from './audio';
import { clipDur, uid } from './project';
import { devToRoman } from './translit';
import { groupWords } from './captionUtils';

export const WHISPER_MODELS = [
  { id: 'Xenova/whisper-tiny', name: 'Fast (tiny, ~40 MB)' },
  { id: 'Xenova/whisper-base', name: 'Better (base, ~75 MB)' },
  { id: 'Xenova/whisper-small', name: 'Best (small, ~250 MB, slow)' },
];

export const LANGS = [
  ['auto', 'Auto-detect'],
  ['hinglish', 'Hinglish (Hindi in English letters)'],
  ['hindi', 'Hindi (Devanagari)'],
  ['english', 'English'],
  ['urdu', 'Urdu'], ['bengali', 'Bengali'], ['spanish', 'Spanish'], ['french', 'French'], ['german', 'German'],
  ['portuguese', 'Portuguese'], ['arabic', 'Arabic'], ['russian', 'Russian'], ['japanese', 'Japanese'],
  ['korean', 'Korean'], ['chinese', 'Chinese'], ['indonesian', 'Indonesian'], ['turkish', 'Turkish'],
];

let worker = null;
export function stopWorker() {
  if (worker) {
    worker.terminate();
    worker = null;
  }
}
function getWorker() {
  if (!worker) worker = new Worker(new URL('./whisperWorker.js', import.meta.url), { type: 'module' });
  return worker;
}

function transcribe(audio, language, model, onProgress) {
  return new Promise((resolve, reject) => {
    const w = getWorker();
    const id = uid();
    const handler = (e) => {
      const m = e.data;
      if (m.id !== id) return;
      if (m.type === 'progress') {
        onProgress(m.data);
      } else if (m.type === 'result') {
        w.removeEventListener('message', handler);
        resolve(m);
      } else if (m.type === 'error') {
        w.removeEventListener('message', handler);
        reject(new Error(m.message));
      }
    };
    w.addEventListener('message', handler);
    w.postMessage({ type: 'transcribe', id, audio, language, model }, [audio.buffer]);
  });
}

// Snaps each caption to where the voice really starts and stops.
function refine(subs, env, clipStart) {
  if (!env) return subs;
  const out = subs.map((s) => {
    const rs = s.start - clipStart;
    const re = s.end - clipStart;
    const on = findOnset(env, rs - 0.35, rs + 0.6);
    const off = findOffset(env, re - 0.6, re + 0.35);
    let ns = on !== null ? on : rs;
    let ne = off !== null ? off : re;
    if (ne < ns + 0.25) {
      ns = rs;
      ne = re;
    }
    ns += clipStart;
    ne += clipStart;
    const words = s.words.map((w) => ({ ...w }));
    words[0].s = ns;
    words[words.length - 1].e = ne;
    words.forEach((w) => {
      if (w.s < ns) w.s = ns;
      if (w.e > ne) w.e = ne;
      if (w.e < w.s + 0.05) w.e = Math.min(ne, w.s + 0.05);
    });
    return { ...s, start: ns, end: ne, words };
  });
  for (let i = 1; i < out.length; i++) {
    if (out[i - 1].end > out[i].start) out[i - 1].end = Math.max(out[i - 1].start + 0.1, out[i].start - 0.01);
  }
  return out;
}

export async function generateCaptions({
  project, clipIds, language, model, mode = 'speech', maxWords = 5,
  onPhase = () => {}, onProgress = () => {}, isCancelled = () => false,
}) {
  const targets = project.clips
    .filter((c) => clipIds.includes(c.id) && c.kind !== 'image' && c.url)
    .sort((a, b) => a.start - b.start);
  if (!targets.length) throw new Error('Choose at least one clip that has sound.');
  const wlang = language === 'hinglish' ? 'hindi' : language;
  const all = [];
  for (let i = 0; i < targets.length; i++) {
    const c = targets[i];
    onPhase(`Reading audio ${i + 1} of ${targets.length}...`);
    const audio = await extractAudio16k(c.url, c.inPoint, c.outPoint);
    if (isCancelled()) return null;
    if (audio.length < 4800) continue;
    const env = mode === 'speech' ? computeEnvelope(audio) : null;
    onPhase(`Listening ${i + 1} of ${targets.length}...`);
    const res = await transcribe(audio, wlang, model, onProgress);
    if (isCancelled()) return null;
    const limit = clipDur(c);
    const words = res.words
      .filter((w) => w.s < limit)
      .map((w) => ({
        w: language === 'hinglish' ? devToRoman(w.w) : w.w,
        s: c.start + w.s,
        e: c.start + Math.min(w.e, limit),
      }));
    const subs = groupWords(words, { maxWords, maxChars: 34 });
    all.push(...refine(subs, env, c.start));
  }
  if (isCancelled()) return null;
  return all;
}
