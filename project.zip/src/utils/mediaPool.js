// Holds one <video>/<audio>/<img> element per timeline clip and routes all audio
// through a single Web Audio graph so export can record the mixed sound.
class MediaPool {
  constructor() {
    this.els = new Map();
    this.ac = null;
  }

  ensureAudio() {
    if (this.ac) return this.ac;
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ac = new AC();
    this.master = this.ac.createGain();
    this.speaker = this.ac.createGain();
    this.recordDest = this.ac.createMediaStreamDestination();
    this.master.connect(this.speaker);
    this.speaker.connect(this.ac.destination);
    this.master.connect(this.recordDest);
    return this.ac;
  }

  async resume() {
    this.ensureAudio();
    if (this.ac.state !== 'running') {
      try { await this.ac.resume(); } catch { /* ignore */ }
    }
  }

  setSpeakerMuted(muted) {
    if (this.speaker) this.speaker.gain.value = muted ? 0 : 1;
  }

  get(clip) {
    let e = this.els.get(clip.id);
    if (e) return e;
    if (clip.kind === 'image') {
      const img = new Image();
      img.src = clip.url;
      e = { el: img, kind: 'image' };
    } else {
      const el = document.createElement(clip.kind === 'audio' ? 'audio' : 'video');
      el.preload = 'auto';
      el.playsInline = true;
      el.setAttribute('playsinline', '');
      el.src = clip.url;
      this.ensureAudio();
      const src = this.ac.createMediaElementSource(el);
      const gain = this.ac.createGain();
      src.connect(gain);
      gain.connect(this.master);
      e = { el, gain, kind: clip.kind };
    }
    this.els.set(clip.id, e);
    return e;
  }

  pauseAll() {
    this.els.forEach((e) => {
      if (e.el.pause && !e.el.paused) e.el.pause();
    });
  }
}

export const mediaPool = new MediaPool();
