import { uid } from './project';

// All words of a caption list with their timeline times (estimated when missing).
export function flattenWords(subs) {
  const out = [];
  subs.forEach((s) => {
    if (s.words && s.words.length) {
      s.words.forEach((w) => out.push({ ...w }));
    } else {
      const parts = String(s.text).split(/\s+/).filter(Boolean);
      const total = parts.reduce((n, p) => n + p.length + 1, 0) || 1;
      let t = s.start;
      parts.forEach((p) => {
        const d = ((s.end - s.start) * (p.length + 1)) / total;
        out.push({ w: p, s: t, e: t + d });
        t += d;
      });
    }
  });
  return out;
}

function makeSub(ws) {
  return {
    id: uid(),
    start: ws[0].s,
    end: Math.max(ws[ws.length - 1].e, ws[0].s + 0.3),
    text: ws.map((x) => x.w).join(' '),
    words: ws,
  };
}

// Groups words into caption blocks (max words / characters / pause length).
export function groupWords(words, { maxWords = 5, maxChars = 34, maxGap = 0.8 } = {}) {
  const subs = [];
  let cur = [];
  let chars = 0;
  const flush = () => {
    if (cur.length) subs.push(makeSub(cur));
    cur = [];
    chars = 0;
  };
  for (const w of words) {
    if (cur.length) {
      const gap = w.s - cur[cur.length - 1].e;
      if (cur.length >= maxWords || chars + w.w.length + 1 > maxChars || gap > maxGap) flush();
    }
    cur.push(w);
    chars += w.w.length + 1;
    if (/[.!?\u0964]$/.test(w.w)) flush();
  }
  flush();
  return subs;
}

export function regroupSubs(subs, maxWords, maxChars = 34) {
  return groupWords(flattenWords(subs), { maxWords, maxChars });
}
