import React, { useCallback, useEffect, useReducer, useRef, useState } from 'react';
import {
  ArrowLeft, Film, Layers, Maximize, Minimize, Music, Palette, Pause, Play, Redo2, Settings, Smile, Type, Undo2,
} from 'lucide-react';
import CanvasPlayer from './CanvasPlayer';
import Timeline from './Timeline';
import Inspector from './Inspector';
import RadialMenu from './RadialMenu';
import AutoCaptions from './AutoCaptions';
import AiStudio from './AiStudio';
import ExportModal from './ExportModal';
import MemeLibrary from './MemeLibrary';
import Modal from './Modal';
import { emptyHistory, historyReducer } from '../state/projectReducer';
import { mediaPool } from '../utils/mediaPool';
import { loadMediaFile } from '../utils/media';
import { audioBufferToWav } from '../utils/audio';
import { putMedia, putProject, serializeProject } from '../utils/db';
import { clock, useClockTime } from '../utils/clock';
import { sampleClipColor } from '../utils/renderer';
import {
  clamp, clipEnd, formatTime, newClip, projectDuration, uid,
} from '../utils/project';

function TimeLabel() {
  const t = useClockTime(100);
  return <>{formatTime(t)}</>;
}

export default function Editor({
  id, initialName, created, initialProject, settings, updateSettings, onExit, onOpenSettings,
}) {
  const [hist, dispatch] = useReducer(historyReducer, initialProject, emptyHistory);
  const project = hist.present;
  const [selected, setSelected] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [modal, setModal] = useState(null);
  const [inspector, setInspector] = useState(null);
  const [focus, setFocus] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [recording, setRecording] = useState(false);
  const [picking, setPicking] = useState(null);
  const [toast, setToast] = useState('');
  const [importing, setImporting] = useState(false);
  const [exportSettingsKey, setExportSettingsKey] = useState(0);

  const duration = projectDuration(project);
  const aiReady = settings.aiEnabled && settings.apiKey.trim().length > 0;

  const fileRef = useRef(null);
  const addOptsRef = useRef({ track: 'video' });
  const recRef = useRef(null);
  const urlsRef = useRef(new Set());
  const toastTimer = useRef(null);
  const projectRef = useRef(project);
  const selectedRef = useRef(selected);
  const settingsRef = useRef(settings);
  const playingRef = useRef(playing);
  const durRef = useRef(duration);
  projectRef.current = project;
  selectedRef.current = selected;
  settingsRef.current = settings;
  playingRef.current = playing;
  durRef.current = duration;

  const showToast = useCallback((msg) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 3500);
  }, []);

  const seek = useCallback((t) => {
    clock.set(clamp(t, 0, Math.max(durRef.current, 0)));
  }, []);

  useEffect(() => {
    clock.set(0);
    return () => {
      clock.playing = false;
      clearTimeout(toastTimer.current);
    };
  }, []);

  // ---------- saving ----------
  const persist = useCallback(async () => {
    const p = projectRef.current;
    const first = p.clips.find((c) => c.thumb && c.track !== 'audio');
    await putProject({
      id, name: initialName, created, updated: Date.now(), aspect: p.aspect,
      duration: projectDuration(p), thumb: first ? first.thumb : null, data: serializeProject(p),
    });
  }, [id, initialName, created]);

  useEffect(() => {
    if (!settings.autoSave) return undefined;
    const t = setTimeout(() => persist().catch(() => {}), 1200);
    return () => clearTimeout(t);
  }, [project, settings.autoSave, persist]);

  useEffect(() => {
    const onHide = () => {
      if (document.visibilityState === 'hidden') persist().catch(() => {});
    };
    document.addEventListener('visibilitychange', onHide);
    return () => document.removeEventListener('visibilitychange', onHide);
  }, [persist]);

  const leave = async () => {
    setPlaying(false);
    mediaPool.pauseAll();
    try { await persist(); } catch { /* ignore */ }
    mediaPool.clear();
    urlsRef.current.forEach((u) => URL.revokeObjectURL(u));
    onExit();
  };

  // ---------- playback ----------
  const togglePlay = useCallback(async () => {
    if (playingRef.current) {
      setPlaying(false);
      mediaPool.pauseAll();
      return;
    }
    if (durRef.current <= 0) return;
    await mediaPool.resume();
    if (clock.time >= durRef.current - 0.05) seek(0);
    setPlaying(true);
  }, [seek]);
  const onEnded = useCallback(() => setPlaying(false), []);

  // ---------- editing actions ----------
  const clipAtPlayhead = (preferSelected) => {
    const p = projectRef.current;
    const t = clock.time;
    const sel = selectedRef.current;
    const inside = (c) => c && t > c.start + 0.05 && t < clipEnd(c) - 0.05;
    let target = preferSelected && sel && sel.type === 'clip' ? p.clips.find((c) => c.id === sel.id) : null;
    if (!inside(target)) target = p.clips.find((c) => c.track === 'video' && inside(c));
    return target || null;
  };

  const doSplit = useCallback(() => {
    const c = clipAtPlayhead(true);
    if (!c) { showToast('Move the playhead over a clip, then tap Split.'); return; }
    dispatch({ type: 'SPLIT', id: c.id, time: clock.time, newId: uid() });
  }, [showToast]);

  const doTrim = useCallback((side) => {
    const c = clipAtPlayhead(true);
    if (!c) { showToast('Move the playhead over a clip, then tap Trim.'); return; }
    const ripple = settingsRef.current.ripple;
    dispatch({ type: side === 'left' ? 'TRIM_LEFT' : 'TRIM_RIGHT', id: c.id, time: clock.time, ripple });
    if (side === 'left' && ripple) seek(c.start);
  }, [showToast, seek]);

  const doDelete = useCallback(() => {
    const sel = selectedRef.current;
    if (!sel) return;
    if (settingsRef.current.confirmDelete && !window.confirm('Delete this?')) return;
    dispatch(sel.type === 'clip'
      ? { type: 'DELETE_CLIP', id: sel.id, ripple: settingsRef.current.ripple }
      : { type: 'DELETE_SUB', id: sel.id });
    setSelected(null);
  }, []);

  useEffect(() => {
    if (clock.time > duration) seek(duration);
  }, [duration, seek]);

  useEffect(() => {
    if (!selected) return;
    const ok = selected.type === 'clip'
      ? project.clips.some((c) => c.id === selected.id)
      : project.subtitles.some((s) => s.id === selected.id);
    if (!ok) setSelected(null);
  }, [project, selected]);

  useEffect(() => {
    if (selected) setInspector('edit');
    else setInspector((cur) => (cur === 'edit' ? null : cur));
  }, [selected && selected.id]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const onKey = (e) => {
      const tag = (e.target && e.target.tagName) || '';
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tag)) return;
      const k = e.key.toLowerCase();
      if (e.code === 'Space') { e.preventDefault(); togglePlay(); }
      else if (e.key === 'Delete' || e.key === 'Backspace') doDelete();
      else if ((e.ctrlKey || e.metaKey) && k === 'z') { e.preventDefault(); dispatch({ type: e.shiftKey ? 'REDO' : 'UNDO' }); }
      else if ((e.ctrlKey || e.metaKey) && k === 'y') { e.preventDefault(); dispatch({ type: 'REDO' }); }
      else if (k === 's' && !e.ctrlKey && !e.metaKey) doSplit();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [togglePlay, doDelete, doSplit]);

  // ---------- importing media ----------
  const importFiles = useCallback(async (files, opts = {}) => {
    const track = opts.track || 'video';
    setImporting(true);
    for (const file of files) {
      try {
        const m = await loadMediaFile(file);
        if (track === 'audio' && m.kind === 'image') throw new Error(`"${file.name}" is a photo. Use Media instead.`);
        if (track !== 'audio' && m.kind === 'audio') throw new Error(`"${file.name}" is audio. Use the Audio button instead.`);
        const mediaId = uid();
        try {
          await putMedia({ id: mediaId, projectId: id, blob: file, name: file.name, type: file.type });
        } catch {
          showToast('Not enough storage to keep a copy. The clip works now but may be missing after you close the project.');
        }
        urlsRef.current.add(m.url);
        const clip = newClip({
          id: uid(), mediaId, name: m.name, kind: m.kind, url: m.url, thumb: m.thumb, track,
          outPoint: m.srcDuration, srcDuration: m.srcDuration,
          ...(typeof opts.start === 'number' ? { start: opts.start } : {}),
        });
        if (opts.ov) clip.ov = opts.ov;
        if (opts.border !== undefined) clip.border = opts.border;
        if (opts.chroma && clip.chroma) clip.chroma = { ...clip.chroma, on: true };
        dispatch({ type: 'ADD_CLIP', clip });
        setSelected({ type: 'clip', id: clip.id });
      } catch (err) {
        showToast(err.message || 'Could not add that file.');
      }
    }
    setImporting(false);
  }, [id, showToast]);

  const pickFiles = (opts) => {
    addOptsRef.current = opts;
    const input = fileRef.current;
    input.accept = opts.track === 'audio' ? 'audio/*,video/*' : 'video/*,image/*';
    input.value = '';
    setModal(null);
    input.click();
  };
  const onFiles = (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length) importFiles(files, addOptsRef.current);
  };

  // ---------- voice recording ----------
  const toggleRec = async () => {
    if (recRef.current) {
      recRef.current.rec.stop();
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      const chunks = [];
      const start = clock.time;
      rec.ondataavailable = (e) => {
        if (e.data && e.data.size) chunks.push(e.data);
      };
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        recRef.current = null;
        setRecording(false);
        setPlaying(false);
        mediaPool.pauseAll();
        try {
          const blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' });
          const ac = new (window.AudioContext || window.webkitAudioContext)();
          const buf = await ac.decodeAudioData(await blob.arrayBuffer());
          ac.close();
          const file = new File([audioBufferToWav(buf)], `Voice ${Date.now() % 100000}.wav`, { type: 'audio/wav' });
          await importFiles([file], { track: 'audio', start });
        } catch {
          showToast('Could not save the recording.');
        }
      };
      rec.start();
      recRef.current = { rec };
      setRecording(true);
      if (durRef.current > 0) {
        await mediaPool.resume();
        setPlaying(true);
      }
      showToast('Recording. Use headphones so the video sound is not picked up.');
    } catch {
      showToast('Microphone access was blocked. Allow it in Chrome site settings.');
    }
  };

  // ---------- eyedropper for green screen ----------
  const onPick = (x, y, w, h) => {
    const clip = projectRef.current.clips.find((c) => c.id === picking);
    setPicking(null);
    if (!clip) return;
    const color = sampleClipColor(clip, mediaPool, w, h, x, y);
    if (!color) { showToast('Tap on the picture of that clip.'); return; }
    dispatch({ type: 'UPDATE_CLIP', id: clip.id, patch: { chroma: { ...clip.chroma, color, on: true } } });
  };

  const onExportBusy = useCallback((busy) => {
    setExporting(busy);
    if (busy) {
      setPlaying(false);
      mediaPool.pauseAll();
    } else {
      seek(0);
    }
  }, [seek]);

  const addTextAtPlayhead = () => {
    const t = clock.time;
    const s = { id: uid(), start: t, end: t + 2.5, text: 'Your text' };
    dispatch({ type: 'ADD_SUB', sub: s });
    setSelected({ type: 'sub', id: s.id });
    setModal(null);
  };

  const closeInspector = () => {
    setInspector(null);
    setSelected(null);
    setPicking(null);
  };
  const closeModal = () => setModal(null);
  const ui = {
    holdToDrag: settings.holdToDrag, holdMs: settings.holdMs, haptics: settings.haptics,
    snap: settings.snap, showThumbs: settings.showThumbs,
  };
  const railBtn = 'btn-icon w-10 h-10';

  return (
    <div className="h-[100dvh] w-screen flex flex-col gap-2 p-2 overflow-hidden">
      <div className="hidden portrait:flex items-center gap-2 glass-sm px-3 py-2 text-xs text-amber-200 shrink-0">
        Rotate your tablet to landscape for the full editor.
      </div>

      <div className="flex-1 min-h-0 flex gap-2">
        <nav className="glass-sm w-12 shrink-0 flex flex-col items-center gap-1.5 py-1.5 overflow-y-auto">
          <button className={railBtn} onClick={leave} aria-label="Back to projects"><ArrowLeft size={18} /></button>
          <button className={railBtn} onClick={() => dispatch({ type: 'UNDO' })} disabled={!hist.past.length && !hist.base} aria-label="Undo"><Undo2 size={18} /></button>
          <button className={railBtn} onClick={() => dispatch({ type: 'REDO' })} disabled={!hist.future.length} aria-label="Redo"><Redo2 size={18} /></button>
          <button className={railBtn} onClick={() => setFocus((f) => !f)} aria-label="Big preview">{focus ? <Minimize size={18} /> : <Maximize size={18} />}</button>
          <button className={`${railBtn} ${inspector === 'look' ? 'on' : ''}`} onClick={() => { setFocus(false); setInspector('look'); }} aria-label="Looks"><Palette size={18} /></button>
          <button className={`${railBtn} ${inspector === 'text' ? 'on' : ''}`} onClick={() => { setFocus(false); setInspector('text'); }} aria-label="Captions"><Type size={18} /></button>
          <button className={railBtn} onClick={onOpenSettings} aria-label="Settings"><Settings size={18} /></button>
        </nav>

        <section className="panel flex-1 min-w-0 min-h-0 relative overflow-hidden p-1.5">
          <div className="w-full h-full rounded-2xl overflow-hidden bg-black">
            <CanvasPlayer
              project={project}
              playing={playing}
              suspended={exporting}
              pool={mediaPool}
              scale={settings.previewScale}
              fpsCap={settings.previewFps}
              grid={settings.showGrid}
              loop={settings.loopPlayback}
              onEnded={onEnded}
              picking={!!picking}
              onPick={onPick}
            />
          </div>
          {picking && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 glass-sm px-3 py-1.5 text-xs">Tap the colour you want to remove</div>
          )}
          {recording && (
            <div className="absolute top-3 left-3 flex items-center gap-1.5 glass-sm px-2.5 py-1 text-xs text-rose-300">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" /> REC
            </div>
          )}
          {focus && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 glass-sm flex items-center gap-2 px-2 py-1.5">
              <button className="btn-icon" onClick={togglePlay} disabled={duration <= 0}>{playing ? <Pause size={18} /> : <Play size={18} />}</button>
              <span className="text-sm tabular-nums px-1"><TimeLabel /> <span className="text-slate-500">/ {formatTime(duration)}</span></span>
              <button className="btn-icon" onClick={() => setFocus(false)} aria-label="Exit big preview"><Minimize size={18} /></button>
            </div>
          )}
        </section>

        {!focus && (
          <aside className={`shrink-0 transition-[width] ${inspector ? 'w-[19rem]' : 'w-[15.5rem]'}`}>
            {inspector ? (
              <div className="glass h-full overflow-hidden">
                <Inspector
                  project={project}
                  selected={selected}
                  tab={inspector}
                  onTab={setInspector}
                  onClose={closeInspector}
                  dispatch={dispatch}
                  onSelect={setSelected}
                  onSeek={seek}
                  onSplit={doSplit}
                  onTrimLeft={() => doTrim('left')}
                  onTrimRight={() => doTrim('right')}
                  onDelete={doDelete}
                  onPickColor={(cid) => { setPicking(cid); showToast('Tap the colour you want to remove in the preview.'); }}
                  picking={picking}
                  onAutoCaptions={() => setModal('captions')}
                />
              </div>
            ) : (
              <RadialMenu
                onMedia={() => pickFiles({ track: 'video' })}
                onLayer={() => setModal('layer')}
                onAudio={() => pickFiles({ track: 'audio' })}
                onRec={toggleRec}
                recording={recording}
                onAi={() => setModal('ai')}
                onMemes={() => setModal('memes')}
                onPlay={togglePlay}
                playing={playing}
                canPlay={duration > 0}
                onExport={() => { setExportSettingsKey((k) => k + 1); setModal('export'); }}
                canExport={duration > 0}
              />
            )}
          </aside>
        )}
      </div>

      {!focus && (
        <section className="glass shrink-0 overflow-hidden" style={{ height: 'clamp(170px, 34%, 260px)' }}>
          <Timeline
            project={project}
            duration={duration}
            selected={selected}
            onSelect={setSelected}
            onSeek={seek}
            onSplit={doSplit}
            onTrimLeft={() => doTrim('left')}
            onTrimRight={() => doTrim('right')}
            onDelete={doDelete}
            dispatch={dispatch}
            ui={ui}
          />
        </section>
      )}

      <input ref={fileRef} type="file" multiple className="hidden" onChange={onFiles} />

      {modal === 'layer' && (
        <Modal title="Layers" icon={<Layers size={18} className="text-accent" />} onClose={closeModal}>
          <div className="grid gap-2">
            <button className="btn h-14 justify-start" onClick={() => pickFiles({ track: 'overlay' })}>
              <Layers size={18} /> Picture-in-picture <span className="text-xs text-slate-400">video or photo on top</span>
            </button>
            <button className="btn h-14 justify-start" onClick={() => pickFiles({ track: 'overlay', ov: { x: 0.5, y: 0.5, s: 1 }, chroma: true, border: false })}>
              <Film size={18} /> Green-screen video <span className="text-xs text-slate-400">full screen, colour removed</span>
            </button>
            <button className="btn h-14 justify-start" onClick={addTextAtPlayhead}>
              <Type size={18} /> Text at playhead
            </button>
            <button className="btn h-14 justify-start" onClick={() => setModal('memes')}>
              <Smile size={18} /> Meme library
            </button>
            <button className="btn h-14 justify-start" onClick={() => pickFiles({ track: 'audio' })}>
              <Music size={18} /> Audio or music
            </button>
          </div>
        </Modal>
      )}
      {modal === 'captions' && <AutoCaptions project={project} settings={settings} dispatch={dispatch} onClose={closeModal} />}
      {modal === 'ai' && (
        <AiStudio
          settings={settings}
          aiReady={aiReady}
          project={project}
          dispatch={dispatch}
          onSeek={seek}
          onOpenSettings={() => { setModal(null); onOpenSettings(); }}
          onClose={closeModal}
        />
      )}
      {modal === 'memes' && (
        <MemeLibrary
          giphyKey={settings.giphyKey}
          onAddFile={(file, opts) => importFiles([file], opts)}
          onOpenSettings={() => { setModal(null); onOpenSettings(); }}
          onClose={closeModal}
        />
      )}
      {modal === 'export' && (
        <ExportModal
          key={exportSettingsKey}
          project={project}
          settings={settings}
          updateSettings={updateSettings}
          onClose={closeModal}
          onBusy={onExportBusy}
        />
      )}

      {importing && <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[60] glass-sm px-4 py-2 text-sm">Importing...</div>}
      {toast && <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[60] glass-sm px-4 py-2 text-sm max-w-[90vw]">{toast}</div>}
    </div>
  );
}
