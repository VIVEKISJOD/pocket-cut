import React, { useEffect, useState } from 'react';
import { Plus, Scissors, Trash2 } from 'lucide-react';
import { ASPECTS, FILTER_PRESETS, FONT_CHOICES, clipDur, formatTime, uid } from '../utils/project';
import { buildFilter } from '../utils/renderer';

function Slider({ label, value, min, max, step = 1, unit = '', onChange, onEnd }) {
  return (
    <label className="block">
      <div className="flex justify-between text-xs text-slate-300">
        <span>{label}</span>
        <span className="tabular-nums">{Math.round(value * 100) / 100}{unit}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        onPointerUp={onEnd}
        onTouchEnd={onEnd}
        onKeyUp={onEnd}
      />
    </label>
  );
}

const TABS = [['look', 'Look'], ['clip', 'Clip'], ['text', 'Text']];

export default function Inspector({ project, selected, time, dispatch, onSelect, onSeek, onSplit, onDelete }) {
  const [tab, setTab] = useState('look');
  useEffect(() => {
    if (selected) setTab('clip');
  }, [selected && selected.id]);

  const end = () => dispatch({ type: 'END_GESTURE' });
  const f = project.filter;
  const st = project.subStyle;
  const setF = (patch) => dispatch({ type: 'SET_FILTER', patch: { ...patch, preset: 'custom' }, live: true });
  const setS = (patch) => dispatch({ type: 'SET_SUBSTYLE', patch, live: true });
  const clip = selected && selected.type === 'clip' ? project.clips.find((c) => c.id === selected.id) : null;
  const sub = selected && selected.type === 'sub' ? project.subtitles.find((s) => s.id === selected.id) : null;

  const addCaption = () => {
    const s = { id: uid(), start: time, end: time + 2, text: 'New caption' };
    dispatch({ type: 'ADD_SUB', sub: s });
    onSelect({ type: 'sub', id: s.id });
  };

  const sliders = [
    ['Brightness', 'brightness', 50, 150, '%'],
    ['Contrast', 'contrast', 50, 150, '%'],
    ['Saturation', 'saturation', 0, 200, '%'],
    ['Hue shift', 'hue', -180, 180, '\u00b0'],
    ['Vignette', 'vignette', 0, 100, '%'],
    ['Sepia', 'sepia', 0, 100, '%'],
    ['Black & white', 'grayscale', 0, 100, '%'],
  ];

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="flex gap-1 p-2 border-b border-white/10 shrink-0">
        {TABS.map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex-1 h-9 rounded-xl text-sm font-medium transition ${tab === id ? 'bg-gradient-to-r from-violet-500 to-cyan-500 text-white' : 'bg-white/10 text-slate-300'}`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="flex-1 min-h-0 overflow-auto p-3 space-y-3">
        {tab === 'look' && (
          <>
            <div>
              <div className="text-xs text-slate-400 mb-1">Canvas shape</div>
              <div className="grid grid-cols-3 gap-2">
                {Object.keys(ASPECTS).map((k) => (
                  <button
                    key={k}
                    onClick={() => dispatch({ type: 'SET_ASPECT', aspect: k })}
                    className={`h-9 rounded-xl text-sm ${project.aspect === k ? 'bg-cyan-500/30 ring-1 ring-cyan-300' : 'bg-white/10'}`}
                  >
                    {k}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400 mb-1">Looks</div>
              <div className="grid grid-cols-3 gap-2">
                {FILTER_PRESETS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => dispatch({ type: 'SET_FILTER', patch: { ...p.values, preset: p.id } })}
                    className={`rounded-xl p-1 text-[11px] ${f.preset === p.id ? 'ring-2 ring-cyan-300 bg-white/10' : 'bg-white/5'}`}
                  >
                    <div
                      className="h-8 rounded-lg mb-1"
                      style={{ background: 'linear-gradient(135deg,#f97316,#22d3ee,#a855f7)', filter: buildFilter(p.values) }}
                    />
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-1">
              {sliders.map(([label, key, min, max, unit]) => (
                <Slider key={key} label={label} unit={unit} min={min} max={max} value={f[key]} onChange={(v) => setF({ [key]: v })} onEnd={end} />
              ))}
            </div>
          </>
        )}

        {tab === 'clip' && !clip && !sub && (
          <p className="text-sm text-slate-400">Tap a clip or caption on the timeline to edit it here.</p>
        )}

        {tab === 'clip' && clip && (
          <>
            <div>
              <div className="font-medium truncate">{clip.name}</div>
              <div className="text-xs text-slate-400">
                Starts {formatTime(clip.start)} - length {formatTime(clipDur(clip))}
              </div>
            </div>
            {clip.kind !== 'image' && (
              <Slider
                label="Volume"
                unit="%"
                min={0}
                max={200}
                value={Math.round((clip.volume == null ? 1 : clip.volume) * 100)}
                onChange={(v) => dispatch({ type: 'UPDATE_CLIP', id: clip.id, patch: { volume: v / 100 }, live: true })}
                onEnd={end}
              />
            )}
            {clip.track !== 'audio' && (
              <div>
                <div className="text-xs text-slate-400 mb-1">Picture size</div>
                <div className="grid grid-cols-2 gap-2">
                  {[['contain', 'Fit'], ['cover', 'Fill']].map(([v, label]) => (
                    <button
                      key={v}
                      onClick={() => dispatch({ type: 'UPDATE_CLIP', id: clip.id, patch: { fit: v } })}
                      className={`h-9 rounded-xl text-sm ${(clip.fit || 'contain') === v ? 'bg-cyan-500/30 ring-1 ring-cyan-300' : 'bg-white/10'}`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <div className="flex gap-2">
              <button className="btn flex-1" onClick={onSplit}><Scissors size={16} /> Split</button>
              <button className="btn flex-1" onClick={onDelete}><Trash2 size={16} /> Delete</button>
            </div>
          </>
        )}

        {tab === 'clip' && sub && (
          <>
            <textarea
              className="input"
              rows={3}
              value={sub.text}
              onChange={(e) => dispatch({ type: 'UPDATE_SUB', id: sub.id, patch: { text: e.target.value }, live: true })}
              onBlur={end}
            />
            <div className="grid grid-cols-2 gap-2">
              {[['Start (s)', 'start'], ['End (s)', 'end']].map(([label, key]) => (
                <label key={key} className="text-xs text-slate-400">
                  {label}
                  <input
                    key={`${sub.id}-${key}-${sub[key].toFixed(2)}`}
                    className="input mt-1"
                    type="number"
                    step="0.1"
                    min="0"
                    defaultValue={sub[key].toFixed(2)}
                    onBlur={(e) => {
                      const v = parseFloat(e.target.value);
                      if (!Number.isFinite(v)) return;
                      const patch = { [key]: Math.max(0, v) };
                      const ns = patch.start ?? sub.start;
                      const ne = patch.end ?? sub.end;
                      if (ne > ns + 0.1) dispatch({ type: 'UPDATE_SUB', id: sub.id, patch });
                    }}
                  />
                </label>
              ))}
            </div>
            <div className="flex gap-2">
              <button className="btn flex-1" onClick={() => onSeek(sub.start)}>Go to caption</button>
              <button className="btn flex-1" onClick={onDelete}><Trash2 size={16} /> Delete</button>
            </div>
          </>
        )}

        {tab === 'text' && (
          <>
            <button className="btn-primary w-full" onClick={addCaption}><Plus size={16} /> Add caption at playhead</button>
            <label className="block text-xs text-slate-400">
              Font
              <select className="input mt-1" value={st.font} onChange={(e) => dispatch({ type: 'SET_SUBSTYLE', patch: { font: e.target.value } })}>
                {FONT_CHOICES.map((fc) => (
                  <option key={fc.id} value={fc.css}>{fc.name}</option>
                ))}
              </select>
            </label>
            <Slider label="Text size" min={3} max={10} step={0.5} value={st.size} onChange={(v) => setS({ size: v })} onEnd={end} />
            <div className="grid grid-cols-3 gap-2 text-xs text-slate-400">
              {[['Text', 'color'], ['Active word', 'highlight'], ['Pill', 'bg']].map(([label, key]) => (
                <label key={key} className="flex flex-col items-center gap-1">
                  {label}
                  <input type="color" value={st[key]} onChange={(e) => setS({ [key]: e.target.value })} onBlur={end} />
                </label>
              ))}
            </div>
            <Slider label="Pill opacity" min={0} max={1} step={0.05} value={st.bgOpacity} onChange={(v) => setS({ bgOpacity: v })} onEnd={end} />
            <div className="grid grid-cols-2 gap-2">
              <button
                className={`h-9 rounded-xl text-sm ${st.pill ? 'bg-cyan-500/30 ring-1 ring-cyan-300' : 'bg-white/10'}`}
                onClick={() => dispatch({ type: 'SET_SUBSTYLE', patch: { pill: !st.pill } })}
              >
                Pill background
              </button>
              <button
                className={`h-9 rounded-xl text-sm ${st.highlightOn ? 'bg-cyan-500/30 ring-1 ring-cyan-300' : 'bg-white/10'}`}
                onClick={() => dispatch({ type: 'SET_SUBSTYLE', patch: { highlightOn: !st.highlightOn } })}
              >
                Word highlight
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {['top', 'middle', 'bottom'].map((p) => (
                <button
                  key={p}
                  onClick={() => dispatch({ type: 'SET_SUBSTYLE', patch: { position: p } })}
                  className={`h-9 rounded-xl text-sm capitalize ${st.position === p ? 'bg-cyan-500/30 ring-1 ring-cyan-300' : 'bg-white/10'}`}
                >
                  {p}
                </button>
              ))}
            </div>
            <div>
              <div className="text-xs text-slate-400 mb-1">Captions ({project.subtitles.length})</div>
              {project.subtitles.length === 0 && <p className="text-xs text-slate-500">No captions yet. Use Captions in the top bar to transcribe, or add one above.</p>}
              <div className="space-y-1">
                {project.subtitles.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => {
                      onSelect({ type: 'sub', id: s.id });
                      onSeek(s.start);
                    }}
                    className="w-full text-left rounded-xl bg-white/5 hover:bg-white/10 px-2 py-1.5 text-xs"
                  >
                    <span className="text-slate-400 tabular-nums">{formatTime(s.start)}</span> {s.text}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
