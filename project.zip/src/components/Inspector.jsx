import React from 'react';
import { Pipette, Plus, Scissors, Trash2, X } from 'lucide-react';
import {
  ASPECT_LIST, CAPTION_PRESETS, DEFAULT_OV, FILTER_PRESETS, FONT_CHOICES, clipDur, formatTime, uid,
} from '../utils/project';
import { buildFilter } from '../utils/renderer';
import { clock } from '../utils/clock';
import { regroupSubs } from '../utils/captionUtils';

function Slider({ label, value, min, max, step = 1, unit = '', onChange, onEnd }) {
  return (
    <label className="block">
      <div className="flex justify-between text-xs text-slate-300">
        <span>{label}</span>
        <span className="tabular-nums">{Math.round(value * 100) / 100}{unit}</span>
      </div>
      <input
        type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        onPointerUp={onEnd} onTouchEnd={onEnd} onKeyUp={onEnd}
      />
    </label>
  );
}

function Toggle({ label, on, onClick }) {
  return (
    <button onClick={onClick} className={`h-9 rounded-xl text-xs px-2 ${on ? 'on' : 'bg-white/10'}`}>{label}</button>
  );
}

const TABS = [['edit', 'Edit'], ['look', 'Look'], ['text', 'Text']];

export default function Inspector({
  project, selected, tab, onTab, onClose, dispatch, onSelect, onSeek, onSplit, onTrimLeft, onTrimRight, onDelete,
  onPickColor, picking, onAutoCaptions,
}) {
  const end = () => dispatch({ type: 'END_GESTURE' });
  const f = project.filter;
  const st = project.subStyle;
  const setF = (patch) => dispatch({ type: 'SET_FILTER', patch: { ...patch, preset: 'custom' }, live: true });
  const setS = (patch) => dispatch({ type: 'SET_SUBSTYLE', patch, live: true });
  const setSn = (patch) => dispatch({ type: 'SET_SUBSTYLE', patch });
  const clip = selected && selected.type === 'clip' ? project.clips.find((c) => c.id === selected.id) : null;
  const sub = selected && selected.type === 'sub' ? project.subtitles.find((s) => s.id === selected.id) : null;
  const setClip = (patch, live = true) => dispatch({ type: 'UPDATE_CLIP', id: clip.id, patch, live });

  const addCaption = () => {
    const t = clock.time;
    const s = { id: uid(), start: t, end: t + 2, text: 'New caption' };
    dispatch({ type: 'ADD_SUB', sub: s });
    onSelect({ type: 'sub', id: s.id });
  };

  const sliders = [
    ['Brightness', 'brightness', 50, 150, '%'],
    ['Contrast', 'contrast', 50, 150, '%'],
    ['Saturation', 'saturation', 0, 200, '%'],
    ['Hue shift', 'hue', -180, 180, '\u00b0'],
    ['Vignette', 'vignette', 0, 100, '%'],
    ['Sepia', 'sepia', 0, 100, '%'],
    ['Black & white', 'grayscale', 0, 100, '%'],
    ['Blur', 'blur', 0, 10, ''],
  ];
  const visual = clip && (clip.track === 'video' || clip.track === 'overlay') && clip.kind !== 'audio';
  const ov = clip && clip.ov ? clip.ov : DEFAULT_OV;
  const ch = clip && clip.chroma ? clip.chroma : null;
  const wordsNow = (() => {
    const n = project.subtitles.reduce((a, s) => a + String(s.text).split(/\s+/).filter(Boolean).length, 0);
    return n;
  })();

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="flex items-center gap-1 p-2 border-b border-white/10 shrink-0">
        {TABS.map(([id, label]) => (
          <button
            key={id}
            onClick={() => onTab(id)}
            className={`flex-1 h-9 rounded-xl text-sm font-medium transition ${tab === id ? 'bg-gradient-to-r from-accent2 to-accent text-white' : 'bg-white/10 text-slate-300'}`}
          >
            {label}
          </button>
        ))}
        <button className="btn-icon w-9 h-9" onClick={onClose} aria-label="Close panel"><X size={16} /></button>
      </div>

      <div className="flex-1 min-h-0 overflow-auto p-3 space-y-3">
        {tab === 'edit' && !clip && !sub && (
          <p className="text-sm text-slate-400">Tap a clip or caption on the timeline to edit it here.</p>
        )}

        {tab === 'edit' && clip && (
          <>
            <div>
              <div className="font-medium truncate">{clip.name}</div>
              <div className="text-xs text-slate-400">Starts {formatTime(clip.start)} - length {formatTime(clipDur(clip))}</div>
              {clip.missing && <div className="text-xs text-rose-300 mt-1">This file is missing from the device storage.</div>}
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              <button className="btn px-1 text-xs" onClick={onSplit}><Scissors size={14} /> Split</button>
              <button className="btn px-1 text-xs" onClick={onTrimLeft}>Trim L</button>
              <button className="btn px-1 text-xs" onClick={onTrimRight}>Trim R</button>
              <button className="btn px-1 text-xs" onClick={onDelete}><Trash2 size={14} /></button>
            </div>
            <p className="text-[10px] text-slate-500 -mt-1">Move the playhead, then Trim L removes everything on its left, Trim R everything on its right.</p>
            {clip.kind !== 'image' && (
              <Slider
                label="Volume" unit="%" min={0} max={200}
                value={Math.round((clip.volume == null ? 1 : clip.volume) * 100)}
                onChange={(v) => setClip({ volume: v / 100 })} onEnd={end}
              />
            )}
            {visual && (
              <>
                <Slider label="Opacity" unit="%" min={5} max={100} value={Math.round((clip.opacity == null ? 1 : clip.opacity) * 100)} onChange={(v) => setClip({ opacity: v / 100 })} onEnd={end} />
                <div className="grid grid-cols-2 gap-2">
                  {[['contain', 'Fit'], ['cover', 'Fill']].map(([v, label]) => (
                    <button key={v} onClick={() => setClip({ fit: v }, false)} className={`h-9 rounded-xl text-sm ${(clip.fit || 'contain') === v ? 'on' : 'bg-white/10'}`}>{label}</button>
                  ))}
                </div>
              </>
            )}

            {clip.track === 'overlay' && (
              <div className="space-y-2 rounded-2xl bg-white/5 p-2.5">
                <div className="text-xs font-medium">Layer size and position</div>
                <Slider label="Size" unit="%" min={10} max={100} value={Math.round(ov.s * 100)} onChange={(v) => setClip({ ov: { ...ov, s: v / 100 } })} onEnd={end} />
                <Slider label="Left / right" unit="%" min={0} max={100} value={Math.round(ov.x * 100)} onChange={(v) => setClip({ ov: { ...ov, x: v / 100 } })} onEnd={end} />
                <Slider label="Up / down" unit="%" min={0} max={100} value={Math.round(ov.y * 100)} onChange={(v) => setClip({ ov: { ...ov, y: v / 100 } })} onEnd={end} />
                <div className="grid grid-cols-4 gap-1.5">
                  <button className="btn px-1 text-xs" onClick={() => setClip({ ov: { ...DEFAULT_OV } }, false)}>Corner</button>
                  <button className="btn px-1 text-xs" onClick={() => setClip({ ov: { x: 0.5, y: 0.5, s: 0.55 } }, false)}>Center</button>
                  <button className="btn px-1 text-xs" onClick={() => setClip({ ov: { x: 0.5, y: 0.5, s: 1 } }, false)}>Full</button>
                  <Toggle label="Border" on={!!clip.border} onClick={() => setClip({ border: !clip.border }, false)} />
                </div>
              </div>
            )}

            {visual && ch && (
              <div className="space-y-2 rounded-2xl bg-white/5 p-2.5">
                <div className="flex items-center gap-2">
                  <div className="flex-1">
                    <div className="text-xs font-medium">Green screen / remove a colour</div>
                    <div className="text-[10px] text-slate-500">Works best on a Layer clip placed over another video.</div>
                  </div>
                  <Toggle label={ch.on ? 'On' : 'Off'} on={ch.on} onClick={() => setClip({ chroma: { ...ch, on: !ch.on } }, false)} />
                </div>
                {ch.on && (
                  <>
                    <div className="flex items-center gap-2">
                      <input type="color" value={ch.color} onChange={(e) => setClip({ chroma: { ...ch, color: e.target.value } })} onBlur={end} />
                      <button className={`btn flex-1 text-xs ${picking === clip.id ? 'on' : ''}`} onClick={() => onPickColor(clip.id)}>
                        <Pipette size={14} /> {picking === clip.id ? 'Tap the preview...' : 'Pick from preview'}
                      </button>
                    </div>
                    <Slider label="Remove strength" min={0} max={0.8} step={0.01} value={ch.sim} onChange={(v) => setClip({ chroma: { ...ch, sim: v } })} onEnd={end} />
                    <Slider label="Edge softness" min={0} max={0.4} step={0.01} value={ch.smooth} onChange={(v) => setClip({ chroma: { ...ch, smooth: v } })} onEnd={end} />
                    <Slider label="Remove colour tint" min={0} max={1} step={0.05} value={ch.spill} onChange={(v) => setClip({ chroma: { ...ch, spill: v } })} onEnd={end} />
                  </>
                )}
              </div>
            )}
          </>
        )}

        {tab === 'edit' && sub && (
          <>
            <textarea
              className="input" rows={3} value={sub.text}
              onChange={(e) => dispatch({ type: 'UPDATE_SUB', id: sub.id, patch: { text: e.target.value, words: null }, live: true })}
              onBlur={end}
            />
            <div className="grid grid-cols-2 gap-2">
              {[['Start (s)', 'start'], ['End (s)', 'end']].map(([label, key]) => (
                <label key={key} className="text-xs text-slate-400">
                  {label}
                  <input
                    key={`${sub.id}-${key}-${sub[key].toFixed(2)}`}
                    className="input mt-1" type="number" step="0.1" min="0" defaultValue={sub[key].toFixed(2)}
                    onBlur={(e) => {
                      const v = parseFloat(e.target.value);
                      if (!Number.isFinite(v)) return;
                      const patch = { [key]: Math.max(0, v) };
                      const ns = patch.start ?? sub.start;
                      const ne = patch.end ?? sub.end;
                      if (ne > ns + 0.1) dispatch({ type: 'UPDATE_SUB', id: sub.id, patch });
                    }}
                  />
                </label>
              ))}
            </div>
            <p className="text-[10px] text-slate-500">Caption looks too early or late? Hold it on the timeline and slide it, or change the start time here.</p>
            <div className="flex gap-2">
              <button className="btn flex-1" onClick={() => onSeek(sub.start)}>Go to caption</button>
              <button className="btn flex-1" onClick={onDelete}><Trash2 size={16} /> Delete</button>
            </div>
          </>
        )}

        {tab === 'look' && (
          <>
            <div>
              <div className="text-xs text-slate-400 mb-1">Video shape</div>
              <div className="grid grid-cols-5 gap-1.5">
                {ASPECT_LIST.map((a) => (
                  <button key={a.id} onClick={() => dispatch({ type: 'SET_ASPECT', aspect: a.id })} className={`h-9 rounded-xl text-xs ${project.aspect === a.id ? 'on' : 'bg-white/10'}`}>{a.id}</button>
                ))}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400 mb-1">Effects and looks</div>
              <div className="grid grid-cols-3 gap-2">
                {FILTER_PRESETS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => dispatch({ type: 'SET_FILTER', patch: { ...p.values, preset: p.id } })}
                    className={`rounded-xl p-1 text-[11px] ${f.preset === p.id ? 'on' : 'bg-white/5'}`}
                  >
                    <div className="h-8 rounded-lg mb-1" style={{ background: 'linear-gradient(135deg,#f97316,#22d3ee,#a855f7)', filter: buildFilter(p.values) }} />
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-1">
              {sliders.map(([label, key, min, max, unit]) => (
                <Slider key={key} label={label} unit={unit} min={min} max={max} value={f[key] || 0} onChange={(v) => setF({ [key]: v })} onEnd={end} />
              ))}
            </div>
          </>
        )}

        {tab === 'text' && (
          <>
            <div className="grid grid-cols-2 gap-2">
              <button className="btn-primary" onClick={onAutoCaptions}>Auto captions</button>
              <button className="btn" onClick={addCaption}><Plus size={16} /> Add one</button>
            </div>
            <div>
              <div className="text-xs text-slate-400 mb-1">Caption styles</div>
              <div className="flex flex-wrap gap-1.5">
                {CAPTION_PRESETS.map((p) => (
                  <button key={p.id} className="chip" onClick={() => dispatch({ type: 'SET_SUBSTYLE', patch: p.style })}>{p.name}</button>
                ))}
              </div>
            </div>
            <label className="block text-xs text-slate-400">
              Font
              <select className="input mt-1" value={st.font} onChange={(e) => setSn({ font: e.target.value })}>
                {FONT_CHOICES.map((fc) => <option key={fc.id} value={fc.css}>{fc.name}</option>)}
              </select>
            </label>
            <Slider label="Text size" min={3} max={12} step={0.5} value={st.size} onChange={(v) => setS({ size: v })} onEnd={end} />
            <div className="grid grid-cols-4 gap-2 text-[10px] text-slate-400">
              {[['Text', 'color'], ['Active', 'highlight'], ['Pill', 'bg'], ['Outline', 'strokeColor']].map(([label, key]) => (
                <label key={key} className="flex flex-col items-center gap-1">
                  {label}
                  <input type="color" value={st[key]} onChange={(e) => setS({ [key]: e.target.value })} onBlur={end} />
                </label>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <Toggle label="Pill background" on={st.pill} onClick={() => setSn({ pill: !st.pill })} />
              <Toggle label="Word highlight" on={st.highlightOn} onClick={() => setSn({ highlightOn: !st.highlightOn })} />
              <Toggle label="Shadow" on={st.shadow} onClick={() => setSn({ shadow: !st.shadow })} />
              <Toggle label="CAPITALS" on={st.uppercase} onClick={() => setSn({ uppercase: !st.uppercase })} />
            </div>
            <Slider label="Outline width" min={0} max={30} value={st.stroke} onChange={(v) => setS({ stroke: v })} onEnd={end} />
            <Slider label="Pill opacity" min={0} max={1} step={0.05} value={st.bgOpacity} onChange={(v) => setS({ bgOpacity: v })} onEnd={end} />
            <Slider label="Pill roundness" min={0} max={1.5} step={0.1} value={st.radius} onChange={(v) => setS({ radius: v })} onEnd={end} />
            <div>
              <div className="text-xs text-slate-400 mb-1">Animation</div>
              <div className="grid grid-cols-3 gap-1.5">
                {[['none', 'None'], ['pop', 'Pop'], ['fade', 'Fade']].map(([v, l]) => (
                  <Toggle key={v} label={l} on={st.anim === v} onClick={() => setSn({ anim: v })} />
                ))}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {['top', 'middle', 'bottom'].map((p) => (
                <Toggle key={p} label={p[0].toUpperCase() + p.slice(1)} on={st.position === p} onClick={() => setSn({ position: p })} />
              ))}
            </div>
            <Slider label="Nudge up / down" unit="%" min={-30} max={30} value={st.offsetY} onChange={(v) => setS({ offsetY: v })} onEnd={end} />
            {project.subtitles.length > 0 && (
              <div className="rounded-2xl bg-white/5 p-2.5 space-y-1.5">
                <div className="text-xs font-medium">Words per caption ({wordsNow} words)</div>
                <div className="flex flex-wrap gap-1.5">
                  {[1, 2, 3, 4, 5, 6, 8].map((n) => (
                    <button key={n} className="chip" onClick={() => dispatch({ type: 'SET_SUBS', subs: regroupSubs(project.subtitles, n, n === 1 ? 20 : 34) })}>{n}</button>
                  ))}
                </div>
              </div>
            )}
            <div>
              <div className="text-xs text-slate-400 mb-1">Captions ({project.subtitles.length})</div>
              {project.subtitles.length === 0 && <p className="text-xs text-slate-500">No captions yet.</p>}
              <div className="space-y-1">
                {project.subtitles.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => { onSelect({ type: 'sub', id: s.id }); onSeek(s.start); }}
                    className="w-full text-left rounded-xl bg-white/5 hover:bg-white/10 px-2 py-1.5 text-xs"
                  >
                    <span className="text-slate-400 tabular-nums">{formatTime(s.start)}</span> {s.text}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
