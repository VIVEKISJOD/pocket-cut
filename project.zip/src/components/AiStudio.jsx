import React, { useEffect, useRef, useState } from 'react';
import { Loader2, Sparkles } from 'lucide-react';
import Modal from './Modal';
import {
  FREE_MODELS, chat, formatCaptions, friendlyError, generateScript, parseJsonLoose, polishCaptions, suggestGrades,
} from '../services/openrouter';
import {
  EDITOR_SYSTEM_PROMPT, applyPolished, buildSnapshot, expandCaptionParts, planActions, scriptToSubs,
} from '../services/aiActions';
import { LANGS, WHISPER_MODELS, generateCaptions, stopWorker } from '../utils/captioner';
import { CAPTION_PRESETS, projectDuration } from '../utils/project';
import { clock } from '../utils/clock';

const TABS = [['auto', 'Auto Edit'], ['command', 'Command'], ['script', 'Script'], ['grade', 'Color'], ['format', 'Captions']];
const EXAMPLES = [
  'Split the video at 5 seconds',
  'Remove everything before 3 seconds',
  'Make it cinematic and vertical 9:16',
  'Make the captions bigger and yellow',
];

function Gate({ onOpenSettings }) {
  return (
    <div className="rounded-xl bg-white/5 p-4 text-sm space-y-3">
      <p>This tool uses an online AI model. It is optional and off until you turn it on and add your free OpenRouter key.</p>
      <button className="btn-primary" onClick={onOpenSettings}>Open AI settings</button>
    </div>
  );
}

export default function AiStudio({ onClose, settings, aiReady, project, dispatch, onSeek, onOpenSettings }) {
  const [tab, setTab] = useState('auto');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const abortRef = useRef(null);
  const cancelled = useRef(false);
  const duration = projectDuration(project);
  const eligible = project.clips.filter((c) => c.kind !== 'image' && c.url && c.track !== 'overlay');

  // auto edit
  const [language, setLanguage] = useState(settings.captionLang);
  const [wmodel, setWmodel] = useState(settings.captionModel);
  const [source, setSource] = useState('speech');
  const [presetId, setPresetId] = useState('pop');
  const [maxWords, setMaxWords] = useState(settings.captionWords);
  const [polish, setPolish] = useState(true);
  const [aiLook, setAiLook] = useState(false);
  const [lookText, setLookText] = useState('');
  const [phase, setPhase] = useState('');
  const [pct, setPct] = useState(null);
  const [steps, setSteps] = useState([]);
  // online tools
  const [command, setCommand] = useState('');
  const [editorResult, setEditorResult] = useState(null);
  const [topic, setTopic] = useState('');
  const [tone, setTone] = useState('Energetic');
  const [seconds, setSeconds] = useState(30);
  const [script, setScript] = useState('');
  const [mood, setMood] = useState('');
  const [grades, setGrades] = useState([]);
  const [maxChars, setMaxChars] = useState(32);
  const [capDone, setCapDone] = useState('');

  const base = { apiKey: settings.apiKey.trim(), model: settings.model, fallbackModels: FREE_MODELS.map((m) => m.id) };

  useEffect(() => () => {
    cancelled.current = true;
    stopWorker();
    if (abortRef.current) abortRef.current.abort();
  }, []);

  const run = async (fn) => {
    setBusy(true);
    setError('');
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      await fn(ctrl.signal);
    } catch (e) {
      if (e.name !== 'AbortError') setError(friendlyError(e));
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  };

  const onProg = (d) => {
    if (!d) return;
    if (d.status === 'progress') {
      setPct(Math.round(d.progress || 0));
      setPhase(`Downloading speech model (first time only): ${String(d.file || '').split('/').pop()}`);
    } else if (d.status === 'transcribing') {
      setPct(null);
      setPhase('Listening and writing captions...');
    }
  };

  const runAuto = async () => {
    cancelled.current = false;
    setBusy(true);
    setError('');
    setSteps([]);
    setPct(null);
    const add = (s) => setSteps((x) => [...x, s]);
    try {
      const ids = eligible.map((c) => c.id);
      if (!ids.length) throw new Error('Add a video or audio clip first.');
      setPhase('Starting...');
      let subs = await generateCaptions({
        project, clipIds: ids, language, model: wmodel, mode: source, maxWords,
        onPhase: setPhase, onProgress: onProg, isCancelled: () => cancelled.current,
      });
      if (!subs) return;
      if (!subs.length) throw new Error('No speech was found. For songs, set Sound type to Song lyrics.');
      add(`Wrote ${subs.length} captions with word-by-word timing`);
      if (polish && aiReady) {
        setPhase('AI is proofreading the captions...');
        try {
          const texts = await polishCaptions({ ...base, texts: subs.map((s) => s.text), roman: language === 'hinglish' });
          subs = applyPolished(subs, texts);
          add('AI proofread the captions');
        } catch (e) {
          add(`Skipped AI proofreading: ${friendlyError(e)}`);
        }
      }
      const preset = CAPTION_PRESETS.find((p) => p.id === presetId) || CAPTION_PRESETS[0];
      const actions = [{ type: 'SET_SUBS', subs }, { type: 'SET_SUBSTYLE', patch: preset.style }];
      add(`Applied the ${preset.name} caption style`);
      if (aiLook && aiReady) {
        setPhase('AI is choosing a colour look...');
        try {
          const g = await suggestGrades({ ...base, description: lookText.trim() || 'cinematic social media video' });
          actions.push({ type: 'SET_FILTER', patch: { ...g[0].values, preset: 'custom' } });
          add(`Applied the colour look "${g[0].name}"`);
        } catch (e) {
          add(`Skipped AI colour look: ${friendlyError(e)}`);
        }
      }
      dispatch({ type: 'BATCH', actions });
      add('Done. One tap on Undo reverts all of this.');
      setPhase('');
    } catch (e) {
      if (!cancelled.current) setError(e.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const cancelAuto = () => {
    cancelled.current = true;
    stopWorker();
    setBusy(false);
    setPhase('');
    setPct(null);
  };

  const runEditor = () =>
    run(async (signal) => {
      setEditorResult(null);
      const snapshot = buildSnapshot(project, clock.time);
      const text = await chat({
        ...base, signal, temperature: 0.2,
        messages: [
          { role: 'system', content: EDITOR_SYSTEM_PROMPT },
          { role: 'user', content: `PROJECT STATE:\n${JSON.stringify(snapshot)}\n\nUSER COMMAND:\n${command}` },
        ],
      });
      const json = parseJsonLoose(text);
      const rawActions = Array.isArray(json) ? json : json.actions;
      const plan = planActions(rawActions, project, clock.time);
      if (plan.ops.length) dispatch({ type: 'BATCH', actions: plan.ops });
      if (plan.seekTo !== null) onSeek(plan.seekTo);
      setEditorResult({ message: Array.isArray(json) ? '' : json.message || '', applied: plan.applied, skipped: plan.skipped });
    });

  const runScript = () =>
    run(async (signal) => {
      setScript('');
      setScript(await generateScript({ ...base, signal, topic, tone, seconds }));
    });
  const runGrade = () =>
    run(async (signal) => {
      setGrades([]);
      setGrades(await suggestGrades({ ...base, signal, description: mood }));
    });
  const runFormat = () =>
    run(async (signal) => {
      setCapDone('');
      const items = await formatCaptions({ ...base, signal, subtitles: project.subtitles, maxChars });
      const subs = expandCaptionParts(project.subtitles, items);
      dispatch({ type: 'SET_SUBS', subs });
      setCapDone(`Reformatted: ${project.subtitles.length} captions became ${subs.length}. You can undo it.`);
    });

  const Spinner = busy ? <Loader2 size={16} className="animate-spin" /> : null;
  const online = tab !== 'auto';

  return (
    <Modal wide title="AI studio" icon={<Sparkles size={18} className="text-accent" />} onClose={onClose}>
      <div className="flex gap-1 mb-4 overflow-x-auto">
        {TABS.map(([id, label]) => (
          <button
            key={id}
            onClick={() => { setTab(id); setError(''); }}
            className={`px-3 h-9 rounded-xl text-sm whitespace-nowrap ${tab === id ? 'bg-gradient-to-r from-accent2 to-accent text-white' : 'bg-white/10 text-slate-300'}`}
          >
            {label}
          </button>
        ))}
      </div>

      {online && !aiReady && <Gate onOpenSettings={onOpenSettings} />}

      {tab === 'auto' && (
        <div className="space-y-3">
          <p className="text-xs text-slate-400">
            One tap: listens to the person speaking (or the song) and writes captions with word-by-word timing, then styles them. The listening part works offline and free. AI proofreading and AI colours are optional extras.
          </p>
          <div className="grid grid-cols-2 gap-2">
            <label className="block text-xs text-slate-400 col-span-2">
              Language
              <select className="input mt-1" value={language} onChange={(e) => setLanguage(e.target.value)} disabled={busy}>
                {LANGS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </label>
            <label className="block text-xs text-slate-400">
              Accuracy
              <select className="input mt-1" value={wmodel} onChange={(e) => setWmodel(e.target.value)} disabled={busy}>
                {WHISPER_MODELS.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
            </label>
            <label className="block text-xs text-slate-400">
              Sound type
              <select className="input mt-1" value={source} onChange={(e) => setSource(e.target.value)} disabled={busy}>
                <option value="speech">Person speaking</option>
                <option value="music">Song / background music lyrics</option>
              </select>
            </label>
          </div>
          <div>
            <div className="text-xs text-slate-400 mb-1">Caption style</div>
            <div className="flex flex-wrap gap-1.5">
              {CAPTION_PRESETS.map((p) => (
                <button key={p.id} className={`chip ${presetId === p.id ? 'on' : ''}`} onClick={() => setPresetId(p.id)}>{p.name}</button>
              ))}
            </div>
          </div>
          <label className="block text-xs text-slate-400">
            Words per caption: {maxWords}
            <input type="range" min={2} max={10} value={maxWords} onChange={(e) => setMaxWords(Number(e.target.value))} disabled={busy} />
          </label>
          <label className={`flex items-center gap-2 text-sm ${aiReady ? '' : 'opacity-50'}`}>
            <input type="checkbox" checked={polish && aiReady} disabled={!aiReady || busy} onChange={(e) => setPolish(e.target.checked)} />
            Proofread captions with AI {aiReady ? '' : '(needs AI on)'}
          </label>
          <label className={`flex items-center gap-2 text-sm ${aiReady ? '' : 'opacity-50'}`}>
            <input type="checkbox" checked={aiLook && aiReady} disabled={!aiReady || busy} onChange={(e) => setAiLook(e.target.checked)} />
            Pick a colour look with AI {aiReady ? '' : '(needs AI on)'}
          </label>
          {aiLook && aiReady && (
            <input className="input" placeholder="Mood, e.g. travel vlog, gym, party" value={lookText} onChange={(e) => setLookText(e.target.value)} />
          )}

          {busy && (
            <div className="rounded-xl bg-white/5 p-3 text-sm">
              <div className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                <span className="flex-1">{phase || 'Working...'}</span>
                {pct !== null && <span className="tabular-nums">{pct}%</span>}
              </div>
              {pct !== null && (
                <div className="mt-2 h-1.5 rounded bg-white/10 overflow-hidden">
                  <div className="h-full bg-accent" style={{ width: `${pct}%` }} />
                </div>
              )}
            </div>
          )}
          {steps.length > 0 && (
            <ul className="list-disc pl-5 text-xs text-emerald-300 space-y-0.5">
              {steps.map((s, i) => <li key={i}>{s}</li>)}
            </ul>
          )}
          <div className="flex gap-2">
            {busy ? (
              <button className="btn flex-1" onClick={cancelAuto}>Cancel</button>
            ) : (
              <button className="btn-primary flex-1 h-11" onClick={runAuto} disabled={!eligible.length}>Edit my video automatically</button>
            )}
          </div>
          {!eligible.length && <p className="text-xs text-amber-300">Add a video or audio clip first.</p>}
        </div>
      )}

      {tab === 'command' && aiReady && (
        <div className="space-y-3">
          <p className="text-xs text-slate-400">Tell the AI what to change. It edits your project, and one tap on Undo reverses everything it did.</p>
          <textarea className="input" rows={3} placeholder="Example: split at 8 seconds and delete the second half" value={command} onChange={(e) => setCommand(e.target.value)} />
          <div className="flex flex-wrap gap-1.5">
            {EXAMPLES.map((ex) => <button key={ex} className="chip" onClick={() => setCommand(ex)}>{ex}</button>)}
          </div>
          <div className="flex gap-2">
            <button className="btn-primary flex-1" onClick={runEditor} disabled={busy || !command.trim()}>{Spinner} Run command</button>
            {busy && <button className="btn" onClick={() => abortRef.current && abortRef.current.abort()}>Stop</button>}
          </div>
          {editorResult && (
            <div className="rounded-xl bg-white/5 p-3 text-sm space-y-2">
              {editorResult.message && <p>{editorResult.message}</p>}
              {editorResult.applied.length > 0 && (
                <ul className="list-disc pl-5 text-emerald-300 text-xs space-y-0.5">{editorResult.applied.map((a, i) => <li key={i}>{a}</li>)}</ul>
              )}
              {editorResult.skipped.length > 0 && (
                <ul className="list-disc pl-5 text-amber-300 text-xs space-y-0.5">{editorResult.skipped.map((a, i) => <li key={i}>{a}</li>)}</ul>
              )}
              {!editorResult.applied.length && !editorResult.skipped.length && <p className="text-xs text-slate-400">No edits were made.</p>}
            </div>
          )}
        </div>
      )}

      {tab === 'script' && aiReady && (
        <div className="space-y-3">
          <input className="input" placeholder="What is the video about?" value={topic} onChange={(e) => setTopic(e.target.value)} />
          <div className="grid grid-cols-2 gap-2">
            <select className="input" value={tone} onChange={(e) => setTone(e.target.value)}>
              {['Energetic', 'Funny', 'Calm', 'Professional', 'Dramatic'].map((t) => <option key={t}>{t}</option>)}
            </select>
            <select className="input" value={seconds} onChange={(e) => setSeconds(Number(e.target.value))}>
              {[15, 30, 45, 60].map((s) => <option key={s} value={s}>{s} seconds</option>)}
            </select>
          </div>
          <button className="btn-primary w-full" onClick={runScript} disabled={busy || !topic.trim()}>{Spinner} Generate video script</button>
          {script && (
            <>
              <textarea className="input" rows={8} value={script} onChange={(e) => setScript(e.target.value)} />
              <div className="flex gap-2">
                <button className="btn flex-1" onClick={() => { dispatch({ type: 'SET_SUBS', subs: scriptToSubs(script, duration) }); onClose(); }}>Use as captions</button>
                <button className="btn" onClick={() => navigator.clipboard && navigator.clipboard.writeText(script)}>Copy</button>
              </div>
            </>
          )}
        </div>
      )}

      {tab === 'grade' && aiReady && (
        <div className="space-y-3">
          <input className="input" placeholder="Describe the mood (e.g. sunset beach vlog)" value={mood} onChange={(e) => setMood(e.target.value)} />
          <button className="btn-primary w-full" onClick={runGrade} disabled={busy || !mood.trim()}>{Spinner} Suggest color grades</button>
          <div className="space-y-2">
            {grades.map((g, i) => (
              <div key={i} className="rounded-xl bg-white/5 p-3 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{g.name}</div>
                  <div className="text-xs text-slate-400">{g.why}</div>
                </div>
                <button className="btn" onClick={() => dispatch({ type: 'SET_FILTER', patch: { ...g.values, preset: 'custom' } })}>Apply</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'format' && aiReady && (
        <div className="space-y-3">
          <p className="text-xs text-slate-400">The AI fixes punctuation and breaks long captions into short, readable lines.</p>
          <label className="block text-xs text-slate-400">
            Longest line: {maxChars} characters
            <input type="range" min={16} max={60} value={maxChars} onChange={(e) => setMaxChars(Number(e.target.value))} />
          </label>
          <button className="btn-primary w-full" onClick={runFormat} disabled={busy || project.subtitles.length === 0}>{Spinner} Auto-format caption line lengths</button>
          {project.subtitles.length === 0 && <p className="text-xs text-amber-300">No captions yet. Use the Auto Edit tab first.</p>}
          {capDone && <p className="text-sm text-emerald-300">{capDone}</p>}
        </div>
      )}

      {error && <p className="mt-3 text-sm text-rose-300">{error}</p>}
    </Modal>
  );
}
