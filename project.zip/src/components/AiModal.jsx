import React, { useEffect, useRef, useState } from 'react';
import { Loader2, Sparkles } from 'lucide-react';
import Modal from './Modal';
import {
  FREE_MODELS, chat, formatCaptions, friendlyError, generateScript, parseJsonLoose, suggestGrades,
} from '../services/openrouter';
import {
  EDITOR_SYSTEM_PROMPT, buildSnapshot, expandCaptionParts, planActions, scriptToSubs,
} from '../services/aiActions';

const TABS = [['editor', 'AI Editor'], ['script', 'Script'], ['grade', 'Color'], ['captions', 'Captions']];
const EXAMPLES = [
  'Split the video at 5 seconds',
  'Make it cinematic and vertical 9:16',
  'Remove the last 3 seconds of the first clip',
  'Make the captions bigger and yellow',
];

export default function AiModal({ onClose, settings, project, time, duration, dispatch, onSeek }) {
  const [tab, setTab] = useState('editor');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const abortRef = useRef(null);

  const [command, setCommand] = useState('');
  const [editorResult, setEditorResult] = useState(null);
  const [topic, setTopic] = useState('');
  const [tone, setTone] = useState('Energetic');
  const [seconds, setSeconds] = useState(30);
  const [script, setScript] = useState('');
  const [mood, setMood] = useState('');
  const [grades, setGrades] = useState([]);
  const [maxChars, setMaxChars] = useState(32);
  const [capDone, setCapDone] = useState('');

  const base = {
    apiKey: settings.apiKey.trim(),
    model: settings.model,
    fallbackModels: FREE_MODELS.map((m) => m.id),
  };

  useEffect(() => () => {
    if (abortRef.current) abortRef.current.abort();
  }, []);

  const run = async (fn) => {
    setBusy(true);
    setError('');
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      await fn(ctrl.signal);
    } catch (e) {
      if (e.name !== 'AbortError') setError(friendlyError(e));
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  };

  const runEditor = () =>
    run(async (signal) => {
      setEditorResult(null);
      const snapshot = buildSnapshot(project, time);
      const text = await chat({
        ...base, signal, temperature: 0.2,
        messages: [
          { role: 'system', content: EDITOR_SYSTEM_PROMPT },
          { role: 'user', content: `PROJECT STATE:\n${JSON.stringify(snapshot)}\n\nUSER COMMAND:\n${command}` },
        ],
      });
      const json = parseJsonLoose(text);
      const rawActions = Array.isArray(json) ? json : json.actions;
      const plan = planActions(rawActions, project, time);
      if (plan.ops.length) dispatch({ type: 'BATCH', actions: plan.ops });
      if (plan.seekTo !== null) onSeek(plan.seekTo);
      setEditorResult({ message: Array.isArray(json) ? '' : json.message || '', applied: plan.applied, skipped: plan.skipped });
    });

  const runScript = () =>
    run(async (signal) => {
      setScript('');
      setScript(await generateScript({ ...base, signal, topic, tone, seconds }));
    });

  const runGrade = () =>
    run(async (signal) => {
      setGrades([]);
      setGrades(await suggestGrades({ ...base, signal, description: mood }));
    });

  const runCaptions = () =>
    run(async (signal) => {
      setCapDone('');
      const items = await formatCaptions({ ...base, signal, subtitles: project.subtitles, maxChars });
      const subs = expandCaptionParts(project.subtitles, items);
      dispatch({ type: 'SET_SUBS', subs });
      setCapDone(`Reformatted: ${project.subtitles.length} captions became ${subs.length}. You can undo it.`);
    });

  const Spinner = busy ? <Loader2 size={16} className="animate-spin" /> : null;

  return (
    <Modal wide title="AI assistant" icon={<Sparkles size={18} className="text-cyan-300" />} onClose={onClose}>
      <div className="flex gap-1 mb-4 overflow-x-auto">
        {TABS.map(([id, label]) => (
          <button
            key={id}
            onClick={() => { setTab(id); setError(''); }}
            className={`px-3 h-9 rounded-xl text-sm whitespace-nowrap ${tab === id ? 'bg-gradient-to-r from-violet-500 to-cyan-500 text-white' : 'bg-white/10 text-slate-300'}`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'editor' && (
        <div className="space-y-3">
          <p className="text-xs text-slate-400">Tell the AI what to change. It edits your project, and one tap on Undo reverses everything it did.</p>
          <textarea className="input" rows={3} placeholder="Example: split at 8 seconds and delete the second half" value={command} onChange={(e) => setCommand(e.target.value)} />
          <div className="flex flex-wrap gap-1.5">
            {EXAMPLES.map((ex) => (
              <button key={ex} className="chip" onClick={() => setCommand(ex)}>{ex}</button>
            ))}
          </div>
          <div className="flex gap-2">
            <button className="btn-primary flex-1" onClick={runEditor} disabled={busy || !command.trim()}>{Spinner} Run command</button>
            {busy && <button className="btn" onClick={() => abortRef.current && abortRef.current.abort()}>Stop</button>}
          </div>
          {editorResult && (
            <div className="rounded-xl bg-white/5 p-3 text-sm space-y-2">
              {editorResult.message && <p>{editorResult.message}</p>}
              {editorResult.applied.length > 0 && (
                <ul className="list-disc pl-5 text-emerald-300 text-xs space-y-0.5">
                  {editorResult.applied.map((a, i) => <li key={i}>{a}</li>)}
                </ul>
              )}
              {editorResult.skipped.length > 0 && (
                <ul className="list-disc pl-5 text-amber-300 text-xs space-y-0.5">
                  {editorResult.skipped.map((a, i) => <li key={i}>{a}</li>)}
                </ul>
              )}
              {!editorResult.applied.length && !editorResult.skipped.length && <p className="text-xs text-slate-400">No edits were made.</p>}
            </div>
          )}
        </div>
      )}

      {tab === 'script' && (
        <div className="space-y-3">
          <input className="input" placeholder="What is the video about?" value={topic} onChange={(e) => setTopic(e.target.value)} />
          <div className="grid grid-cols-2 gap-2">
            <select className="input" value={tone} onChange={(e) => setTone(e.target.value)}>
              {['Energetic', 'Funny', 'Calm', 'Professional', 'Dramatic'].map((t) => <option key={t}>{t}</option>)}
            </select>
            <select className="input" value={seconds} onChange={(e) => setSeconds(Number(e.target.value))}>
              {[15, 30, 45, 60].map((s) => <option key={s} value={s}>{s} seconds</option>)}
            </select>
          </div>
          <button className="btn-primary w-full" onClick={runScript} disabled={busy || !topic.trim()}>{Spinner} Generate video script</button>
          {script && (
            <>
              <textarea className="input" rows={8} value={script} onChange={(e) => setScript(e.target.value)} />
              <div className="flex gap-2">
                <button
                  className="btn flex-1"
                  onClick={() => {
                    dispatch({ type: 'SET_SUBS', subs: scriptToSubs(script, duration) });
                    onClose();
                  }}
                >
                  Use as captions
                </button>
                <button className="btn" onClick={() => navigator.clipboard && navigator.clipboard.writeText(script)}>Copy</button>
              </div>
            </>
          )}
        </div>
      )}

      {tab === 'grade' && (
        <div className="space-y-3">
          <input className="input" placeholder="Describe the mood (e.g. sunset beach vlog)" value={mood} onChange={(e) => setMood(e.target.value)} />
          <button className="btn-primary w-full" onClick={runGrade} disabled={busy || !mood.trim()}>{Spinner} Suggest color grades</button>
          <div className="space-y-2">
            {grades.map((g, i) => (
              <div key={i} className="rounded-xl bg-white/5 p-3 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{g.name}</div>
                  <div className="text-xs text-slate-400">{g.why}</div>
                </div>
                <button className="btn" onClick={() => dispatch({ type: 'SET_FILTER', patch: { ...g.values, preset: 'custom' } })}>Apply</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'captions' && (
        <div className="space-y-3">
          <p className="text-xs text-slate-400">The AI fixes punctuation and breaks long captions into short, readable lines.</p>
          <label className="block text-xs text-slate-400">
            Longest line: {maxChars} characters
            <input type="range" min={16} max={60} value={maxChars} onChange={(e) => setMaxChars(Number(e.target.value))} />
          </label>
          <button className="btn-primary w-full" onClick={runCaptions} disabled={busy || project.subtitles.length === 0}>{Spinner} Auto-format caption line lengths</button>
          {project.subtitles.length === 0 && <p className="text-xs text-amber-300">No captions yet. Make some with Captions in the top bar first.</p>}
          {capDone && <p className="text-sm text-emerald-300">{capDone}</p>}
        </div>
      )}

      {error && <p className="mt-3 text-sm text-rose-300">{error}</p>}
    </Modal>
  );
}
