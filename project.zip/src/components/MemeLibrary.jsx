import React, { useEffect, useMemo, useState } from 'react';
import { Download, Loader2, Plus, Search, Smile } from 'lucide-react';
import Modal from './Modal';
import {
  REDDIT_SOURCES, downloadAsFile, giphySearch, imgflipTemplates, redditMemes, saveFileToDevice,
} from '../services/memes';

const TABS = [['reddit', 'Memes'], ['templates', 'Templates'], ['gifs', 'GIFs']];

export default function MemeLibrary({ giphyKey, onAddFile, onOpenSettings, onClose }) {
  const [tab, setTab] = useState('reddit');
  const [sub, setSub] = useState(REDDIT_SOURCES[0][0]);
  const [query, setQuery] = useState('');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);
  const [notice, setNotice] = useState('');
  const [gifQuery, setGifQuery] = useState('');

  useEffect(() => {
    let dead = false;
    const load = async () => {
      setLoading(true);
      setError('');
      setItems([]);
      try {
        let list = [];
        if (tab === 'reddit') list = await redditMemes(sub);
        else if (tab === 'templates') list = await imgflipTemplates();
        else if (giphyKey) list = await giphySearch(giphyKey, gifQuery);
        if (!dead) setItems(list);
      } catch (e) {
        if (!dead) setError(e.message || 'Could not load memes. Check your internet connection.');
      } finally {
        if (!dead) setLoading(false);
      }
    };
    load();
    return () => { dead = true; };
  }, [tab, sub, gifQuery, giphyKey]);

  const shown = useMemo(() => {
    if (tab === 'gifs') return items;
    const q = query.trim().toLowerCase();
    return q ? items.filter((i) => i.title.toLowerCase().includes(q)) : items;
  }, [items, query, tab]);

  const act = async (item, mode) => {
    setBusyId(item.id);
    setNotice('');
    try {
      const file = await downloadAsFile(item);
      if (mode === 'save') {
        saveFileToDevice(file);
        setNotice('Saved to your Downloads.');
      } else {
        await onAddFile(file, { track: 'overlay', ov: { x: 0.5, y: 0.5, s: item.type === 'video' ? 0.6 : 0.55 }, border: false });
        setNotice('Added to the timeline as a layer. Keep browsing to add more.');
      }
    } catch (e) {
      setNotice(e.message || 'That meme could not be downloaded.');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <Modal wide title="Meme library" icon={<Smile size={18} className="text-accent" />} onClose={onClose}>
      <div className="space-y-3">
        <div className="flex gap-1">
          {TABS.map(([id, label]) => (
            <button key={id} onClick={() => { setTab(id); setQuery(''); }} className={`flex-1 h-9 rounded-xl text-sm ${tab === id ? 'bg-gradient-to-r from-accent2 to-accent text-white' : 'bg-white/10 text-slate-300'}`}>{label}</button>
          ))}
        </div>

        {tab === 'reddit' && (
          <div className="flex flex-wrap gap-1.5">
            {REDDIT_SOURCES.map(([id, label]) => (
              <button key={id} className={`chip ${sub === id ? 'on' : ''}`} onClick={() => setSub(id)}>{label}</button>
            ))}
          </div>
        )}

        {tab === 'gifs' && !giphyKey ? (
          <div className="rounded-xl bg-white/5 p-4 text-sm space-y-3">
            <p>GIF search uses GIPHY. Add your own free GIPHY key in Settings to turn it on.</p>
            <button className="btn-primary" onClick={onOpenSettings}>Open settings</button>
          </div>
        ) : (
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (tab === 'gifs') setGifQuery(query.trim());
            }}
          >
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input className="input pl-9" placeholder={tab === 'gifs' ? 'Search GIFs, press Enter' : 'Search by name'} value={query} onChange={(e) => setQuery(e.target.value)} />
            </div>
          </form>
        )}

        {notice && <p className="text-xs text-emerald-300">{notice}</p>}
        {error && <p className="text-sm text-rose-300">{error}</p>}
        {loading && (
          <div className="flex items-center gap-2 text-sm text-slate-300"><Loader2 size={16} className="animate-spin" /> Loading...</div>
        )}

        <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
          {shown.map((item) => (
            <div key={item.id} className="relative rounded-xl overflow-hidden bg-black/40 aspect-square">
              <img src={item.thumb} alt={item.title} loading="lazy" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
              <div className="absolute inset-x-0 bottom-0 flex gap-1 p-1 bg-gradient-to-t from-black/80 to-transparent">
                <button
                  className="flex-1 h-8 rounded-lg bg-white/20 text-xs flex items-center justify-center gap-1 active:scale-95"
                  onClick={() => act(item, 'add')}
                  disabled={busyId === item.id}
                >
                  {busyId === item.id ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />} Add
                </button>
                <button
                  className="w-9 h-8 rounded-lg bg-white/20 flex items-center justify-center active:scale-95"
                  onClick={() => act(item, 'save')}
                  disabled={busyId === item.id}
                  aria-label="Save to device"
                >
                  <Download size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
        {!loading && !error && shown.length === 0 && !(tab === 'gifs' && !giphyKey) && (
          <p className="text-sm text-slate-400 text-center py-4">Nothing found.</p>
        )}
        <p className="text-[10px] text-slate-500">Memes come from public sources and belong to their creators. Check usage rights before posting publicly.</p>
      </div>
    </Modal>
  );
}
