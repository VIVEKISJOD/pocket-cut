import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Film, Layers, Music, Scissors, Trash2, Type, ZoomIn, ZoomOut } from 'lucide-react';
import { clamp, clipDur, clipEnd, formatTime } from '../utils/project';
import { clock, useClockTime } from '../utils/clock';

const LABEL_W = 40;
const RULER_H = 24;
const ROWS = [
  { id: 'overlay', label: 'Layer', Icon: Layers, h: 36 },
  { id: 'video', label: 'Video', Icon: Film, h: 50 },
  { id: 'subs', label: 'Text', Icon: Type, h: 34 },
  { id: 'audio', label: 'Audio', Icon: Music, h: 36 },
];
const COLORS = { video: 'bg-violet-700', overlay: 'bg-fuchsia-700', audio: 'bg-emerald-700', subs: 'bg-amber-600' };

const TrimLeftIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M13 3v18" />
    <rect x="2.5" y="8" width="7" height="8" rx="1.5" strokeDasharray="2.5 2.5" opacity="0.7" />
    <rect x="16" y="8" width="5.5" height="8" rx="1.5" />
  </svg>
);
const TrimRightIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M11 3v18" />
    <rect x="14.5" y="8" width="7" height="8" rx="1.5" strokeDasharray="2.5 2.5" opacity="0.7" />
    <rect x="2.5" y="8" width="5.5" height="8" rx="1.5" />
  </svg>
);

function ToolBtn({ label, onClick, disabled, children }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="w-11 shrink-0 flex flex-col items-center gap-0.5 py-1 rounded-xl bg-white/10 hover:bg-white/20 active:scale-90 transition text-[9px] text-slate-200 disabled:opacity-40"
    >
      {children}
      <span>{label}</span>
    </button>
  );
}

function TimePills({ duration }) {
  const t = useClockTime(100);
  return (
    <div className="flex items-center gap-1.5 text-[11px] tabular-nums">
      <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white font-medium">{formatTime(t)}</span>
      <span className="px-2 py-0.5 rounded-full bg-black/40 text-slate-300">{formatTime(duration)}</span>
    </div>
  );
}

export default function Timeline({
  project, duration, selected, onSelect, onSeek, onSplit, onTrimLeft, onTrimRight, onDelete, dispatch, ui,
}) {
  const scrollRef = useRef(null);
  const rulerRef = useRef(null);
  const headRef = useRef(null);
  const [pps, setPps] = useState(70);
  const [holdKey, setHoldKey] = useState(null);
  const [armedKey, setArmedKey] = useState(null);
  const ppsRef = useRef(pps);
  const uiRef = useRef(ui);
  const projectRef = useRef(project);
  ppsRef.current = pps;
  uiRef.current = ui;
  projectRef.current = project;
  const gesture = useRef(null);
  const pointers = useRef(new Map());
  const pinch = useRef(null);
  const anchor = useRef(null);
  const tap = useRef(null);
  const scrub = useRef(false);

  const totalSec = Math.max(duration + 10, 24);
  const laneW = Math.ceil(totalSec * pps);

  // ---- playhead moves without re-rendering React ----
  const placeHead = (t) => {
    if (headRef.current) headRef.current.style.transform = `translateX(${LABEL_W + t * ppsRef.current}px)`;
  };
  useLayoutEffect(() => {
    placeHead(clock.time);
  }, [pps]);
  useEffect(
    () =>
      clock.subscribe((t) => {
        placeHead(t);
        const el = scrollRef.current;
        if (!el || !clock.playing) return;
        const x = LABEL_W + t * ppsRef.current;
        if (x < el.scrollLeft + LABEL_W || x > el.scrollLeft + el.clientWidth - 40) {
          el.scrollLeft = Math.max(0, x - el.clientWidth * 0.35);
        }
      }),
    [],
  );

  // ---- pinch to zoom ----
  const pinchDist = () => {
    const [a, b] = [...pointers.current.values()];
    return Math.hypot(a.x - b.x, a.y - b.y) || 1;
  };
  const onDownCap = (e) => {
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size === 2) {
      const g = gesture.current;
      if (g) {
        clearTimeout(g.timer);
        if (g.raf) cancelAnimationFrame(g.raf);
        gesture.current = null;
        setHoldKey(null);
        setArmedKey(null);
        if (g.armed && g.moved) dispatch({ type: 'END_GESTURE' });
      }
      scrub.current = false;
      tap.current = null;
      const [a, b] = [...pointers.current.values()];
      const rect = scrollRef.current.getBoundingClientRect();
      const cx = (a.x + b.x) / 2 - rect.left;
      const ct = (scrollRef.current.scrollLeft + cx - LABEL_W) / ppsRef.current;
      pinch.current = { d: pinchDist(), pps: ppsRef.current, ct, cx };
    }
  };
  const onMoveCap = (e) => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch.current && pointers.current.size >= 2) {
      anchor.current = { ct: pinch.current.ct, cx: pinch.current.cx };
      setPps(clamp((pinch.current.pps * pinchDist()) / pinch.current.d, 15, 400));
    }
  };
  const onUpCap = (e) => {
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) pinch.current = null;
  };
  useLayoutEffect(() => {
    if (anchor.current && scrollRef.current) {
      scrollRef.current.scrollLeft = Math.max(0, anchor.current.ct * pps + LABEL_W - anchor.current.cx);
      if (!pinch.current) anchor.current = null;
    }
  }, [pps]);
  const zoomBy = (f) => {
    const el = scrollRef.current;
    anchor.current = { ct: clock.time, cx: LABEL_W + clock.time * ppsRef.current - el.scrollLeft };
    setPps((p) => clamp(p * f, 15, 400));
  };

  // ---- ruler scrubbing ----
  const seekFromRuler = (e) => {
    const left = rulerRef.current.getBoundingClientRect().left;
    onSeek(Math.max(0, (e.clientX - left) / ppsRef.current));
  };

  // ---- lane background: drag to pan, tap to move the playhead ----
  const panDown = (e) => {
    if (e.target !== e.currentTarget) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    tap.current = {
      pid: e.pointerId, x: e.clientX, y: e.clientY,
      sl: scrollRef.current.scrollLeft, st: scrollRef.current.scrollTop, moved: false,
    };
  };
  const panMove = (e) => {
    const s = tap.current;
    if (!s || s.pid !== e.pointerId || pointers.current.size > 1) return;
    const dx = e.clientX - s.x;
    const dy = e.clientY - s.y;
    if (Math.abs(dx) > 6 || Math.abs(dy) > 6) s.moved = true;
    if (s.moved) {
      scrollRef.current.scrollLeft = s.sl - dx;
      scrollRef.current.scrollTop = s.st - dy;
    }
  };
  const panUp = (e) => {
    const s = tap.current;
    if (!s || s.pid !== e.pointerId) return;
    tap.current = null;
    if (!s.moved) {
      onSeek(Math.max(0, (e.clientX - e.currentTarget.getBoundingClientRect().left) / ppsRef.current));
      onSelect(null);
    }
  };

  // ---- hold-to-drag for clips, captions and trim handles ----
  const snapStart = (g, start) => {
    if (!uiRef.current.snap) return Math.max(0, start);
    const th = 8 / ppsRef.current;
    const p = projectRef.current;
    const len = g.type === 'clip' ? clipDur(g.orig) : g.orig.end - g.orig.start;
    const cands = [0, clock.time];
    p.clips.forEach((c) => {
      if (!(g.type === 'clip' && c.id === g.id)) cands.push(c.start, clipEnd(c));
    });
    p.subtitles.forEach((s) => {
      if (!(g.type === 'sub' && s.id === g.id)) cands.push(s.start, s.end);
    });
    let best = start;
    let bd = th;
    for (const c of cands) {
      if (Math.abs(c - start) < bd) { bd = Math.abs(c - start); best = c; }
      if (Math.abs(c - (start + len)) < bd) { bd = Math.abs(c - (start + len)); best = c - len; }
    }
    return Math.max(0, best);
  };
  const clipPatch = (g, dt) => {
    const o = g.orig;
    if (g.mode === 'move') return { start: snapStart(g, o.start + dt) };
    if (g.mode === 'left') {
      const len = o.outPoint - o.inPoint;
      const nd = clamp(dt, Math.max(-o.inPoint, -o.start), len - 0.2);
      return { start: o.start + nd, inPoint: o.inPoint + nd };
    }
    const maxOut = o.kind === 'image' ? 3600 : o.srcDuration;
    return { outPoint: clamp(o.outPoint + dt, o.inPoint + 0.2, maxOut) };
  };
  const subPatch = (g, dt) => {
    const o = g.orig;
    if (g.mode === 'move') {
      const s = snapStart(g, o.start + dt);
      return { start: s, end: s + (o.end - o.start) };
    }
    if (g.mode === 'left') return { start: clamp(o.start + dt, 0, o.end - 0.2) };
    return { end: Math.max(o.start + 0.2, o.end + dt) };
  };
  const endDrag = (e) => {
    const g = gesture.current;
    if (!g || g.pid !== e.pointerId) return;
    clearTimeout(g.timer);
    gesture.current = null;
    setHoldKey(null);
    setArmedKey(null);
    if (g.armed && g.moved) {
      if (g.raf) cancelAnimationFrame(g.raf);
      if (g.pending) dispatch(g.pending);
      dispatch({ type: 'END_GESTURE' });
    }
  };
  const drag = (mode, type, item) => ({
    onPointerDown: (e) => {
      if (pointers.current.size > 1) return;
      e.stopPropagation();
      e.currentTarget.setPointerCapture(e.pointerId);
      onSelect({ type, id: item.id });
      const u = uiRef.current;
      const key = `${type}:${item.id}:${mode}`;
      const g = {
        pid: e.pointerId, mode, type, id: item.id, key, x0: e.clientX, y0: e.clientY, orig: { ...item },
        armed: !u.holdToDrag, moved: false, pan: false, raf: 0, pending: null, timer: 0,
        sl: scrollRef.current.scrollLeft, st: scrollRef.current.scrollTop,
      };
      gesture.current = g;
      if (u.holdToDrag) {
        setHoldKey(key);
        g.timer = setTimeout(() => {
          if (gesture.current === g && !g.pan) {
            g.armed = true;
            setHoldKey(null);
            setArmedKey(key);
            if (uiRef.current.haptics && navigator.vibrate) navigator.vibrate(25);
          }
        }, u.holdMs);
      }
    },
    onPointerMove: (e) => {
      const g = gesture.current;
      if (!g || g.pid !== e.pointerId) return;
      e.stopPropagation();
      const dx = e.clientX - g.x0;
      const dy = e.clientY - g.y0;
      if (!g.armed) {
        // finger moved before the hold finished: treat it as scrolling the timeline
        if (!g.pan && (Math.abs(dx) > 10 || Math.abs(dy) > 10)) {
          g.pan = true;
          clearTimeout(g.timer);
          setHoldKey(null);
        }
        if (g.pan) {
          scrollRef.current.scrollLeft = g.sl - dx;
          scrollRef.current.scrollTop = g.st - dy;
        }
        return;
      }
      if (!g.moved && Math.abs(dx) < 4) return;
      g.moved = true;
      const dt = dx / ppsRef.current;
      g.pending =
        g.type === 'clip'
          ? { type: 'UPDATE_CLIP', id: g.id, patch: clipPatch(g, dt), live: true }
          : { type: 'UPDATE_SUB', id: g.id, patch: subPatch(g, dt), live: true };
      if (!g.raf) {
        g.raf = requestAnimationFrame(() => {
          g.raf = 0;
          if (g.pending) {
            dispatch(g.pending);
            g.pending = null;
          }
        });
      }
    },
    onPointerUp: endDrag,
    onPointerCancel: endDrag,
  });

  const holdBar = (key) =>
    holdKey === key ? <div className="hold-fill" style={{ animationDuration: `${ui.holdMs}ms` }} /> : null;

  const handle = (side, type, item, width) => {
    const key = `${type}:${item.id}:${side}`;
    return (
      <div
        {...drag(side, type, item)}
        className={`absolute inset-y-0 flex items-center justify-center ${armedKey === key ? 'bg-accent' : 'bg-white/40 hover:bg-white/60'}`}
        style={{ width, [side]: 0 }}
      >
        <div className="w-0.5 h-4 bg-white rounded" />
        {holdBar(key)}
      </div>
    );
  };

  const blockCls = (type, id, base, sel) =>
    `absolute top-1 bottom-1 rounded-lg overflow-hidden border-2 ${base} ${sel ? 'border-accent' : 'border-white/15'} ${
      armedKey && armedKey.startsWith(`${type}:${id}:`) ? 'ring-2 ring-white scale-[1.03] z-10 shadow-xl' : ''
    }`;

  const renderClip = (c) => {
    const w = Math.max(6, clipDur(c) * pps);
    const sel = selected && selected.type === 'clip' && selected.id === c.id;
    const hw = clamp(w / 3, 10, 22);
    const style = { left: c.start * pps, width: w };
    if (c.missing) {
      style.backgroundImage = 'repeating-linear-gradient(45deg, rgba(239,68,68,.4) 0 6px, transparent 6px 12px)';
    } else if (ui.showThumbs && c.thumb && c.track !== 'audio') {
      style.backgroundImage = `linear-gradient(rgba(2,6,23,.25), rgba(2,6,23,.55)), url("${c.thumb}")`;
      style.backgroundSize = 'auto 100%';
      style.backgroundRepeat = 'repeat-x';
    } else if (c.track === 'audio') {
      style.backgroundImage = 'repeating-linear-gradient(90deg, rgba(255,255,255,.35) 0 2px, transparent 2px 6px)';
    }
    return (
      <div key={c.id} {...drag('move', 'clip', c)} className={blockCls('clip', c.id, `${COLORS[c.track]} cursor-grab`, sel)} style={style}>
        <div className="pointer-events-none px-2 pt-0.5 text-[11px] font-medium text-white drop-shadow truncate">
          {c.missing ? 'Missing file ' : ''}{c.name} <span className="opacity-70">{clipDur(c).toFixed(1)}s</span>
        </div>
        {holdBar(`clip:${c.id}:move`)}
        {sel && handle('left', 'clip', c, hw)}
        {sel && handle('right', 'clip', c, hw)}
      </div>
    );
  };

  const renderSub = (s) => {
    const w = Math.max(6, (s.end - s.start) * pps);
    const sel = selected && selected.type === 'sub' && selected.id === s.id;
    const hw = clamp(w / 3, 10, 22);
    return (
      <div key={s.id} {...drag('move', 'sub', s)} className={blockCls('sub', s.id, `${COLORS.subs} cursor-grab`, sel)} style={{ left: s.start * pps, width: w }}>
        <div className="pointer-events-none px-2 text-[11px] leading-7 font-medium text-white truncate">{s.text}</div>
        {holdBar(`sub:${s.id}:move`)}
        {sel && handle('left', 'sub', s, hw)}
        {sel && handle('right', 'sub', s, hw)}
      </div>
    );
  };

  const step = pps >= 150 ? 0.5 : pps >= 70 ? 1 : pps >= 35 ? 2 : pps >= 18 ? 5 : 10;
  const labelEvery = Math.max(1, Math.ceil(46 / (pps * step)));
  const ticks = [];
  for (let i = 0; i * step <= totalSec; i++) ticks.push(i);
  const itemsFor = (id) =>
    id === 'subs' ? project.subtitles.map(renderSub) : project.clips.filter((c) => c.track === id).map(renderClip);

  return (
    <div className="flex h-full min-h-0">
      <div className="flex flex-col items-center gap-1 p-1 border-r border-white/10 shrink-0 overflow-y-auto">
        <ToolBtn label="Split" onClick={onSplit}><Scissors size={17} /></ToolBtn>
        <ToolBtn label="Trim L" onClick={onTrimLeft}><TrimLeftIcon /></ToolBtn>
        <ToolBtn label="Trim R" onClick={onTrimRight}><TrimRightIcon /></ToolBtn>
        <ToolBtn label="Delete" onClick={onDelete} disabled={!selected}><Trash2 size={17} /></ToolBtn>
      </div>

      <div className="flex-1 min-w-0 flex flex-col">
        <div className="flex items-center gap-2 px-2 h-8 shrink-0">
          <span className="flex-1 min-w-0 truncate text-[10px] text-slate-500">
            {ui.holdToDrag ? `Hold a clip for ${(ui.holdMs / 1000).toFixed(1)} s to move or trim it` : 'Drag a clip to move it'}
          </span>
          <TimePills duration={duration} />
          <button className="btn-icon w-7 h-7 rounded-lg" onClick={() => zoomBy(1 / 1.4)} aria-label="Zoom out"><ZoomOut size={14} /></button>
          <button className="btn-icon w-7 h-7 rounded-lg" onClick={() => zoomBy(1.4)} aria-label="Zoom in"><ZoomIn size={14} /></button>
        </div>

        <div
          ref={scrollRef}
          className="relative flex-1 min-h-0 overflow-auto"
          style={{ touchAction: 'none' }}
          onContextMenu={(e) => e.preventDefault()}
          onPointerDownCapture={onDownCap}
          onPointerMoveCapture={onMoveCap}
          onPointerUpCapture={onUpCap}
          onPointerCancelCapture={onUpCap}
          onWheel={(e) => {
            if (e.ctrlKey) zoomBy(e.deltaY < 0 ? 1.15 : 1 / 1.15);
          }}
        >
          <div className="relative" style={{ width: LABEL_W + laneW, minHeight: '100%' }}>
            <div className="sticky top-0 z-30 flex bg-slate-900/95" style={{ height: RULER_H }}>
              <div className="sticky left-0 z-50 shrink-0 bg-slate-900" style={{ width: LABEL_W }} />
              <div
                ref={rulerRef}
                className="relative cursor-pointer"
                style={{ width: laneW, touchAction: 'none' }}
                onPointerDown={(e) => {
                  e.currentTarget.setPointerCapture(e.pointerId);
                  scrub.current = true;
                  seekFromRuler(e);
                }}
                onPointerMove={(e) => {
                  if (scrub.current && pointers.current.size < 2) seekFromRuler(e);
                }}
                onPointerUp={() => {
                  scrub.current = false;
                }}
                onPointerCancel={() => {
                  scrub.current = false;
                }}
              >
                {ticks.map((i) => (
                  <div key={i} className="absolute top-0 bottom-0 pointer-events-none" style={{ left: i * step * pps }}>
                    <div className="w-px bg-white/30" style={{ height: i % labelEvery === 0 ? 10 : 5 }} />
                    {i % labelEvery === 0 && (
                      <span className="absolute left-1 top-2 text-[10px] text-slate-400 tabular-nums">
                        {Math.floor((i * step) / 60)}:{String(Math.floor((i * step) % 60)).padStart(2, '0')}
                        {step < 1 && i % 2 === 1 ? '.5' : ''}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {ROWS.map((r) => (
              <div key={r.id} className="flex" style={{ height: r.h }}>
                <div
                  className="sticky left-0 z-40 shrink-0 bg-slate-900 border-b border-white/5 flex flex-col items-center justify-center gap-0.5 text-slate-400"
                  style={{ width: LABEL_W }}
                >
                  <r.Icon size={13} />
                  <span className="text-[8px]">{r.label}</span>
                </div>
                <div
                  className="relative border-b border-white/5"
                  style={{ width: laneW }}
                  onPointerDown={panDown}
                  onPointerMove={panMove}
                  onPointerUp={panUp}
                  onPointerCancel={() => {
                    tap.current = null;
                  }}
                >
                  {itemsFor(r.id)}
                </div>
              </div>
            ))}

            <div ref={headRef} className="pointer-events-none absolute top-0 bottom-0 left-0 z-30 w-0.5 bg-rose-500">
              <div className="absolute top-0 -left-[7px] w-4 h-4 rounded-full bg-rose-500 border-2 border-white" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
