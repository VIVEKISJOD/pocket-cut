import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Film, Layers, Music, Scissors, Trash2, Type, ZoomIn, ZoomOut } from 'lucide-react';
import { clamp, clipDur, clipEnd, formatTime } from '../utils/project';

const LABEL_W = 44;
const ROWS = [
  { id: 'overlay', label: 'PiP', Icon: Layers, h: 44 },
  { id: 'video', label: 'Video', Icon: Film, h: 58 },
  { id: 'subs', label: 'Text', Icon: Type, h: 40 },
  { id: 'audio', label: 'Audio', Icon: Music, h: 44 },
];
const COLORS = { video: 'bg-violet-700', overlay: 'bg-fuchsia-700', audio: 'bg-emerald-700', subs: 'bg-amber-600' };

function clipPatch(g, dt) {
  const o = g.orig;
  if (g.mode === 'move') return { start: Math.max(0, o.start + dt) };
  if (g.mode === 'left') {
    const len = o.outPoint - o.inPoint;
    const nd = clamp(dt, Math.max(-o.inPoint, -o.start), len - 0.2);
    return { start: o.start + nd, inPoint: o.inPoint + nd };
  }
  const maxOut = o.kind === 'image' ? 3600 : o.srcDuration;
  return { outPoint: clamp(o.outPoint + dt, o.inPoint + 0.2, maxOut) };
}

function subPatch(g, dt) {
  const o = g.orig;
  if (g.mode === 'move') {
    const s = Math.max(0, o.start + dt);
    return { start: s, end: s + (o.end - o.start) };
  }
  if (g.mode === 'left') return { start: clamp(o.start + dt, 0, o.end - 0.2) };
  return { end: Math.max(o.start + 0.2, o.end + dt) };
}

export default function Timeline({ project, time, duration, playing, selected, onSelect, onSeek, onSplit, onDelete, dispatch }) {
  const scrollRef = useRef(null);
  const rulerRef = useRef(null);
  const [pps, setPps] = useState(70);
  const ppsRef = useRef(pps);
  ppsRef.current = pps;
  const gesture = useRef(null);
  const pointers = useRef(new Map());
  const pinch = useRef(null);
  const anchor = useRef(null);
  const tap = useRef(null);
  const scrub = useRef(false);

  const totalSec = Math.max(duration + 10, 24);
  const laneW = Math.ceil(totalSec * pps);

  // ----- pinch to zoom (two fingers) -----
  const pinchDist = () => {
    const [a, b] = [...pointers.current.values()];
    return Math.hypot(a.x - b.x, a.y - b.y) || 1;
  };
  const onDownCap = (e) => {
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size === 2) {
      if (gesture.current) {
        const moved = gesture.current.moved;
        gesture.current = null;
        if (moved) dispatch({ type: 'END_GESTURE' });
      }
      scrub.current = false;
      tap.current = null;
      const [a, b] = [...pointers.current.values()];
      const rect = scrollRef.current.getBoundingClientRect();
      const cx = (a.x + b.x) / 2 - rect.left;
      const ct = (scrollRef.current.scrollLeft + cx - LABEL_W) / ppsRef.current;
      pinch.current = { d: pinchDist(), pps: ppsRef.current, ct, cx };
    }
  };
  const onMoveCap = (e) => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch.current && pointers.current.size >= 2) {
      anchor.current = { ct: pinch.current.ct, cx: pinch.current.cx };
      setPps(clamp((pinch.current.pps * pinchDist()) / pinch.current.d, 15, 400));
    }
  };
  const onUpCap = (e) => {
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) {
      pinch.current = null;
      anchor.current = null;
    }
  };
  useLayoutEffect(() => {
    if (anchor.current && scrollRef.current) {
      scrollRef.current.scrollLeft = Math.max(0, anchor.current.ct * pps + LABEL_W - anchor.current.cx);
    }
  }, [pps]);

  const zoomBy = (f) => {
    const el = scrollRef.current;
    anchor.current = { ct: time, cx: LABEL_W + time * ppsRef.current - el.scrollLeft };
    setPps((p) => clamp(p * f, 15, 400));
  };

  // keep the playhead in view while playing
  useEffect(() => {
    if (!playing) return;
    const el = scrollRef.current;
    if (!el) return;
    const x = LABEL_W + time * pps;
    if (x < el.scrollLeft + LABEL_W || x > el.scrollLeft + el.clientWidth - 40) {
      el.scrollLeft = Math.max(0, x - el.clientWidth * 0.35);
    }
  }, [time, playing, pps]);

  // ----- ruler scrubbing -----
  const seekFromRuler = (e) => {
    const left = rulerRef.current.getBoundingClientRect().left;
    onSeek(Math.max(0, (e.clientX - left) / ppsRef.current));
  };
  const rulerDown = (e) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    scrub.current = true;
    seekFromRuler(e);
  };
  const rulerMove = (e) => {
    if (scrub.current && pointers.current.size < 2) seekFromRuler(e);
  };
  const rulerUp = () => {
    scrub.current = false;
  };

  // ----- lane background: drag to pan, tap to move the playhead -----
  const panDown = (e) => {
    if (e.target !== e.currentTarget) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    tap.current = {
      pid: e.pointerId, x: e.clientX, y: e.clientY,
      sl: scrollRef.current.scrollLeft, st: scrollRef.current.scrollTop, moved: false,
    };
  };
  const panMove = (e) => {
    const s = tap.current;
    if (!s || s.pid !== e.pointerId || pointers.current.size > 1) return;
    const dx = e.clientX - s.x;
    const dy = e.clientY - s.y;
    if (Math.abs(dx) > 6 || Math.abs(dy) > 6) s.moved = true;
    if (s.moved) {
      scrollRef.current.scrollLeft = s.sl - dx;
      scrollRef.current.scrollTop = s.st - dy;
    }
  };
  const panUp = (e) => {
    const s = tap.current;
    if (!s || s.pid !== e.pointerId) return;
    tap.current = null;
    if (!s.moved) {
      onSeek(Math.max(0, (e.clientX - e.currentTarget.getBoundingClientRect().left) / ppsRef.current));
      onSelect(null);
    }
  };

  // ----- dragging / trimming blocks -----
  const endDrag = (e) => {
    const g = gesture.current;
    if (!g || g.pid !== e.pointerId) return;
    gesture.current = null;
    if (g.moved) dispatch({ type: 'END_GESTURE' });
  };
  const drag = (mode, type, item) => ({
    onPointerDown: (e) => {
      if (pointers.current.size > 1) return;
      e.stopPropagation();
      e.currentTarget.setPointerCapture(e.pointerId);
      onSelect({ type, id: item.id });
      gesture.current = { pid: e.pointerId, mode, type, id: item.id, x0: e.clientX, orig: { ...item }, moved: false };
    },
    onPointerMove: (e) => {
      const g = gesture.current;
      if (!g || g.pid !== e.pointerId) return;
      e.stopPropagation();
      if (!g.moved && Math.abs(e.clientX - g.x0) < 4) return;
      g.moved = true;
      const dt = (e.clientX - g.x0) / ppsRef.current;
      if (g.type === 'clip') dispatch({ type: 'UPDATE_CLIP', id: g.id, patch: clipPatch(g, dt), live: true });
      else dispatch({ type: 'UPDATE_SUB', id: g.id, patch: subPatch(g, dt), live: true });
    },
    onPointerUp: endDrag,
    onPointerCancel: endDrag,
  });

  const handle = (side, type, item, width) => (
    <div
      {...drag(side, type, item)}
      className="absolute inset-y-0 bg-white/40 hover:bg-white/60 flex items-center justify-center"
      style={{ width, [side]: 0 }}
    >
      <div className="w-0.5 h-4 bg-white rounded" />
    </div>
  );

  const renderClip = (c) => {
    const w = Math.max(6, clipDur(c) * pps);
    const sel = selected && selected.type === 'clip' && selected.id === c.id;
    const hw = clamp(w / 3, 10, 22);
    const style = { left: c.start * pps, width: w };
    if (c.thumb && c.track !== 'audio') {
      style.backgroundImage = `linear-gradient(rgba(2,6,23,.25), rgba(2,6,23,.55)), url("${c.thumb}")`;
      style.backgroundSize = 'auto 100%';
      style.backgroundRepeat = 'repeat-x';
    } else if (c.track === 'audio') {
      style.backgroundImage = 'repeating-linear-gradient(90deg, rgba(255,255,255,.35) 0 2px, transparent 2px 6px)';
    }
    return (
      <div
        key={c.id}
        {...drag('move', 'clip', c)}
        className={`absolute top-1 bottom-1 rounded-lg overflow-hidden border-2 cursor-grab ${COLORS[c.track]} ${sel ? 'border-cyan-300' : 'border-white/15'}`}
        style={style}
      >
        <div className="pointer-events-none px-2 pt-0.5 text-[11px] font-medium text-white drop-shadow truncate">
          {c.name} <span className="opacity-70">{clipDur(c).toFixed(1)}s</span>
        </div>
        {sel && handle('left', 'clip', c, hw)}
        {sel && handle('right', 'clip', c, hw)}
      </div>
    );
  };

  const renderSub = (s) => {
    const w = Math.max(6, (s.end - s.start) * pps);
    const sel = selected && selected.type === 'sub' && selected.id === s.id;
    const hw = clamp(w / 3, 10, 22);
    return (
      <div
        key={s.id}
        {...drag('move', 'sub', s)}
        className={`absolute top-1 bottom-1 rounded-lg overflow-hidden border-2 cursor-grab ${COLORS.subs} ${sel ? 'border-cyan-300' : 'border-white/15'}`}
        style={{ left: s.start * pps, width: w }}
      >
        <div className="pointer-events-none px-2 text-[11px] leading-8 font-medium text-white truncate">{s.text}</div>
        {sel && handle('left', 'sub', s, hw)}
        {sel && handle('right', 'sub', s, hw)}
      </div>
    );
  };

  const step = pps >= 150 ? 0.5 : pps >= 70 ? 1 : pps >= 35 ? 2 : pps >= 18 ? 5 : 10;
  const labelEvery = Math.max(1, Math.ceil(46 / (pps * step)));
  const ticks = [];
  for (let i = 0; i * step <= totalSec; i++) ticks.push(i);

  const itemsFor = (id) => {
    if (id === 'subs') return project.subtitles.map(renderSub);
    return project.clips.filter((c) => c.track === id).map(renderClip);
  };

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="flex items-center gap-1.5 px-2 py-1.5 border-b border-white/10 shrink-0">
        <button className="btn h-9" onClick={onSplit}>
          <Scissors size={16} /> Split
        </button>
        <button className="btn h-9" onClick={onDelete} disabled={!selected}>
          <Trash2 size={16} /> Delete
        </button>
        <div className="flex-1" />
        <span className="text-xs text-slate-400 tabular-nums hidden sm:block">
          {formatTime(time)} / {formatTime(duration)}
        </span>
        <button className="btn-icon h-9 w-9" onClick={() => zoomBy(1 / 1.4)} aria-label="Zoom out">
          <ZoomOut size={16} />
        </button>
        <button className="btn-icon h-9 w-9" onClick={() => zoomBy(1.4)} aria-label="Zoom in">
          <ZoomIn size={16} />
        </button>
      </div>

      <div
        ref={scrollRef}
        className="relative flex-1 min-h-0 overflow-auto"
        style={{ touchAction: 'none' }}
        onPointerDownCapture={onDownCap}
        onPointerMoveCapture={onMoveCap}
        onPointerUpCapture={onUpCap}
        onPointerCancelCapture={onUpCap}
        onWheel={(e) => {
          if (e.ctrlKey) zoomBy(e.deltaY < 0 ? 1.15 : 1 / 1.15);
        }}
      >
        <div className="relative" style={{ width: LABEL_W + laneW, minHeight: '100%' }}>
          <div className="sticky top-0 z-30 flex bg-slate-900/95" style={{ height: 26 }}>
            <div className="sticky left-0 z-50 shrink-0 bg-slate-900" style={{ width: LABEL_W }} />
            <div
              ref={rulerRef}
              className="relative cursor-pointer"
              style={{ width: laneW, touchAction: 'none' }}
              onPointerDown={rulerDown}
              onPointerMove={rulerMove}
              onPointerUp={rulerUp}
              onPointerCancel={rulerUp}
            >
              {ticks.map((i) => (
                <div key={i} className="absolute top-0 bottom-0 pointer-events-none" style={{ left: i * step * pps }}>
                  <div className="w-px bg-white/30" style={{ height: i % labelEvery === 0 ? 10 : 5 }} />
                  {i % labelEvery === 0 && (
                    <span className="absolute left-1 top-2.5 text-[10px] text-slate-400 tabular-nums">
                      {Math.floor((i * step) / 60)}:{String(Math.floor((i * step) % 60)).padStart(2, '0')}
                      {step < 1 && i % 2 === 1 ? '.5' : ''}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {ROWS.map((r) => (
            <div key={r.id} className="flex" style={{ height: r.h }}>
              <div
                className="sticky left-0 z-40 shrink-0 bg-slate-900 border-b border-white/5 flex flex-col items-center justify-center gap-0.5 text-slate-400"
                style={{ width: LABEL_W }}
              >
                <r.Icon size={14} />
                <span className="text-[9px]">{r.label}</span>
              </div>
              <div
                className="relative border-b border-white/5"
                style={{ width: laneW }}
                onPointerDown={panDown}
                onPointerMove={panMove}
                onPointerUp={panUp}
                onPointerCancel={() => {
                  tap.current = null;
                }}
              >
                {itemsFor(r.id)}
              </div>
            </div>
          ))}

          <div className="pointer-events-none absolute top-0 bottom-0 z-30 w-0.5 bg-rose-500" style={{ left: LABEL_W + time * pps }}>
            <div className="absolute -top-0 -left-[7px] w-4 h-4 rounded-full bg-rose-500 border-2 border-white" />
          </div>
        </div>
      </div>
    </div>
  );
}
