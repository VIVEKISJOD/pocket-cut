import React from 'react';
import { Download, Film, Layers, Mic, Music, Pause, Play, Smile, Sparkles, Square } from 'lucide-react';

const SIZE = 'clamp(150px, 46vh, 230px)';

function Item({ pos, icon, label, onClick, active }) {
  return (
    <button
      onClick={onClick}
      className={`absolute flex flex-col items-center gap-0.5 text-[11px] font-medium active:scale-90 transition ${pos} ${active ? 'text-rose-400' : 'text-slate-100'}`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

export default function RadialMenu({
  onMedia, onLayer, onAudio, onRec, recording, onAi, onMemes, onPlay, playing, canPlay, onExport, canExport,
}) {
  return (
    <div className="h-full w-full flex flex-col items-center justify-between py-1">
      <div className="w-full flex justify-end">
        <button
          onClick={onExport}
          disabled={!canExport}
          aria-label="Export"
          className="w-11 h-11 rounded-full bg-white text-slate-900 flex items-center justify-center active:scale-90 transition disabled:opacity-40"
        >
          <Download size={20} />
        </button>
      </div>

      <div className="relative rounded-full panel" style={{ width: SIZE, height: SIZE }}>
        <Item pos="left-1/2 -translate-x-1/2 top-[9%]" icon={<Film size={22} />} label="Media" onClick={onMedia} />
        <Item pos="right-[8%] top-1/2 -translate-y-1/2" icon={<Music size={22} />} label="Audio" onClick={onAudio} />
        <Item
          pos="left-1/2 -translate-x-1/2 bottom-[9%]"
          icon={recording ? <Square size={22} fill="currentColor" /> : <Mic size={22} />}
          label={recording ? 'Stop' : 'REC'}
          onClick={onRec}
          active={recording}
        />
        <Item pos="left-[8%] top-1/2 -translate-y-1/2" icon={<Layers size={22} />} label="Layer" onClick={onLayer} />
        <button
          onClick={onAi}
          aria-label="AI"
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-br from-accent2 to-accent text-white flex flex-col items-center justify-center shadow-lg active:scale-90 transition"
          style={{ width: '38%', height: '38%' }}
        >
          <Sparkles size={20} />
          <span className="text-sm font-bold leading-none mt-0.5">AI</span>
        </button>
      </div>

      <div className="w-full flex items-center justify-between">
        <button onClick={onMemes} aria-label="Memes" className="w-11 h-11 rounded-xl panel flex items-center justify-center active:scale-90 transition">
          <Smile size={22} />
        </button>
        <button
          onClick={onPlay}
          disabled={!canPlay}
          aria-label={playing ? 'Pause' : 'Play'}
          className="w-12 h-12 rounded-full bg-white/15 border border-white/20 flex items-center justify-center active:scale-90 transition disabled:opacity-40"
        >
          {playing ? <Pause size={22} /> : <Play size={22} fill="currentColor" />}
        </button>
      </div>
    </div>
  );
}
