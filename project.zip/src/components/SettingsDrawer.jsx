import React, { useState } from 'react';
import { Eye, EyeOff, Loader2, Maximize, Settings } from 'lucide-react';
import Modal from './Modal';
import { FREE_MODELS, friendlyError, testConnection } from '../services/openrouter';

function Switch({ checked, onChange }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`relative w-12 h-7 rounded-full transition shrink-0 ${checked ? 'bg-cyan-500' : 'bg-white/20'}`}
    >
      <span className={`absolute top-0.5 w-6 h-6 rounded-full bg-white transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`} />
    </button>
  );
}

export default function SettingsDrawer({ settings, update, onClose, onFullscreen }) {
  const [show, setShow] = useState(false);
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState(null);
  const isCustom = !FREE_MODELS.some((m) => m.id === settings.model);
  const [custom, setCustom] = useState(isCustom);

  const test = async () => {
    setTesting(true);
    setResult(null);
    try {
      const out = await testConnection({
        apiKey: settings.apiKey.trim(),
        model: settings.model,
        fallbackModels: FREE_MODELS.map((m) => m.id),
      });
      setResult({ ok: true, text: `Connected. The model answered: ${out}` });
    } catch (e) {
      setResult({ ok: false, text: friendlyError(e) });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Modal side title="Settings" icon={<Settings size={18} className="text-cyan-300" />} onClose={onClose}>
      <div className="space-y-5">
        <section className="space-y-2">
          <div className="text-xs text-slate-400">Screen</div>
          <button className="btn w-full" onClick={onFullscreen}><Maximize size={16} /> Fullscreen and lock landscape</button>
          <p className="text-xs text-slate-500">For the best result, install the app: Chrome menu, then "Add to Home screen". It opens fullscreen in landscape.</p>
        </section>

        <section className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="flex-1">
              <div className="font-medium">AI features (optional)</div>
              <p className="text-xs text-slate-400">Off by default. The editor works fully without AI.</p>
            </div>
            <Switch checked={settings.aiEnabled} onChange={(v) => update({ aiEnabled: v })} />
          </div>

          {settings.aiEnabled && (
            <div className="space-y-3 rounded-2xl bg-white/5 p-3">
              <label className="block text-xs text-slate-400">
                OpenRouter API key
                <div className="flex gap-2 mt-1">
                  <input
                    className="input"
                    type={show ? 'text' : 'password'}
                    placeholder="sk-or-..."
                    value={settings.apiKey}
                    onChange={(e) => update({ apiKey: e.target.value })}
                    autoComplete="off"
                    spellCheck={false}
                  />
                  <button className="btn-icon shrink-0" onClick={() => setShow((s) => !s)} aria-label="Show or hide key">
                    {show ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={settings.remember} onChange={(e) => update({ remember: e.target.checked })} />
                Remember the key on this device
              </label>

              <label className="block text-xs text-slate-400">
                Model
                <select
                  className="input mt-1"
                  value={custom ? '__custom' : settings.model}
                  onChange={(e) => {
                    if (e.target.value === '__custom') setCustom(true);
                    else {
                      setCustom(false);
                      update({ model: e.target.value });
                    }
                  }}
                >
                  {FREE_MODELS.map((m) => (
                    <option key={m.id} value={m.id}>{m.label}</option>
                  ))}
                  <option value="__custom">Other model id...</option>
                </select>
              </label>
              {custom && (
                <input
                  className="input"
                  placeholder="vendor/model-name:free"
                  value={settings.model}
                  onChange={(e) => update({ model: e.target.value.trim() })}
                  spellCheck={false}
                />
              )}

              <div className="flex gap-2">
                <button className="btn flex-1" onClick={test} disabled={!settings.apiKey.trim() || testing}>
                  {testing ? <Loader2 size={16} className="animate-spin" /> : null} Test connection
                </button>
                <button className="btn" onClick={() => { update({ apiKey: '' }); setResult(null); }} disabled={!settings.apiKey}>
                  Remove key
                </button>
              </div>
              {result && <p className={`text-xs ${result.ok ? 'text-emerald-300' : 'text-rose-300'}`}>{result.text}</p>}

              <p className="text-xs text-slate-500">
                Get a free key: openrouter.ai, sign in, open Keys, tap Create Key. The key stays in this browser and requests go straight from your device to OpenRouter. Free models can be slow or busy at times.
              </p>
              {!settings.apiKey.trim() && <p className="text-xs text-amber-300">The AI button appears in the top bar after you save a key.</p>}
            </div>
          )}
        </section>
      </div>
    </Modal>
  );
}
