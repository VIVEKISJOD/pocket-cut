import React, { useEffect, useRef, useState } from 'react';
import { Download, Loader2 } from 'lucide-react';
import Modal from './Modal';
import { calcBitrate, exportFast, exportStudio, pickMime, studioSupported } from '../utils/exportEngine';
import { mediaPool } from '../utils/mediaPool';
import { dims, formatTime, projectDuration } from '../utils/project';

const Opt = ({ label, value, onChange, children, disabled }) => (
  <label className="block text-xs text-slate-400">
    {label}
    <select className="input mt-1" value={value} onChange={(e) => onChange(e.target.value)} disabled={disabled}>{children}</select>
  </label>
);

export default function ExportModal({ project, settings, updateSettings, onClose, onBusy }) {
  const canStudio = studioSupported();
  const [res, setRes] = useState(settings.exportRes);
  const [fps, setFps] = useState(settings.exportFps);
  const [quality, setQuality] = useState(settings.exportQuality);
  const [engine, setEngine] = useState(canStudio ? settings.exportEngine : 'fast');
  const [state, setState] = useState('idle'); // idle | running | done | error
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const abortRef = useRef(null);
  const wakeRef = useRef(null);
  const total = projectDuration(project);
  const { w, h } = dims(project.aspect, res);
  const mime = pickMime();
  const sizeMb = (calcBitrate(w, h, fps, quality) * total) / 8 / 1048576;
  const running = state === 'running';

  useEffect(() => () => {
    if (abortRef.current) abortRef.current.abort();
  }, []);

  const start = async () => {
    setState('running');
    setProgress(0);
    setPhase('');
    setError('');
    setResult(null);
    updateSettings({ exportRes: res, exportFps: fps, exportQuality: quality, exportEngine: engine });
    onBusy(true);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      try {
        if (navigator.wakeLock) wakeRef.current = await navigator.wakeLock.request('screen');
      } catch { /* optional */ }
      const fn = engine === 'studio' ? exportStudio : exportFast;
      const out = await fn({
        project, pool: mediaPool, opts: { res, fps, quality }, signal: ctrl.signal, onProgress: setProgress, onPhase: setPhase,
      });
      if (!out) {
        setState('idle');
      } else {
        const url = URL.createObjectURL(out.blob);
        setResult({ url, ext: out.ext, size: out.blob.size, name: `pocket-cut-${Date.now()}.${out.ext}` });
        setState('done');
      }
    } catch (e) {
      setError(e.message || String(e));
      setState('error');
    } finally {
      onBusy(false);
      try {
        if (wakeRef.current) await wakeRef.current.release();
      } catch { /* ignore */ }
    }
  };

  return (
    <Modal title="Export video" icon={<Download size={18} className="text-accent" />} onClose={onClose}>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-2">
          <Opt label="Resolution" value={res} onChange={(v) => setRes(Number(v))} disabled={running}>
            <option value={540}>540p</option>
            <option value={720}>720p HD</option>
            <option value={1080}>1080p Full HD</option>
            <option value={1440}>1440p 2K</option>
          </Opt>
          <Opt label="Frame rate" value={fps} onChange={(v) => setFps(Number(v))} disabled={running}>
            <option value={24}>24 fps</option>
            <option value={30}>30 fps</option>
            <option value={60}>60 fps (smooth)</option>
          </Opt>
          <Opt label="Quality" value={quality} onChange={setQuality} disabled={running}>
            <option value="standard">Standard</option>
            <option value="high">High</option>
            <option value="ultra">Ultra (biggest file)</option>
          </Opt>
          <Opt label="Engine" value={engine} onChange={setEngine} disabled={running}>
            <option value="studio" disabled={!canStudio}>Studio (exact frames)</option>
            <option value="fast">Fast (real time)</option>
          </Opt>
        </div>
        <div className="rounded-xl bg-white/5 p-3 text-xs text-slate-300 space-y-1">
          <div>{w} x {h} - {project.aspect} - {formatTime(total)}</div>
          <div>About {sizeMb < 1 ? '<1' : sizeMb.toFixed(0)} MB as {engine === 'studio' ? 'MP4' : mime ? mime.ext.toUpperCase() : 'video'}</div>
          <div className="text-slate-500">
            {engine === 'studio'
              ? 'Studio renders every frame exactly and never drops frames, so 60 fps stays smooth. It can take longer than the video itself.'
              : 'Fast records while the video plays, so it takes about as long as the video. A slow device may drop frames at high settings.'}
          </div>
          {!canStudio && <div className="text-amber-300">Studio export needs a newer Chrome, so Fast is used here.</div>}
        </div>
        <p className="text-xs text-slate-400">Keep this screen open and Chrome in front until it finishes.</p>

        {running && (
          <div className="rounded-xl bg-white/5 p-3 text-sm">
            <div className="flex items-center gap-2">
              <Loader2 size={16} className="animate-spin" />
              <span className="flex-1 truncate">{phase || 'Working...'}</span>
              <span className="tabular-nums">{Math.round(progress * 100)}%</span>
            </div>
            <div className="mt-2 h-1.5 rounded bg-white/10 overflow-hidden">
              <div className="h-full bg-accent" style={{ width: `${progress * 100}%` }} />
            </div>
          </div>
        )}
        {state === 'error' && (
          <div className="space-y-2">
            <p className="text-sm text-rose-300">{error}</p>
            {engine === 'studio' && <button className="btn" onClick={() => setEngine('fast')}>Switch to Fast export</button>}
          </div>
        )}
        {state === 'done' && result && (
          <div className="space-y-2">
            <video src={result.url} controls playsInline className="w-full max-h-48 rounded-xl bg-black" />
            <a className="btn-primary w-full" href={result.url} download={result.name}>
              <Download size={16} /> Download {result.ext.toUpperCase()} ({(result.size / 1048576).toFixed(1)} MB)
            </a>
          </div>
        )}

        <div className="flex gap-2">
          {running ? (
            <button className="btn flex-1" onClick={() => abortRef.current && abortRef.current.abort()}>Cancel export</button>
          ) : (
            <button className="btn-primary flex-1" onClick={start} disabled={total <= 0}>{state === 'done' ? 'Export again' : 'Start export'}</button>
          )}
          <button className="btn" onClick={onClose}>Close</button>
        </div>
      </div>
    </Modal>
  );
}
