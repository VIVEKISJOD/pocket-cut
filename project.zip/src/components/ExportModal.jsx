import React, { useEffect, useRef, useState } from 'react';
import { Download, Loader2 } from 'lucide-react';
import Modal from './Modal';
import { exportProject, pickMime } from '../utils/exportEngine';
import { mediaPool } from '../utils/mediaPool';
import { ASPECTS, formatTime, projectDuration } from '../utils/project';

export default function ExportModal({ project, onClose, onBusy }) {
  const [fps, setFps] = useState(30);
  const [state, setState] = useState('idle'); // idle | running | done | error
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const abortRef = useRef(null);
  const wakeRef = useRef(null);
  const { w, h } = ASPECTS[project.aspect];
  const total = projectDuration(project);
  const mime = pickMime();

  useEffect(() => () => {
    if (abortRef.current) abortRef.current.abort();
  }, []);

  const start = async () => {
    setState('running');
    setProgress(0);
    setError('');
    setResult(null);
    onBusy(true);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      try {
        if (navigator.wakeLock) wakeRef.current = await navigator.wakeLock.request('screen');
      } catch { /* optional */ }
      const out = await exportProject({ project, pool: mediaPool, fps, signal: ctrl.signal, onProgress: setProgress });
      if (!out) {
        setState('idle');
      } else {
        const url = URL.createObjectURL(out.blob);
        setResult({ url, ext: out.ext, size: out.blob.size, name: `pocket-cut-${Date.now()}.${out.ext}` });
        setState('done');
      }
    } catch (e) {
      setError(e.message || String(e));
      setState('error');
    } finally {
      onBusy(false);
      try {
        if (wakeRef.current) await wakeRef.current.release();
      } catch { /* ignore */ }
    }
  };

  const cancel = () => {
    if (abortRef.current) abortRef.current.abort();
  };

  return (
    <Modal title="Export video" icon={<Download size={18} className="text-cyan-300" />} onClose={onClose}>
      <div className="space-y-4">
        <div className="rounded-xl bg-white/5 p-3 text-sm space-y-1">
          <div>Size: {w} x {h} ({project.aspect})</div>
          <div>Length: {formatTime(total)}</div>
          <div>Format: {mime ? mime.ext.toUpperCase() : 'not supported in this browser'}</div>
        </div>
        <label className="block text-xs text-slate-400">
          Frame rate
          <select className="input mt-1" value={fps} onChange={(e) => setFps(Number(e.target.value))} disabled={state === 'running'}>
            <option value={24}>24 fps</option>
            <option value={30}>30 fps</option>
          </select>
        </label>
        <p className="text-xs text-slate-400">
          Export runs in real time: a 1 minute video takes about 1 minute. Keep this screen open and Chrome in front until it finishes.
        </p>

        {state === 'running' && (
          <div className="rounded-xl bg-white/5 p-3 text-sm">
            <div className="flex items-center gap-2">
              <Loader2 size={16} className="animate-spin" />
              <span className="flex-1">Recording your video...</span>
              <span className="tabular-nums">{Math.round(progress * 100)}%</span>
            </div>
            <div className="mt-2 h-1.5 rounded bg-white/10 overflow-hidden">
              <div className="h-full bg-cyan-400" style={{ width: `${progress * 100}%` }} />
            </div>
          </div>
        )}
        {state === 'error' && <p className="text-sm text-rose-300">{error}</p>}
        {state === 'done' && result && (
          <div className="space-y-2">
            <video src={result.url} controls playsInline className="w-full max-h-48 rounded-xl bg-black" />
            <a className="btn-primary w-full" href={result.url} download={result.name}>
              <Download size={16} /> Download {result.ext.toUpperCase()} ({(result.size / 1048576).toFixed(1)} MB)
            </a>
          </div>
        )}

        <div className="flex gap-2">
          {state === 'running' ? (
            <button className="btn flex-1" onClick={cancel}>Cancel export</button>
          ) : (
            <button className="btn-primary flex-1" onClick={start} disabled={total <= 0 || !mime}>
              {state === 'done' ? 'Export again' : 'Start export'}
            </button>
          )}
          <button className="btn" onClick={onClose}>Close</button>
        </div>
      </div>
    </Modal>
  );
}
