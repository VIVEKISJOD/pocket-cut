import React, { useEffect, useState } from 'react';
import { Eye, EyeOff, Loader2, Maximize, Settings } from 'lucide-react';
import Modal from './Modal';
import { FREE_MODELS, friendlyError, testConnection } from '../services/openrouter';
import { LANGS, WHISPER_MODELS } from '../utils/captioner';
import { THEMES } from '../utils/project';
import { storageEstimate } from '../utils/db';

function Section({ title, children }) {
  return (
    <section className="space-y-1.5">
      <div className="text-[11px] uppercase tracking-wide text-slate-400 px-1">{title}</div>
      <div className="rounded-2xl bg-white/5 divide-y divide-white/5">{children}</div>
    </section>
  );
}

function Row({ title, hint, children, stack }) {
  return (
    <div className={`px-3 py-2.5 ${stack ? 'space-y-2' : 'flex items-center gap-3'}`}>
      <div className="flex-1 min-w-0">
        <div className="text-sm">{title}</div>
        {hint && <div className="text-[11px] text-slate-500">{hint}</div>}
      </div>
      {children}
    </div>
  );
}

function Switch({ checked, onChange, disabled }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative w-12 h-7 rounded-full transition shrink-0 disabled:opacity-40 ${checked ? 'bg-accent' : 'bg-white/20'}`}
    >
      <span className={`absolute top-0.5 w-6 h-6 rounded-full bg-white transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`} />
    </button>
  );
}

function Pick({ value, onChange, options }) {
  return (
    <select className="input w-auto max-w-[11rem]" value={value} onChange={(e) => onChange(e.target.value)}>
      {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
    </select>
  );
}

export default function SettingsPanel({ settings, update, reset, onClose, onFullscreen, onClearAll }) {
  const [show, setShow] = useState(false);
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState(null);
  const [usage, setUsage] = useState(null);
  const [custom, setCustom] = useState(!FREE_MODELS.some((m) => m.id === settings.model));
  const s = settings;

  useEffect(() => {
    storageEstimate().then(setUsage);
  }, []);

  const test = async () => {
    setTesting(true);
    setResult(null);
    try {
      const out = await testConnection({ apiKey: s.apiKey.trim(), model: s.model, fallbackModels: FREE_MODELS.map((m) => m.id) });
      setResult({ ok: true, text: `Connected. The model answered: ${out}` });
    } catch (e) {
      setResult({ ok: false, text: friendlyError(e) });
    } finally {
      setTesting(false);
    }
  };
  const mb = (n) => `${(n / 1048576).toFixed(0)} MB`;

  return (
    <Modal side title="Settings" icon={<Settings size={18} className="text-accent" />} onClose={onClose}>
      <div className="space-y-5">
        <Section title="Appearance">
          <Row title="Colour palette" stack>
            <div className="grid grid-cols-4 gap-2">
              {THEMES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => update({ theme: t.id })}
                  className={`rounded-xl p-1.5 text-[10px] ${s.theme === t.id ? 'on' : 'bg-white/5'}`}
                >
                  <div className="h-7 rounded-lg mb-1" style={{ background: `linear-gradient(135deg, rgb(${t.acc2}), rgb(${t.acc}))` }} />
                  {t.name}
                </button>
              ))}
            </div>
          </Row>
          <Row title="Panel see-through" hint="How transparent the glass panels are" stack>
            <input type="range" min={0.3} max={0.95} step={0.05} value={s.glass} onChange={(e) => update({ glass: Number(e.target.value) })} />
          </Row>
          <Row title="Glass blur" hint="Turn off if the app feels slow">
            <Switch checked={s.blurOn} onChange={(v) => update({ blurOn: v })} />
          </Row>
        </Section>

        <Section title="Editing">
          <Row title="Hold to move clips" hint="Stops accidental dragging. Hold a clip, then slide it.">
            <Switch checked={s.holdToDrag} onChange={(v) => update({ holdToDrag: v })} />
          </Row>
          <Row title={`Hold time: ${(s.holdMs / 1000).toFixed(1)} s`} stack>
            <input type="range" min={300} max={3000} step={100} value={s.holdMs} disabled={!s.holdToDrag} onChange={(e) => update({ holdMs: Number(e.target.value) })} />
          </Row>
          <Row title="Vibrate when ready" hint="A small buzz when the hold finishes">
            <Switch checked={s.haptics} onChange={(v) => update({ haptics: v })} />
          </Row>
          <Row title="Snap to edges" hint="Clips click onto the playhead and other clips">
            <Switch checked={s.snap} onChange={(v) => update({ snap: v })} />
          </Row>
          <Row title="Close gaps after trim/delete" hint="Ripple edit. Later clips and captions slide to fill the gap.">
            <Switch checked={s.ripple} onChange={(v) => update({ ripple: v })} />
          </Row>
          <Row title="Ask before deleting">
            <Switch checked={s.confirmDelete} onChange={(v) => update({ confirmDelete: v })} />
          </Row>
          <Row title="Thumbnails on timeline">
            <Switch checked={s.showThumbs} onChange={(v) => update({ showThumbs: v })} />
          </Row>
          <Row title="Auto-save projects">
            <Switch checked={s.autoSave} onChange={(v) => update({ autoSave: v })} />
          </Row>
          <Row title="Loop playback">
            <Switch checked={s.loopPlayback} onChange={(v) => update({ loopPlayback: v })} />
          </Row>
        </Section>

        <Section title="Preview">
          <Row title="Preview quality" hint="Lower is smoother on slow devices. Export is always full quality.">
            <Pick value={String(s.previewScale)} onChange={(v) => update({ previewScale: Number(v) })} options={[['0.5', 'Low'], ['0.75', 'Medium'], ['1', 'High']]} />
          </Row>
          <Row title="Preview frame rate">
            <Pick value={String(s.previewFps)} onChange={(v) => update({ previewFps: Number(v) })} options={[['30', '30 fps (saves battery)'], ['60', '60 fps']]} />
          </Row>
          <Row title="Show grid lines">
            <Switch checked={s.showGrid} onChange={(v) => update({ showGrid: v })} />
          </Row>
          <Row title="Fullscreen and landscape">
            <button className="btn" onClick={onFullscreen}><Maximize size={16} /> Go</button>
          </Row>
        </Section>

        <Section title="Captions">
          <Row title="Default language">
            <Pick value={s.captionLang} onChange={(v) => update({ captionLang: v })} options={LANGS} />
          </Row>
          <Row title="Default accuracy">
            <Pick value={s.captionModel} onChange={(v) => update({ captionModel: v })} options={WHISPER_MODELS.map((m) => [m.id, m.name])} />
          </Row>
          <Row title={`Words per caption: ${s.captionWords}`} stack>
            <input type="range" min={2} max={10} value={s.captionWords} onChange={(e) => update({ captionWords: Number(e.target.value) })} />
          </Row>
        </Section>

        <Section title="Export defaults">
          <Row title="Resolution">
            <Pick value={String(s.exportRes)} onChange={(v) => update({ exportRes: Number(v) })} options={[['540', '540p'], ['720', '720p HD'], ['1080', '1080p Full HD'], ['1440', '1440p 2K']]} />
          </Row>
          <Row title="Frame rate">
            <Pick value={String(s.exportFps)} onChange={(v) => update({ exportFps: Number(v) })} options={[['24', '24 fps'], ['30', '30 fps'], ['60', '60 fps']]} />
          </Row>
          <Row title="Quality">
            <Pick value={s.exportQuality} onChange={(v) => update({ exportQuality: v })} options={[['standard', 'Standard'], ['high', 'High'], ['ultra', 'Ultra']]} />
          </Row>
          <Row title="Engine" hint="Studio renders every frame exactly. Fast records in real time.">
            <Pick value={s.exportEngine} onChange={(v) => update({ exportEngine: v })} options={[['studio', 'Studio (exact)'], ['fast', 'Fast (real time)']]} />
          </Row>
        </Section>

        <Section title="AI and online (optional)">
          <Row title="AI features" hint="Off by default. Auto captions work without it.">
            <Switch checked={s.aiEnabled} onChange={(v) => update({ aiEnabled: v })} />
          </Row>
          {s.aiEnabled && (
            <div className="px-3 py-3 space-y-3">
              <label className="block text-xs text-slate-400">
                OpenRouter API key
                <div className="flex gap-2 mt-1">
                  <input className="input" type={show ? 'text' : 'password'} placeholder="sk-or-..." value={s.apiKey} onChange={(e) => update({ apiKey: e.target.value })} autoComplete="off" spellCheck={false} />
                  <button className="btn-icon" onClick={() => setShow((v) => !v)} aria-label="Show or hide key">{show ? <EyeOff size={16} /> : <Eye size={16} />}</button>
                </div>
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={s.remember} onChange={(e) => update({ remember: e.target.checked })} />
                Remember the key on this device
              </label>
              <label className="block text-xs text-slate-400">
                Model
                <select
                  className="input mt-1"
                  value={custom ? '__custom' : s.model}
                  onChange={(e) => {
                    if (e.target.value === '__custom') setCustom(true);
                    else { setCustom(false); update({ model: e.target.value }); }
                  }}
                >
                  {FREE_MODELS.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
                  <option value="__custom">Other model id...</option>
                </select>
              </label>
              {custom && <input className="input" placeholder="vendor/model-name:free" value={s.model} onChange={(e) => update({ model: e.target.value.trim() })} spellCheck={false} />}
              <div className="flex gap-2">
                <button className="btn flex-1" onClick={test} disabled={!s.apiKey.trim() || testing}>
                  {testing ? <Loader2 size={16} className="animate-spin" /> : null} Test connection
                </button>
                <button className="btn" onClick={() => { update({ apiKey: '' }); setResult(null); }} disabled={!s.apiKey}>Remove key</button>
              </div>
              {result && <p className={`text-xs ${result.ok ? 'text-emerald-300' : 'text-rose-300'}`}>{result.text}</p>}
              <p className="text-xs text-slate-500">
                Get a free key at openrouter.ai: sign in, open Keys, tap Create Key. The key stays in this browser, and requests go straight from your device to OpenRouter.
              </p>
            </div>
          )}
          <Row title="GIPHY key (optional)" hint="Only needed for GIF search in the meme window. Free at developers.giphy.com" stack>
            <input className="input" placeholder="GIPHY API key" value={s.giphyKey} onChange={(e) => update({ giphyKey: e.target.value.trim() })} autoComplete="off" spellCheck={false} />
          </Row>
        </Section>

        <Section title="Storage and about">
          <Row title="Space used by this app" hint={usage && usage.quota ? `${mb(usage.usage || 0)} of ${mb(usage.quota)} available` : 'Not available in this browser'}>
            <span />
          </Row>
          <Row title="Delete all projects" hint="Removes every saved project and its media from this device">
            <button className="btn text-rose-300" onClick={onClearAll}>Delete</button>
          </Row>
          <Row title="Reset settings" hint="Keeps your AI key">
            <button className="btn" onClick={reset}>Reset</button>
          </Row>
          <Row title="Pocket Cut 2.0" hint="No watermark. No account. Everything stays on your device.">
            <span />
          </Row>
        </Section>
      </div>
    </Modal>
  );
}
