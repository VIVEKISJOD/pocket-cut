import React from 'react';
import { Film, Pencil, Plus, Settings, Trash2 } from 'lucide-react';
import { formatTime, timeAgo } from '../utils/project';

export default function Home({ projects, loading, onNew, onOpen, onRename, onDelete, onSettings }) {
  return (
    <div className="h-[100dvh] w-screen overflow-auto p-4">
      <div className="max-w-5xl mx-auto">
        <header className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-accent2 to-accent flex items-center justify-center">
            <Film size={20} className="text-slate-950" />
          </div>
          <div className="flex-1">
            <h1 className="text-xl font-bold leading-tight">Pocket Cut</h1>
            <p className="text-xs text-slate-400">Your projects stay on this device. No watermark, no account.</p>
          </div>
          <button className="btn-icon" onClick={onSettings} aria-label="Settings"><Settings size={18} /></button>
        </header>

        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))' }}>
          <button
            onClick={onNew}
            className="glass min-h-[150px] flex flex-col items-center justify-center gap-2 active:scale-95 transition border-dashed"
          >
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-accent2 to-accent flex items-center justify-center">
              <Plus size={26} className="text-white" />
            </div>
            <span className="font-semibold">New project</span>
          </button>

          {projects.map((p) => (
            <div key={p.id} className="glass overflow-hidden flex flex-col">
              <button onClick={() => onOpen(p.id)} className="relative aspect-video bg-black/40 flex items-center justify-center overflow-hidden">
                {p.thumb ? <img src={p.thumb} alt="" className="w-full h-full object-cover" /> : <Film size={28} className="text-slate-600" />}
                <span className="absolute top-1.5 left-1.5 text-[10px] px-1.5 py-0.5 rounded-full bg-black/60">{p.aspect}</span>
                <span className="absolute bottom-1.5 right-1.5 text-[10px] px-1.5 py-0.5 rounded-full bg-black/60 tabular-nums">{formatTime(p.duration || 0)}</span>
              </button>
              <div className="p-2.5 flex items-center gap-1">
                <button className="flex-1 min-w-0 text-left" onClick={() => onOpen(p.id)}>
                  <div className="font-medium text-sm truncate">{p.name}</div>
                  <div className="text-[11px] text-slate-400">Edited {timeAgo(p.updated)}</div>
                </button>
                <button className="btn-icon w-8 h-8" onClick={() => onOpen(p.id)} aria-label="Edit"><Film size={14} /></button>
                <button className="btn-icon w-8 h-8" onClick={() => onRename(p)} aria-label="Rename"><Pencil size={14} /></button>
                <button className="btn-icon w-8 h-8" onClick={() => onDelete(p)} aria-label="Delete"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>

        {!loading && projects.length === 0 && (
          <p className="text-center text-sm text-slate-400 mt-8">No projects yet. Tap New project to begin.</p>
        )}
      </div>
    </div>
  );
}
