import React, { useEffect, useRef } from 'react';
import { PREVIEW_SHORT, dims, projectDuration } from '../utils/project';
import { renderFrame, syncMedia } from '../utils/renderer';
import { clock } from '../utils/clock';

// Draws the preview. Only renders when something changes (or while playing),
// so an idle editor uses almost no battery.
function CanvasPlayer({ project, playing, suspended, pool, scale, fpsCap, grid, loop, onEnded, picking, onPick }) {
  const canvasRef = useRef(null);
  const live = useRef({});
  live.current = { project, playing, suspended, fpsCap, grid, loop, onEnded };
  const { w, h } = dims(project.aspect, Math.round(PREVIEW_SHORT * scale));

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { alpha: false });
    let raf = 0;
    let last = performance.now();
    let lastRender = 0;
    let renderUntil = 0;
    let lastProject = null;
    let lastVersion = -1;
    let lastW = 0;
    let lastGrid = null;
    let endedFired = false;

    const loopFn = (now) => {
      raf = requestAnimationFrame(loopFn);
      const dt = Math.min(0.25, (now - last) / 1000);
      last = now;
      const L = live.current;
      if (L.suspended) return;
      const p = L.project;
      const dur = projectDuration(p);
      let isPlaying = L.playing && dur > 0;
      if (isPlaying) {
        let t = clock.time + dt;
        if (t >= dur) {
          if (L.loop) {
            clock.set(0);
            t = 0;
          } else {
            t = dur;
            isPlaying = false;
            if (!endedFired) {
              endedFired = true;
              clock.advance(dur);
              pool.pauseAll();
              L.onEnded();
            }
          }
        } else {
          endedFired = false;
        }
        if (isPlaying) clock.advance(t);
      } else {
        endedFired = false;
      }
      clock.playing = isPlaying;

      if (p !== lastProject || clock.version !== lastVersion || canvas.width !== lastW || L.grid !== lastGrid) {
        renderUntil = now + 900;
        lastProject = p;
        lastVersion = clock.version;
        lastW = canvas.width;
        lastGrid = L.grid;
      }
      if (!isPlaying && now > renderUntil) return;
      if (isPlaying && L.fpsCap === 30 && now - lastRender < 28) return;
      lastRender = now;
      syncMedia(p, clock.time, isPlaying, pool);
      renderFrame(ctx, canvas.width, canvas.height, p, clock.time, pool, { placeholder: true, grid: L.grid });
    };
    raf = requestAnimationFrame(loopFn);
    return () => cancelAnimationFrame(raf);
  }, [pool]);

  const onDown = (e) => {
    if (!picking || !onPick) return;
    const c = canvasRef.current;
    const rect = c.getBoundingClientRect();
    const s = Math.min(rect.width / c.width, rect.height / c.height);
    const ox = (rect.width - c.width * s) / 2;
    const oy = (rect.height - c.height * s) / 2;
    const x = (e.clientX - rect.left - ox) / s;
    const y = (e.clientY - rect.top - oy) / s;
    if (x < 0 || y < 0 || x > c.width || y > c.height) return;
    onPick(x, y, c.width, c.height);
  };

  return (
    <canvas
      ref={canvasRef}
      width={w}
      height={h}
      onPointerDown={onDown}
      style={{ width: '100%', height: '100%', objectFit: 'contain', display: 'block', cursor: picking ? 'crosshair' : 'default' }}
    />
  );
}

export default React.memo(CanvasPlayer);
