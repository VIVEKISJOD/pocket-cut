import React, { useEffect, useRef } from 'react';
import { ASPECTS, projectDuration } from '../utils/project';
import { renderFrame, syncMedia } from '../utils/renderer';

// Draws the composite every animation frame and advances the playback clock.
function CanvasPlayer({ project, clockRef, playing, suspended, pool, onTime, onEnded }) {
  const canvasRef = useRef(null);
  const projectRef = useRef(project);
  const playingRef = useRef(playing);
  const suspendedRef = useRef(suspended);
  const cbRef = useRef({ onTime, onEnded });
  projectRef.current = project;
  playingRef.current = playing;
  suspendedRef.current = suspended;
  cbRef.current = { onTime, onEnded };
  const { w, h } = ASPECTS[project.aspect];

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { alpha: false });
    let raf = 0;
    let last = performance.now();
    let lastEmit = 0;
    let endedFired = false;

    const loop = (now) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.25, (now - last) / 1000);
      last = now;
      if (suspendedRef.current) return;
      const clock = clockRef.current;
      const p = projectRef.current;
      const dur = projectDuration(p);
      let isPlaying = playingRef.current;
      if (isPlaying) {
        clock.time += dt;
        if (clock.time >= dur) {
          clock.time = dur;
          isPlaying = false;
          if (!endedFired) {
            endedFired = true;
            pool.pauseAll();
            cbRef.current.onTime(clock.time);
            cbRef.current.onEnded();
          }
        } else {
          endedFired = false;
        }
      } else {
        endedFired = false;
      }
      syncMedia(p, clock.time, isPlaying, pool);
      renderFrame(ctx, canvas.width, canvas.height, p, clock.time, pool, { placeholder: true });
      if (isPlaying && now - lastEmit > 33) {
        lastEmit = now;
        cbRef.current.onTime(clock.time);
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [clockRef, pool]);

  return (
    <canvas
      ref={canvasRef}
      width={w}
      height={h}
      style={{ width: '100%', height: '100%', objectFit: 'contain', display: 'block' }}
    />
  );
}

export default React.memo(CanvasPlayer);
