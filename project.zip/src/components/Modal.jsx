import React from 'react';
import { X } from 'lucide-react';

export default function Modal({ title, icon, onClose, children, side = false, wide = false }) {
  return (
    <div
      className={`fixed inset-0 z-50 flex bg-black/50 backdrop-blur-sm ${side ? 'justify-end items-stretch' : 'justify-center items-center'}`}
      onPointerDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className={`glass flex flex-col ${
          side ? 'h-full w-[24rem] max-w-full rounded-r-none' : `max-h-[94dvh] ${wide ? 'w-[40rem]' : 'w-[28rem]'} max-w-[96vw]`
        }`}
      >
        <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10 shrink-0">
          {icon}
          <h2 className="font-semibold flex-1 truncate">{title}</h2>
          <button className="btn-icon" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </div>
        <div className="p-4 overflow-auto min-h-0">{children}</div>
      </div>
    </div>
  );
}
