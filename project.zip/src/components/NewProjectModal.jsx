import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import Modal from './Modal';
import { ASPECT_LIST, FILTER_PRESETS } from '../utils/project';
import { buildFilter } from '../utils/renderer';

export default function NewProjectModal({ defaultName, onCreate, onClose }) {
  const [name, setName] = useState(defaultName);
  const [aspect, setAspect] = useState('16:9');
  const [look, setLook] = useState('none');

  return (
    <Modal wide title="New project" icon={<Plus size={18} className="text-accent" />} onClose={onClose}>
      <div className="space-y-5">
        <label className="block text-xs text-slate-400">
          Project name
          <input className="input mt-1" value={name} onChange={(e) => setName(e.target.value)} maxLength={40} />
        </label>

        <div>
          <div className="text-xs text-slate-400 mb-2">1. Video shape (ratio)</div>
          <div className="grid grid-cols-5 gap-2">
            {ASPECT_LIST.map((a) => {
              const bw = a.r >= 1 ? 40 : 40 * a.r;
              const bh = a.r >= 1 ? 40 / a.r : 40;
              return (
                <button
                  key={a.id}
                  onClick={() => setAspect(a.id)}
                  className={`rounded-2xl p-2 flex flex-col items-center gap-1 text-center ${aspect === a.id ? 'on' : 'bg-white/5'}`}
                >
                  <div className="h-11 flex items-center">
                    <div className="rounded-md border-2 border-white/70" style={{ width: bw, height: bh }} />
                  </div>
                  <div className="text-xs font-semibold">{a.id}</div>
                  <div className="text-[10px] text-slate-400 leading-tight">{a.hint}</div>
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <div className="text-xs text-slate-400 mb-2">2. Starting effect (you can change it later)</div>
          <div className="grid grid-cols-4 gap-2">
            {FILTER_PRESETS.map((p) => (
              <button key={p.id} onClick={() => setLook(p.id)} className={`rounded-xl p-1 text-[11px] ${look === p.id ? 'on' : 'bg-white/5'}`}>
                <div
                  className="h-8 rounded-lg mb-1"
                  style={{ background: 'linear-gradient(135deg,#f97316,#22d3ee,#a855f7)', filter: buildFilter(p.values) }}
                />
                {p.name}
              </button>
            ))}
          </div>
        </div>

        <button className="btn-primary w-full h-11" onClick={() => onCreate({ name: name.trim() || defaultName, aspect, look })}>
          Start editing
        </button>
      </div>
    </Modal>
  );
}
