import React, { useEffect, useRef, useState } from 'react';
import { Loader2, Type } from 'lucide-react';
import Modal from './Modal';
import { extractAudio16k } from '../utils/audio';
import { clipDur, formatTime, uid } from '../utils/project';

const LANGS = [
  ['auto', 'Auto-detect'], ['english', 'English'], ['hindi', 'Hindi'], ['spanish', 'Spanish'], ['french', 'French'],
  ['german', 'German'], ['portuguese', 'Portuguese'], ['arabic', 'Arabic'], ['russian', 'Russian'],
  ['japanese', 'Japanese'], ['korean', 'Korean'], ['chinese', 'Chinese'], ['indonesian', 'Indonesian'],
  ['turkish', 'Turkish'], ['urdu', 'Urdu'], ['bengali', 'Bengali'],
];

function transcribe(worker, audio, language, onProgress) {
  return new Promise((resolve, reject) => {
    const id = uid();
    const handler = (e) => {
      const m = e.data;
      if (m.id !== id) return;
      if (m.type === 'progress') {
        onProgress(m.data);
      } else if (m.type === 'result') {
        worker.removeEventListener('message', handler);
        resolve(m.blocks);
      } else if (m.type === 'error') {
        worker.removeEventListener('message', handler);
        reject(new Error(m.message));
      }
    };
    worker.addEventListener('message', handler);
    worker.postMessage({ type: 'transcribe', id, audio, language }, [audio.buffer]);
  });
}

export default function AutoCaptions({ project, dispatch, onClose }) {
  const eligible = project.clips.filter((c) => c.kind !== 'image' && (c.track === 'video' || c.track === 'audio'));
  const [chosen, setChosen] = useState(() => new Set(eligible.map((c) => c.id)));
  const [language, setLanguage] = useState('auto');
  const [replace, setReplace] = useState(true);
  const [status, setStatus] = useState('idle'); // idle | working | done | error
  const [phase, setPhase] = useState('');
  const [pct, setPct] = useState(null);
  const [error, setError] = useState('');
  const [count, setCount] = useState(0);
  const workerRef = useRef(null);
  const cancelled = useRef(false);

  useEffect(() => () => {
    cancelled.current = true;
    if (workerRef.current) workerRef.current.terminate();
  }, []);

  const getWorker = () => {
    if (!workerRef.current) {
      workerRef.current = new Worker(new URL('../utils/whisperWorker.js', import.meta.url), { type: 'module' });
    }
    return workerRef.current;
  };

  const onProgress = (d) => {
    if (!d) return;
    if (d.status === 'progress') {
      setPct(Math.round(d.progress || 0));
      setPhase(`Downloading speech model (first time only): ${String(d.file || '').split('/').pop()}`);
    } else if (d.status === 'ready') {
      setPct(null);
      setPhase('Speech model ready');
    } else if (d.status === 'transcribing') {
      setPct(null);
      setPhase('Listening and writing captions...');
    }
  };

  const run = async () => {
    cancelled.current = false;
    setStatus('working');
    setError('');
    setPct(null);
    try {
      const targets = eligible.filter((c) => chosen.has(c.id)).sort((a, b) => a.start - b.start);
      if (!targets.length) throw new Error('Choose at least one clip that has sound.');
      const worker = getWorker();
      const all = [];
      for (let i = 0; i < targets.length; i++) {
        const c = targets[i];
        setPhase(`Reading audio ${i + 1} of ${targets.length}...`);
        const audio = await extractAudio16k(c.url, c.inPoint, c.outPoint);
        if (cancelled.current) return;
        if (audio.length < 16000 * 0.3) continue;
        setPhase(`Transcribing ${i + 1} of ${targets.length}...`);
        const blocks = await transcribe(worker, audio, language, onProgress);
        const limit = c.start + clipDur(c);
        blocks.forEach((b) => {
          const s = c.start + b.start;
          const e = Math.min(c.start + b.end, limit);
          if (e > s + 0.1) all.push({ id: uid(), start: s, end: e, text: b.text });
        });
      }
      if (cancelled.current) return;
      if (!all.length) throw new Error('No speech was found in the chosen clips.');
      dispatch(replace ? { type: 'SET_SUBS', subs: all } : { type: 'ADD_SUBS', subs: all });
      setCount(all.length);
      setStatus('done');
    } catch (e) {
      if (cancelled.current) return;
      setError(e.message || String(e));
      setStatus('error');
    }
  };

  const cancel = () => {
    cancelled.current = true;
    if (workerRef.current) {
      workerRef.current.terminate();
      workerRef.current = null;
    }
    setStatus('idle');
    setPhase('');
    setPct(null);
  };

  const toggle = (id) =>
    setChosen((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  return (
    <Modal title="Auto captions" icon={<Type size={18} className="text-cyan-300" />} onClose={onClose}>
      {eligible.length === 0 ? (
        <p className="text-sm text-slate-300">Add a video or audio clip first, then come back to make captions.</p>
      ) : (
        <div className="space-y-4">
          <p className="text-xs text-slate-400">
            Runs on your device with Whisper (tiny). The speech model (about 40 MB) downloads once, then works offline. Try a short clip first: phones transcribe slower than real time.
          </p>
          <div className="space-y-1">
            <div className="text-xs text-slate-400">Clips to transcribe</div>
            {eligible.map((c) => (
              <label key={c.id} className="flex items-center gap-2 rounded-xl bg-white/5 px-3 py-2 text-sm">
                <input type="checkbox" checked={chosen.has(c.id)} onChange={() => toggle(c.id)} disabled={status === 'working'} />
                <span className="flex-1 truncate">{c.name}</span>
                <span className="text-xs text-slate-400 tabular-nums">{formatTime(clipDur(c))}</span>
              </label>
            ))}
          </div>
          <label className="block text-xs text-slate-400">
            Spoken language
            <select className="input mt-1" value={language} onChange={(e) => setLanguage(e.target.value)} disabled={status === 'working'}>
              {LANGS.map(([v, l]) => (
                <option key={v} value={v}>{l}</option>
              ))}
            </select>
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={replace} onChange={(e) => setReplace(e.target.checked)} disabled={status === 'working'} />
            Replace existing captions
          </label>

          {status === 'working' && (
            <div className="rounded-xl bg-white/5 p-3 text-sm">
              <div className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                <span className="flex-1">{phase || 'Starting...'}</span>
                {pct !== null && <span className="tabular-nums">{pct}%</span>}
              </div>
              {pct !== null && (
                <div className="mt-2 h-1.5 rounded bg-white/10 overflow-hidden">
                  <div className="h-full bg-cyan-400" style={{ width: `${pct}%` }} />
                </div>
              )}
            </div>
          )}
          {status === 'error' && <p className="text-sm text-rose-300">{error}</p>}
          {status === 'done' && <p className="text-sm text-emerald-300">Done: {count} captions added. Edit them in the Text tab.</p>}

          <div className="flex gap-2">
            {status === 'working' ? (
              <button className="btn flex-1" onClick={cancel}>Cancel</button>
            ) : (
              <button className="btn-primary flex-1" onClick={run}>{status === 'done' ? 'Run again' : 'Make captions'}</button>
            )}
            <button className="btn" onClick={onClose}>Close</button>
          </div>
        </div>
      )}
    </Modal>
  );
}
