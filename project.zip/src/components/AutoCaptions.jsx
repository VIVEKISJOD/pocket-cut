import React, { useEffect, useRef, useState } from 'react';
import { Loader2, Type } from 'lucide-react';
import Modal from './Modal';
import { LANGS, WHISPER_MODELS, generateCaptions, stopWorker } from '../utils/captioner';
import { clipDur, formatTime } from '../utils/project';

export default function AutoCaptions({ project, settings, dispatch, onClose }) {
  const eligible = project.clips.filter((c) => c.kind !== 'image' && c.url);
  const [chosen, setChosen] = useState(() => new Set(eligible.filter((c) => c.track !== 'overlay').map((c) => c.id)));
  const [language, setLanguage] = useState(settings.captionLang);
  const [model, setModel] = useState(settings.captionModel);
  const [mode, setMode] = useState('speech');
  const [maxWords, setMaxWords] = useState(settings.captionWords);
  const [replace, setReplace] = useState(true);
  const [status, setStatus] = useState('idle');
  const [phase, setPhase] = useState('');
  const [pct, setPct] = useState(null);
  const [error, setError] = useState('');
  const [count, setCount] = useState(0);
  const cancelled = useRef(false);

  useEffect(() => () => {
    cancelled.current = true;
    stopWorker();
  }, []);

  const onProgress = (d) => {
    if (!d) return;
    if (d.status === 'progress') {
      setPct(Math.round(d.progress || 0));
      setPhase(`Downloading speech model (first time only): ${String(d.file || '').split('/').pop()}`);
    } else if (d.status === 'ready') {
      setPct(null);
      setPhase('Speech model ready');
    } else if (d.status === 'transcribing') {
      setPct(null);
      setPhase('Listening and writing captions...');
    }
  };

  const run = async () => {
    cancelled.current = false;
    setStatus('working');
    setError('');
    setPct(null);
    try {
      const subs = await generateCaptions({
        project, clipIds: [...chosen], language, model, mode, maxWords,
        onPhase: setPhase, onProgress, isCancelled: () => cancelled.current,
      });
      if (!subs) return;
      if (!subs.length) throw new Error('No speech was found in the chosen clips.');
      dispatch(replace ? { type: 'SET_SUBS', subs } : { type: 'ADD_SUBS', subs });
      setCount(subs.length);
      setStatus('done');
    } catch (e) {
      if (cancelled.current) return;
      setError(e.message || String(e));
      setStatus('error');
    }
  };

  const cancel = () => {
    cancelled.current = true;
    stopWorker();
    setStatus('idle');
    setPhase('');
    setPct(null);
  };
  const toggle = (id) =>
    setChosen((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  const working = status === 'working';

  return (
    <Modal title="Auto captions" icon={<Type size={18} className="text-accent" />} onClose={onClose}>
      {eligible.length === 0 ? (
        <p className="text-sm text-slate-300">Add a video or audio clip first, then come back to make captions.</p>
      ) : (
        <div className="space-y-4">
          <p className="text-xs text-slate-400">
            Runs on your device with Whisper. The speech model downloads once, then works offline. For Hindi or Hinglish choose Better or Best.
          </p>
          <div className="space-y-1">
            <div className="text-xs text-slate-400">Clips to transcribe</div>
            {eligible.map((c) => (
              <label key={c.id} className="flex items-center gap-2 rounded-xl bg-white/5 px-3 py-2 text-sm">
                <input type="checkbox" checked={chosen.has(c.id)} onChange={() => toggle(c.id)} disabled={working} />
                <span className="flex-1 truncate">{c.name}</span>
                <span className="text-xs text-slate-400 tabular-nums">{formatTime(clipDur(c))}</span>
              </label>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <label className="block text-xs text-slate-400 col-span-2">
              Language
              <select className="input mt-1" value={language} onChange={(e) => setLanguage(e.target.value)} disabled={working}>
                {LANGS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </label>
            <label className="block text-xs text-slate-400">
              Accuracy
              <select className="input mt-1" value={model} onChange={(e) => setModel(e.target.value)} disabled={working}>
                {WHISPER_MODELS.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
            </label>
            <label className="block text-xs text-slate-400">
              Sound type
              <select className="input mt-1" value={mode} onChange={(e) => setMode(e.target.value)} disabled={working}>
                <option value="speech">Person speaking</option>
                <option value="music">Song / background music lyrics</option>
              </select>
            </label>
          </div>
          <label className="block text-xs text-slate-400">
            Words per caption: {maxWords}
            <input type="range" min={2} max={10} value={maxWords} onChange={(e) => setMaxWords(Number(e.target.value))} disabled={working} />
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={replace} onChange={(e) => setReplace(e.target.checked)} disabled={working} />
            Replace existing captions
          </label>

          {working && (
            <div className="rounded-xl bg-white/5 p-3 text-sm">
              <div className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                <span className="flex-1">{phase || 'Starting...'}</span>
                {pct !== null && <span className="tabular-nums">{pct}%</span>}
              </div>
              {pct !== null && (
                <div className="mt-2 h-1.5 rounded bg-white/10 overflow-hidden">
                  <div className="h-full bg-accent" style={{ width: `${pct}%` }} />
                </div>
              )}
            </div>
          )}
          {status === 'error' && <p className="text-sm text-rose-300">{error}</p>}
          {status === 'done' && <p className="text-sm text-emerald-300">Done: {count} captions added. Style them in the Text tab.</p>}

          <div className="flex gap-2">
            {working ? (
              <button className="btn flex-1" onClick={cancel}>Cancel</button>
            ) : (
              <button className="btn-primary flex-1" onClick={run} disabled={!chosen.size}>{status === 'done' ? 'Run again' : 'Make captions'}</button>
            )}
            <button className="btn" onClick={onClose}>Close</button>
          </div>
        </div>
      )}
    </Modal>
  );
}
