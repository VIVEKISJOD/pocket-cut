const ENDPOINT = 'https://openrouter.ai/api/v1/chat/completions';

export const FREE_MODELS = [
  { id: 'google/gemini-2.5-flash:free', label: 'Gemini 2.5 Flash (free)' },
  { id: 'meta-llama/llama-3.3-70b-instruct:free', label: 'Llama 3.3 70B (free)' },
];

export class OpenRouterError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'OpenRouterError';
    this.status = status;
  }
}

async function callOnce({ apiKey, model, messages, temperature, signal }) {
  const res = await fetch(ENDPOINT, {
    method: 'POST',
    signal,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
      'HTTP-Referer': window.location.origin,
      'X-Title': 'Pocket Cut',
    },
    body: JSON.stringify({ model, messages, temperature, max_tokens: 1800 }),
  });
  let data = null;
  try { data = await res.json(); } catch { /* non-JSON error body */ }
  if (!res.ok) {
    const msg = (data && data.error && data.error.message) || `HTTP ${res.status}`;
    throw new OpenRouterError(msg, res.status);
  }
  const text = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  if (!text) throw new OpenRouterError('The model returned an empty answer.', 502);
  return text;
}

// Sends a chat request; if the chosen free model is busy or missing, tries the fallbacks.
export async function chat({ apiKey, model, fallbackModels = [], messages, temperature = 0.4, signal }) {
  if (!apiKey) throw new OpenRouterError('Add your OpenRouter API key in Settings first.', 401);
  const list = [model, ...fallbackModels.filter((m) => m !== model)];
  let lastErr = null;
  for (const m of list) {
    try {
      return await callOnce({ apiKey, model: m, messages, temperature, signal });
    } catch (err) {
      lastErr = err;
      if (err.name === 'AbortError' || err.status === 401 || err.status === 402) throw err;
    }
  }
  throw lastErr;
}

export function parseJsonLoose(text) {
  const s = String(text).trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  try { return JSON.parse(s); } catch { /* try to find a JSON block */ }
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a !== -1 && b > a) {
    try { return JSON.parse(s.slice(a, b + 1)); } catch { /* keep trying */ }
  }
  const c = s.indexOf('[');
  const d = s.lastIndexOf(']');
  if (c !== -1 && d > c) {
    try { return JSON.parse(s.slice(c, d + 1)); } catch { /* give up */ }
  }
  throw new OpenRouterError('The AI answer was not valid JSON. Please try again.', 422);
}

export function friendlyError(e) {
  if (e && e.status === 401) return 'OpenRouter rejected your API key. Check it in Settings.';
  if (e && e.status === 402) return 'This model needs credits. Pick a ":free" model in Settings.';
  if (e && e.status === 429) return 'The free models are busy right now. Wait a minute and try again.';
  return (e && e.message) || 'Something went wrong.';
}

export async function testConnection({ apiKey, model, fallbackModels }) {
  const out = await chat({
    apiKey, model, fallbackModels, temperature: 0,
    messages: [{ role: 'user', content: 'Reply with the single word: OK' }],
  });
  return out.trim().slice(0, 40);
}

export async function generateScript({ apiKey, model, fallbackModels, signal, topic, tone, seconds }) {
  const words = Math.round(seconds * 2.5);
  return chat({
    apiKey, model, fallbackModels, signal, temperature: 0.8,
    messages: [
      {
        role: 'system',
        content:
          'You are a short-form video scriptwriter. Output ONLY the spoken narration, one short sentence per line (max 12 words per line). ' +
          'No titles, no markdown, no stage directions, no numbering. Start with a strong hook and end with a call to action.',
      },
      { role: 'user', content: `Topic: ${topic}\nTone: ${tone}\nTarget length: about ${seconds} seconds (~${words} words).` },
    ],
  });
}

export async function suggestGrades({ apiKey, model, fallbackModels, signal, description }) {
  const text = await chat({
    apiKey, model, fallbackModels, signal, temperature: 0.5,
    messages: [
      {
        role: 'system',
        content:
          'You are a colorist. Suggest 3 color grades as JSON only, no markdown: ' +
          '{"grades":[{"name":"short name","why":"one short sentence","brightness":100,"contrast":100,"saturation":100,"hue":0,"vignette":0,"sepia":0,"grayscale":0}]}. ' +
          'Ranges: brightness 70-130, contrast 70-140, saturation 0-200, hue -45..45, vignette 0-80, sepia 0-60, grayscale 0-100. 100 is neutral for brightness/contrast/saturation.',
      },
      { role: 'user', content: `Video mood or description: ${description}` },
    ],
  });
  const json = parseJsonLoose(text);
  const list = Array.isArray(json) ? json : json.grades;
  if (!Array.isArray(list) || !list.length) throw new OpenRouterError('No grades came back. Try again.', 422);
  const lim = (v, a, b, d) => {
    const n = Number(v);
    return Number.isFinite(n) ? Math.min(b, Math.max(a, n)) : d;
  };
  return list.slice(0, 4).map((g) => ({
    name: String(g.name || 'Custom look').slice(0, 40),
    why: String(g.why || '').slice(0, 140),
    values: {
      brightness: lim(g.brightness, 50, 150, 100),
      contrast: lim(g.contrast, 50, 150, 100),
      saturation: lim(g.saturation, 0, 200, 100),
      hue: lim(g.hue, -180, 180, 0),
      vignette: lim(g.vignette, 0, 100, 0),
      sepia: lim(g.sepia, 0, 100, 0),
      grayscale: lim(g.grayscale, 0, 100, 0),
    },
  }));
}

export async function formatCaptions({ apiKey, model, fallbackModels, signal, subtitles, maxChars }) {
  const payload = subtitles.slice(0, 150).map((s, i) => ({ i, text: s.text }));
  const text = await chat({
    apiKey, model, fallbackModels, signal, temperature: 0.2,
    messages: [
      {
        role: 'system',
        content:
          `You format video captions. For each caption, fix capitalization and punctuation, and split it into short pieces of at most ${maxChars} characters, breaking at natural phrase boundaries. ` +
          'Never change the meaning or the order of words, never add or drop words. ' +
          'Reply with JSON only, no markdown: {"items":[{"i":0,"parts":["first piece","second piece"]}]}',
      },
      { role: 'user', content: JSON.stringify(payload) },
    ],
  });
  const json = parseJsonLoose(text);
  const items = Array.isArray(json) ? json : json.items;
  if (!Array.isArray(items)) throw new OpenRouterError('The AI answer had no caption list. Try again.', 422);
  return items.filter((it) => it && Number.isInteger(it.i) && Array.isArray(it.parts));
}

// Proofreads caption texts. Returns one corrected string per input (same order).
export async function polishCaptions({ apiKey, model, fallbackModels, signal, texts, roman }) {
  const out = [...texts];
  const BATCH = 50;
  for (let start = 0; start < texts.length; start += BATCH) {
    const slice = texts.slice(start, start + BATCH).map((t, k) => ({ i: start + k, text: t }));
    const reply = await chat({
      apiKey, model, fallbackModels, signal, temperature: 0.1,
      messages: [
        {
          role: 'system',
          content:
            'You proofread video captions. Fix spelling, punctuation and capitalization only. Keep the same language' +
            (roman ? ' and keep Hindi written in English letters (Hinglish), never Devanagari' : '') +
            '. Do not add, remove or reorder words: every item must keep exactly the same number of words. ' +
            'Reply with JSON only, no markdown: {"items":[{"i":0,"text":"..."}]}',
        },
        { role: 'user', content: JSON.stringify(slice) },
      ],
    });
    const json = parseJsonLoose(reply);
    const items = Array.isArray(json) ? json : json.items;
    if (Array.isArray(items)) {
      items.forEach((it) => {
        if (it && Number.isInteger(it.i) && typeof it.text === 'string' && it.text.trim()) out[it.i] = it.text.trim();
      });
    }
  }
  return out;
}
