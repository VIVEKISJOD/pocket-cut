// Free meme sources. None of them need an account except GIPHY (optional, your own free key).
export const REDDIT_SOURCES = [
  ['memes', 'Popular'],
  ['dankmemes', 'Dank'],
  ['IndianDankMemes', 'Indian'],
  ['wholesomememes', 'Wholesome'],
  ['me_irl', 'me_irl'],
  ['ProgrammerHumor', 'Tech'],
];

async function getJson(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`The meme service answered with an error (${r.status}).`);
  return r.json();
}

export async function redditMemes(sub, count = 40) {
  const j = await getJson(`https://meme-api.com/gimme/${encodeURIComponent(sub)}/${count}`);
  return (j.memes || [])
    .filter((m) => m.url && !m.nsfw && !m.spoiler && !/\.gif($|\?)/i.test(m.url))
    .map((m) => ({
      id: m.postLink || m.url,
      title: m.title || 'meme',
      url: m.url,
      thumb: (m.preview && m.preview[Math.min(2, m.preview.length - 1)]) || m.url,
      type: 'image',
    }));
}

export async function imgflipTemplates() {
  const j = await getJson('https://api.imgflip.com/get_memes');
  if (!j.success) throw new Error('Could not load meme templates.');
  return j.data.memes.map((m) => ({ id: m.id, title: m.name, url: m.url, thumb: m.url, type: 'image' }));
}

export async function giphySearch(key, q, kind = 'gifs') {
  const ep = q ? 'search' : 'trending';
  const url = `https://api.giphy.com/v1/${kind}/${ep}?api_key=${encodeURIComponent(key)}&limit=36&rating=pg-13${q ? `&q=${encodeURIComponent(q)}` : ''}`;
  const j = await getJson(url);
  return (j.data || [])
    .map((g) => {
      const im = g.images || {};
      const mp4 = (im.original && im.original.mp4) || (im.fixed_height && im.fixed_height.mp4);
      const thumb = (im.fixed_width_small && im.fixed_width_small.url) || (im.fixed_width && im.fixed_width.url);
      return mp4 ? { id: g.id, title: g.title || 'gif', url: mp4, thumb: thumb || mp4, type: 'video' } : null;
    })
    .filter(Boolean);
}

const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'meme';

// Downloads a meme into a File (so it can be added to the project or saved to the phone).
export async function downloadAsFile(item) {
  let r;
  try {
    r = await fetch(item.url);
  } catch {
    throw new Error('This site blocks downloads from the app. Try another meme.');
  }
  if (!r.ok) throw new Error(`Download failed (${r.status}).`);
  const blob = await r.blob();
  const sub = (blob.type.split('/')[1] || 'jpg').replace('jpeg', 'jpg').split('+')[0];
  return new File([blob], `${slug(item.title)}.${sub}`, { type: blob.type || 'image/jpeg' });
}

export function saveFileToDevice(file) {
  const url = URL.createObjectURL(file);
  const a = document.createElement('a');
  a.href = url;
  a.download = file.name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
