import { applyAction } from '../state/projectReducer';
import {
  ASPECT_IDS, FILTER_PRESETS, FONT_CHOICES, clamp, clipDur, clipEnd, projectDuration, uid,
} from '../utils/project';

export const EDITOR_SYSTEM_PROMPT = `You are the editing brain of "Pocket Cut", a mobile video editor. The user types a command; you reply with the edit steps to run.
Reply with ONE JSON object and nothing else (no markdown fences):
{"message":"one short friendly sentence","actions":[ ... ]}

All times are seconds on the timeline. Allowed actions:
{"action":"split","at":5}  - cut the clip(s) on a track under time 5 (default track "video"). Optional "clip":"<id>" or "track":"video|overlay|audio".
{"action":"trim_before","at":5}  - delete the part of the clip (default track "video") that is BEFORE time 5. Optional "clip" / "track".
{"action":"trim_after","at":5}  - delete the part of the clip that is AFTER time 5. Optional "clip" / "track".
{"action":"delete_clip","clip":"<id>"}  or  {"action":"delete_clip","track":"video","at":8}
{"action":"trim_clip","clip":"<id>","trim_start":1,"trim_end":2}  - remove seconds from the start and/or end of a clip
{"action":"move_clip","clip":"<id>","start":10}
{"action":"set_volume","clip":"<id>","volume":0.5}  - 0 to 2
{"action":"set_fit","clip":"<id>","fit":"cover|contain"}
{"action":"set_filter","preset":"none|cinematic|tealorange|warm|cool|vintage|noir|vivid|fade|dreamy|sunset|moody","brightness":100,"contrast":100,"saturation":100,"hue":0,"vignette":0,"sepia":0,"grayscale":0,"blur":0}  - every field optional. Ranges: brightness/contrast 50-150, saturation 0-200, hue -180..180, vignette/sepia/grayscale 0-100, blur 0-10
{"action":"set_aspect","ratio":"16:9|9:16|1:1|4:5|4:3"}
{"action":"add_subtitle","start":1,"end":3,"text":"Hello"}
{"action":"edit_subtitle","id":"<id>","text":"...","start":1,"end":2}
{"action":"delete_subtitle","id":"<id>"}
{"action":"clear_subtitles"}
{"action":"set_subtitle_style","font":"sans|serif|mono|impact|rounded|comic","size":3-10,"color":"#ffffff","highlight":"#facc15","bg":"#000000","bgOpacity":0-1,"pill":true,"highlightOn":true,"position":"top|middle|bottom","stroke":0-30,"strokeColor":"#000000","shadow":true,"uppercase":false,"anim":"none|pop|fade","offsetY":-30..30}
{"action":"seek","time":4}

Rules:
- Use only clip and subtitle ids that appear in PROJECT STATE. Steps run in order. To target a clip created by an earlier split in the same plan, use {"track":"video","at":<a time inside that clip>} instead of an id.
- For phrases like "second half" or "last 3 seconds", compute times from "duration" and each clip's "start"/"end".
- If the request is impossible or unclear, return an empty actions list and explain in "message".
- Never invent clips. Output only the JSON object.`;

const r2 = (n) => Math.round(n * 100) / 100;

export function buildSnapshot(project, time) {
  return {
    time: r2(time),
    duration: r2(projectDuration(project)),
    aspect: project.aspect,
    filter: project.filter,
    clips: project.clips.map((c) => ({
      id: c.id, name: c.name, track: c.track, kind: c.kind,
      start: r2(c.start), end: r2(clipEnd(c)), length: r2(clipDur(c)),
      trimIn: r2(c.inPoint), trimOut: r2(c.outPoint), sourceLength: r2(c.srcDuration),
      volume: c.volume == null ? 1 : c.volume, fit: c.fit || 'contain',
    })),
    subtitles: project.subtitles.slice(0, 80).map((s) => ({
      id: s.id, start: r2(s.start), end: r2(s.end), text: String(s.text).slice(0, 80),
    })),
    subtitleStyle: project.subStyle,
  };
}

const num = (v, d) => {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'string' && v.trim() !== '' && Number.isFinite(Number(v))) return Number(v);
  return d;
};

function findClip(work, a) {
  if (a.clip) {
    const c = work.clips.find((x) => x.id === a.clip);
    if (c) return c;
  }
  const t = num(a.at, null);
  if (t === null) return null;
  const track = a.track || 'video';
  return work.clips.find((c) => c.track === track && t >= c.start && t < clipEnd(c)) || null;
}

function findSub(work, a) {
  if (a.id) {
    const s = work.subtitles.find((x) => x.id === a.id);
    if (s) return s;
  }
  const idx = num(a.index, null);
  if (idx !== null && work.subtitles[idx]) return work.subtitles[idx];
  return null;
}

const HEX = /^#[0-9a-fA-F]{3,8}$/;

// Validates the AI's steps and turns them into reducer actions. Each step is
// applied to a working copy so later steps can see earlier ones.
export function planActions(raw, project, time) {
  let work = project;
  const ops = [];
  const applied = [];
  const skipped = [];
  let seekTo = null;
  const dur = projectDuration(project);
  const push = (op, note) => {
    ops.push(op);
    work = applyAction(work, op);
    applied.push(note);
  };

  (Array.isArray(raw) ? raw : []).slice(0, 40).forEach((a) => {
    if (!a || typeof a.action !== 'string') {
      skipped.push('One step was not understood');
      return;
    }
    switch (a.action) {
      case 'split': {
        const t = num(a.at, time);
        const list = a.clip
          ? [findClip(work, a)].filter(Boolean)
          : work.clips.filter((c) => c.track === (a.track || 'video') && t > c.start + 0.05 && t < clipEnd(c) - 0.05);
        const hits = list.filter((c) => t > c.start + 0.05 && t < clipEnd(c) - 0.05);
        if (!hits.length) { skipped.push(`Split at ${t.toFixed(1)}s: no clip there`); break; }
        hits.forEach((c) => push({ type: 'SPLIT', id: c.id, time: t, newId: uid() }, `Split "${c.name}" at ${t.toFixed(1)}s`));
        break;
      }
      case 'trim_before':
      case 'trim_after': {
        const t = num(a.at, time);
        const c = findClip(work, { ...a, at: t });
        if (!c || !(t > c.start + 0.05 && t < clipEnd(c) - 0.05)) { skipped.push(`Trim at ${t.toFixed(1)}s: no clip there`); break; }
        const left = a.action === 'trim_before';
        push({ type: left ? 'TRIM_LEFT' : 'TRIM_RIGHT', id: c.id, time: t, ripple: false }, `Removed the ${left ? 'part before' : 'part after'} ${t.toFixed(1)}s in "${c.name}"`);
        break;
      }
      case 'delete_clip': {
        const c = findClip(work, a);
        if (!c) { skipped.push('Delete: clip not found'); break; }
        push({ type: 'DELETE_CLIP', id: c.id }, `Deleted "${c.name}"`);
        break;
      }
      case 'trim_clip': {
        const c = findClip(work, a);
        if (!c) { skipped.push('Trim: clip not found'); break; }
        const len = clipDur(c);
        const head = clamp(num(a.trim_start, 0), 0, len - 0.2);
        const tail = clamp(num(a.trim_end, 0), 0, len - 0.2 - head);
        if (head === 0 && tail === 0) { skipped.push('Trim: nothing to remove'); break; }
        push({ type: 'UPDATE_CLIP', id: c.id, patch: { inPoint: c.inPoint + head, outPoint: c.outPoint - tail } }, `Trimmed "${c.name}"`);
        break;
      }
      case 'move_clip': {
        const c = findClip(work, a);
        const s = num(a.start, null);
        if (!c || s === null) { skipped.push('Move: clip or time missing'); break; }
        push({ type: 'UPDATE_CLIP', id: c.id, patch: { start: Math.max(0, s) } }, `Moved "${c.name}" to ${Math.max(0, s).toFixed(1)}s`);
        break;
      }
      case 'set_volume': {
        const c = findClip(work, a);
        const v = num(a.volume, null);
        if (!c || v === null) { skipped.push('Volume: clip or value missing'); break; }
        push({ type: 'UPDATE_CLIP', id: c.id, patch: { volume: clamp(v, 0, 2) } }, `Volume of "${c.name}" set to ${Math.round(clamp(v, 0, 2) * 100)}%`);
        break;
      }
      case 'set_fit': {
        const c = findClip(work, a);
        if (!c || (a.fit !== 'cover' && a.fit !== 'contain')) { skipped.push('Fit: clip or mode missing'); break; }
        push({ type: 'UPDATE_CLIP', id: c.id, patch: { fit: a.fit } }, `"${c.name}" now uses ${a.fit === 'cover' ? 'Fill' : 'Fit'}`);
        break;
      }
      case 'set_filter': {
        const patch = {};
        const preset = FILTER_PRESETS.find((p) => p.id === a.preset);
        if (preset) Object.assign(patch, preset.values, { preset: preset.id });
        const limits = {
          brightness: [50, 150], contrast: [50, 150], saturation: [0, 200], hue: [-180, 180],
          vignette: [0, 100], sepia: [0, 100], grayscale: [0, 100], blur: [0, 10],
        };
        let custom = false;
        Object.keys(limits).forEach((k) => {
          const v = num(a[k], null);
          if (v !== null) { patch[k] = clamp(v, limits[k][0], limits[k][1]); custom = true; }
        });
        if (custom) patch.preset = 'custom';
        if (!Object.keys(patch).length) { skipped.push('Color: nothing to change'); break; }
        push({ type: 'SET_FILTER', patch }, preset && !custom ? `Applied the ${preset.name} look` : 'Adjusted colors');
        break;
      }
      case 'set_aspect': {
        if (!ASPECT_IDS.includes(a.ratio)) { skipped.push('Aspect ratio not supported'); break; }
        push({ type: 'SET_ASPECT', aspect: a.ratio }, `Canvas set to ${a.ratio}`);
        break;
      }
      case 'add_subtitle': {
        const s = num(a.start, null);
        const e = num(a.end, null);
        const text = typeof a.text === 'string' ? a.text.trim() : '';
        if (s === null || e === null || e <= s || !text) { skipped.push('Caption: needs start, end and text'); break; }
        push({ type: 'ADD_SUB', sub: { id: uid(), start: Math.max(0, s), end: e, text } }, `Added caption "${text.slice(0, 30)}"`);
        break;
      }
      case 'edit_subtitle': {
        const sub = findSub(work, a);
        if (!sub) { skipped.push('Edit caption: not found'); break; }
        const patch = {};
        if (typeof a.text === 'string' && a.text.trim()) { patch.text = a.text.trim(); patch.words = null; }
        const s = num(a.start, null);
        const e = num(a.end, null);
        if (s !== null) patch.start = Math.max(0, s);
        if (e !== null) patch.end = e;
        if ((patch.end ?? sub.end) <= (patch.start ?? sub.start)) { skipped.push('Edit caption: end must be after start'); break; }
        if (!Object.keys(patch).length) { skipped.push('Edit caption: nothing to change'); break; }
        push({ type: 'UPDATE_SUB', id: sub.id, patch }, 'Edited a caption');
        break;
      }
      case 'delete_subtitle': {
        const sub = findSub(work, a);
        if (!sub) { skipped.push('Delete caption: not found'); break; }
        push({ type: 'DELETE_SUB', id: sub.id }, 'Deleted a caption');
        break;
      }
      case 'clear_subtitles':
        push({ type: 'SET_SUBS', subs: [] }, 'Removed all captions');
        break;
      case 'set_subtitle_style': {
        const patch = {};
        const font = FONT_CHOICES.find((f) => f.id === a.font);
        if (font) patch.font = font.css;
        const size = num(a.size, null);
        if (size !== null) patch.size = clamp(size, 2, 12);
        ['color', 'highlight', 'bg', 'strokeColor'].forEach((k) => {
          if (typeof a[k] === 'string' && HEX.test(a[k])) patch[k] = a[k];
        });
        const op = num(a.bgOpacity, null);
        if (op !== null) patch.bgOpacity = clamp(op, 0, 1);
        const st = num(a.stroke, null);
        if (st !== null) patch.stroke = clamp(st, 0, 30);
        const oy = num(a.offsetY, null);
        if (oy !== null) patch.offsetY = clamp(oy, -30, 30);
        ['pill', 'highlightOn', 'shadow', 'uppercase'].forEach((k) => {
          if (typeof a[k] === 'boolean') patch[k] = a[k];
        });
        if (['top', 'middle', 'bottom'].includes(a.position)) patch.position = a.position;
        if (['none', 'pop', 'fade'].includes(a.anim)) patch.anim = a.anim;
        if (!Object.keys(patch).length) { skipped.push('Caption style: nothing to change'); break; }
        push({ type: 'SET_SUBSTYLE', patch }, 'Updated caption style');
        break;
      }
      case 'seek': {
        const t = num(a.time, null);
        if (t === null) { skipped.push('Seek: time missing'); break; }
        seekTo = clamp(t, 0, Math.max(dur, projectDuration(work)));
        applied.push(`Jumped to ${seekTo.toFixed(1)}s`);
        break;
      }
      default:
        skipped.push(`Unknown step "${String(a.action).slice(0, 30)}"`);
    }
  });
  return { ops, applied, skipped, seekTo };
}

// Spreads AI-split caption pieces across each caption's original time range.
export function expandCaptionParts(subs, items) {
  const byIndex = new Map(items.map((it) => [it.i, it.parts]));
  const out = [];
  subs.forEach((s, i) => {
    let parts = (byIndex.get(i) || [s.text]).map((p) => String(p).trim()).filter(Boolean);
    if (!parts.length) parts = [s.text];
    const total = parts.reduce((n, p) => n + p.length, 0) || 1;
    const span = s.end - s.start;
    let t = s.start;
    parts.forEach((p, k) => {
      const d = (span * p.length) / total;
      out.push({ id: parts.length === 1 ? s.id : uid(), start: t, end: k === parts.length - 1 ? s.end : t + d, text: p });
      t += d;
    });
  });
  return out;
}

// Turns a script (one line per sentence) into caption blocks spread over totalSec.
export function scriptToSubs(text, totalSec) {
  const lines = String(text)
    .split(/\n+/)
    .map((l) => l.replace(/^(?:[-*\u2022]\s+|\d+[.)]\s+)/, '').trim())
    .filter(Boolean);
  if (!lines.length) return [];
  const total = totalSec && totalSec > 0 ? totalSec : lines.length * 2.5;
  const chars = lines.reduce((n, l) => n + l.length, 0) || 1;
  let t = 0;
  return lines.map((l, i) => {
    const d = (total * l.length) / chars;
    const sub = { id: uid(), start: t, end: i === lines.length - 1 ? total : t + d, text: l };
    t += d;
    return sub;
  });
}

// Applies proofread texts back onto captions, keeping word timing when word counts match.
export function applyPolished(subs, texts) {
  return subs.map((s, i) => {
    const t = texts[i];
    if (!t || t === s.text) return s;
    const parts = t.split(/\s+/).filter(Boolean);
    if (s.words && s.words.length === parts.length) {
      return { ...s, text: t, words: s.words.map((w, k) => ({ ...w, w: parts[k] })) };
    }
    return { ...s, text: t, words: null };
  });
}
