/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', '"Segoe UI"', 'Roboto', 'sans-serif'],
      },
      colors: {
        accent: 'rgb(var(--acc) / <alpha-value>)',
        accent2: 'rgb(var(--acc2) / <alpha-value>)',
      },
    },
  },
  plugins: [],
};
