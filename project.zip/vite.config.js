import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: './',
  plugins: [react()],
  worker: { format: 'es' },
  optimizeDeps: { exclude: ['@xenova/transformers'] },
  build: { target: 'esnext', chunkSizeWarningLimit: 6000 },
});
